/**
 * Legal (Contracts & POA) Filter Logic - Stable Version
 */
document.addEventListener('DOMContentLoaded', function() {
    initLegalFiltering();
    initContractModals();
    initPoaModals();
    initLegalCustomFileUploads(document);
    initContractDetailModals();
    initPoaDetailModals();
});

function initLegalFiltering() {
    const filterForms = document.querySelectorAll('form[data-ajax-filter="true"]');
    
    filterForms.forEach(form => {
        const targetId = form.getAttribute('data-target-id');
        const targetContainer = document.getElementById(targetId);
        if (!targetContainer) return;

        const inputs = form.querySelectorAll('input, select');
        
        inputs.forEach(input => {
            if (input.type === 'text') {
                input.addEventListener('input', debounce(() => {
                    submitFilterForm(form, targetContainer);
                }, 500));
            } else {
                input.addEventListener('change', () => {
                    submitFilterForm(form, targetContainer);
                });
            }
        });
    });
}

function submitFilterForm(form, container) {
    const formData = new FormData(form);
    const params = new URLSearchParams(formData);
    const baseUrl = form.getAttribute('action') || window.location.pathname;
    const url = `${baseUrl}?${params.toString()}`;
    
    window.history.pushState({}, '', url);
    container.style.opacity = '0.5';
    
    fetch(url, { 
        headers: { 
            'X-Requested-With': 'XMLHttpRequest' 
        } 
    })
        .then(response => {
            if (response.status === 302 || response.status === 401 || response.status === 403) {
                showLegalAlert('danger', 'جلسة انتهت. يرجى تسجيل الدخول مرة أخرى.');
                setTimeout(() => {
                    window.location.href = '/accounts/login/?next=' + encodeURIComponent(window.location.pathname);
                }, 2000);
                return Promise.reject('Session expired');
            }
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            return response.json();
        })
        .then(data => {
            container.innerHTML = data.html;
            container.style.opacity = '1';
        })
        .catch(() => { 
            container.style.opacity = '1'; 
        });
}

function initLegalModals(type) {
    const dataAttr = type === 'contract' ? 'data-contract-modal-url' : 'data-poa-modal-url';
    const openFunc = type === 'contract' ? openContractModal : openPoaModal;

    document.addEventListener('click', function(event) {
        const trigger = event.target.closest(`[${dataAttr}]`);
        if (!trigger) return;

        event.preventDefault();
        openFunc(trigger.getAttribute(dataAttr));
    });
}

function initContractModals() {
    initLegalModals('contract');
}

function openLegalModal(url, type) {
    // Check if user is still authenticated (simple check)
    if (!document.body.dataset.userAuth || document.body.dataset.userAuth !== 'true') {
        showLegalAlert('danger', 'جلسة انتهت. يرجى تسجيل الدخول مرة أخرى.');
        window.location.href = '/accounts/login/?next=' + encodeURIComponent(window.location.pathname);
        return;
    }

    fetch(url, {
        headers: {
            'X-Requested-With': 'XMLHttpRequest'
        }
    })
        .then(response => {
            // Check for redirect (session expired)
            if (response.status === 302 || response.status === 401 || response.status === 403) {
                showLegalAlert('danger', 'جلسة انتهت. يرجى تسجيل الدخول مرة أخرى.');
                setTimeout(() => {
                    window.location.href = '/accounts/login/?next=' + encodeURIComponent(window.location.pathname);
                }, 2000);
                return Promise.reject('Session expired');
            }
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            return response.json();
        })
        .then(data => {
            if (!data.html) {
                throw new Error('Empty modal payload');
            }
            if (type === 'contract') {
                mountContractModal(data.html);
            } else {
                mountPoaModal(data.html);
            }
        })
        .catch(error => {
            console.error(`Failed to load ${type} modal:`, error);
            const message = type === 'contract' ? 'تعذر تحميل نموذج العقد.' : 'تعذر تحميل نموذج التوكيل.';
            showLegalAlert('danger', message);
        });
}

function openContractModal(url) {
    openLegalModal(url, 'contract');
}

function initPoaModals() {
    initLegalModals('poa');
}

function openPoaModal(url) {
    openLegalModal(url, 'poa');
}

function mountLegalModal(html, type) {
    const modalId = type === 'contract' ? 'contractFormModal' : 'poaFormModal';
    const dialogId = type === 'contract' ? 'contractFormModalDialog' : 'poaFormModalDialog';
    const bindFunc = type === 'contract' ? bindContractModalForm : bindPoaModalForm;

    const modalEl = document.getElementById(modalId);
    const modalDialog = document.getElementById(dialogId);
    if (!modalEl || !modalDialog) return;

    modalDialog.innerHTML = html;
    bindFunc(modalEl);

    if (typeof window.initDatePickers === 'function') {
        window.initDatePickers(modalEl);
    }
    initLegalCustomFileUploads(modalEl);

    const modal = bootstrap.Modal.getOrCreateInstance(modalEl);
    modal.show();
}

function mountContractModal(html) {
    mountLegalModal(html, 'contract');
}

function bindLegalModalForm(modalEl, type) {
    const form = modalEl.querySelector('form');
    const boundAttr = type === 'contract' ? 'contractBound' : 'poaBound';
    const submitFunc = type === 'contract' ? submitContractModalForm : submitPoaModalForm;

    if (!form || form.dataset[boundAttr] === 'true') return;

    form.dataset[boundAttr] = 'true';
    form.addEventListener('submit', function(event) {
        event.preventDefault();
        submitFunc(form, modalEl);
    });
}

function bindContractModalForm(modalEl) {
    bindLegalModalForm(modalEl, 'contract');
}

function bindPoaModalForm(modalEl) {
    bindLegalModalForm(modalEl, 'poa');
}

function submitLegalModalForm(form, modalEl, type) {
    const submitBtn = form.querySelector('button[type="submit"]');
    const originalBtnHtml = submitBtn ? submitBtn.innerHTML : '';

    if (submitBtn) {
        submitBtn.disabled = true;
        submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin me-1"></i>جاري الحفظ...';
    }

    // تحويل تنسيق التاريخ من d/m/Y إلى Y-m-d للـ flatpickr
    const formData = new FormData(form);
    form.querySelectorAll('input[data-datepicker="true"]').forEach(function(input) {
        if (input.value) {
            const parts = input.value.split('/');
            if (parts.length === 3) {
                const converted = parts[2] + '-' + parts[1] + '-' + parts[0];
                formData.set(input.name, converted);
            }
        }
    });

    fetch(form.action, {
        method: 'POST',
        body: formData,
        headers: {
            'X-Requested-With': 'XMLHttpRequest'
        }
    })
        .then(async response => {
            // Check for redirect (session expired)
            if (response.status === 302 || response.status === 401 || response.status === 403) {
                showLegalAlert('danger', 'جلسة انتهت. يرجى تسجيل الدخول مرة أخرى.');
                setTimeout(() => {
                    window.location.href = '/accounts/login/?next=' + encodeURIComponent(window.location.pathname);
                }, 2000);
                return Promise.reject('Session expired');
            }
            if (!response.ok) {
                const text = await response.text();
                throw new Error(`HTTP ${response.status}: ${text.substring(0, 100)}`);
            }
            return response.json();
        })
        .then(({ ok, data }) => {
            if (ok && data.status === 'success') {
                const modal = bootstrap.Modal.getInstance(modalEl);
                if (modal) modal.hide();

                const successMessage = type === 'contract' ? 'تم حفظ العقد بنجاح' : 'تم حفظ التوكيل بنجاح';
                showLegalAlert('success', data.message || successMessage);
                if (type === 'contract') {
                    refreshContractsTable();
                } else {
                    refreshPoaTable();
                }
                return;
            }

            if (data.html) {
                if (type === 'contract') {
                    mountContractModal(data.html);
                } else {
                    mountPoaModal(data.html);
                }
                return;
            }

            const errorType = type === 'contract' ? 'contract' : 'POA';
            throw new Error(`Unexpected ${errorType} form response`);
        })
        .catch(error => {
            const errorType = type === 'contract' ? 'contract' : 'POA';
            console.error(`Failed to submit ${errorType} form:`, error);
            const errorMessage = type === 'contract' ? 'تعذر حفظ العقد. راجع الحقول وحاول مرة أخرى.' : 'تعذر حفظ التوكيل. راجع الحقول وحاول مرة أخرى.';
            showLegalAlert('danger', errorMessage);

            if (submitBtn) {
                submitBtn.disabled = false;
                submitBtn.innerHTML = originalBtnHtml;
            }
        });
}

function submitContractModalForm(form, modalEl) {
    submitLegalModalForm(form, modalEl, 'contract');
}

function mountPoaModal(html) {
    mountLegalModal(html, 'poa');
}

function initLegalCustomFileUploads(root = document) {
    const wrappers = (root || document).querySelectorAll('.custom-file-upload-wrapper');
    wrappers.forEach(function(wrapper) {
        // Skip if already initialized
        if (wrapper.dataset.initialized === 'true') return;

        const originalInput = wrapper.querySelector('input[type="file"]');
        if (!originalInput) return;

        // Find or create Display element
        let fileNameDisplay = wrapper.querySelector('.file-name-display-custom');
        if (!fileNameDisplay) {
            fileNameDisplay = document.createElement('span');
            fileNameDisplay.className = 'file-name-display-custom';
            fileNameDisplay.textContent = 'لم يتم اختيار ملف';
            wrapper.appendChild(fileNameDisplay);
        }

        // Find or create Label/Button
        let labelBtn = wrapper.querySelector('.custom-file-label-btn');
        if (!labelBtn) {
            labelBtn = document.createElement('label');
            labelBtn.className = 'custom-file-label-btn';
            labelBtn.innerHTML = '<i class="fas fa-upload"></i> اختر ملف';
            wrapper.appendChild(labelBtn);
        }

        // Link label to input if not already linked
        if (!originalInput.id) {
            originalInput.id = `file-input-${Math.random().toString(36).slice(2, 9)}`;
        }
        labelBtn.setAttribute('for', originalInput.id);

        // Core Change Event
        originalInput.addEventListener('change', function() {
            const file = this.files[0];
            const nameTargetId = this.dataset.nameTarget;
            const previewTargetId = this.dataset.previewTarget;
            const containerId = this.dataset.containerTarget;

            // 1. Update text display (inside wrapper or specific target)
            const nameDisplay = nameTargetId ? document.getElementById(nameTargetId) : fileNameDisplay;
            if (nameDisplay) {
                if (file) {
                    nameDisplay.textContent = file.name;
                    nameDisplay.classList.add('has-file');
                } else {
                    nameDisplay.textContent = 'لم يتم اختيار ملف';
                    nameDisplay.classList.remove('has-file');
                }
            }

            // 2. Handle Image Preview if target provided
            if (file && previewTargetId) {
                const previewImg = document.getElementById(previewTargetId);
                const container = containerId ? document.getElementById(containerId) : null;
                const placeholder = container ? container.querySelector('.placeholder-content') : null;
                const removeBtn = container ? container.querySelector('.btn-remove-image') : null;

                if (previewImg && file.type.startsWith('image/')) {
                    const reader = new FileReader();
                    reader.onload = function(e) {
                        previewImg.src = e.target.result;
                        previewImg.classList.remove('d-none');
                        if (placeholder) placeholder.classList.add('d-none');
                        if (removeBtn) removeBtn.classList.remove('d-none');
                    };
                    reader.readAsDataURL(file);
                }
            }
        });

        wrapper.dataset.initialized = 'true';
    });
}

/**
 * وظيفة حذف الصورة المختارة وإعادة الحالة للوضع الافتراضي
 */
function clearLegalImage(type) {
    const prefix = type === 'contract' ? 'contract' : 'poa';
    const input = document.getElementById(`id_${prefix}_image_field`);
    const preview = document.getElementById(`${prefix}ImagePreview`);
    const container = document.getElementById(`${prefix}ImagePreviewContainer`);
    const placeholder = container ? container.querySelector('.placeholder-content') : null;
    const removeBtn = document.getElementById(`btnRemove${prefix.charAt(0).toUpperCase() + prefix.slice(1)}Image`);
    const nameDisplay = document.getElementById(`${prefix}ImageNameDisplay`);

    if (input) input.value = '';
    if (preview) {
        preview.src = '';
        preview.classList.add('d-none');
    }
    if (placeholder) placeholder.classList.remove('d-none');
    if (removeBtn) removeBtn.classList.add('d-none');
    if (nameDisplay) {
        nameDisplay.textContent = 'لم يتم اختيار ملف';
        nameDisplay.classList.remove('has-file');
    }
}

function clearContractImage() {
    clearLegalImage('contract');
}

function clearPoaImage() {
    clearLegalImage('poa');
}

function submitPoaModalForm(form, modalEl) {
    submitLegalModalForm(form, modalEl, 'poa');
}

function refreshLegalTable(type) {
    const containerId = type === 'contract' ? 'contractTableWrapper' : 'poaTableWrapper';
    const formId = type === 'contract' ? 'contractFilterForm' : 'poaFilterForm';
    const errorType = type === 'contract' ? 'contracts' : 'POA';

    const container = document.getElementById(containerId);
    if (!container) return;

    const form = document.getElementById(formId);
    const baseUrl = form && form.getAttribute('action') ? form.getAttribute('action') : window.location.pathname;
    
    let searchString = '';
    if (form) {
        searchString = '?' + new URLSearchParams(new FormData(form)).toString();
    } else {
        searchString = window.location.search;
    }

    const url = `${baseUrl}${searchString}`;
    container.style.opacity = '0.5';

    fetch(url, {
        headers: {
            'X-Requested-With': 'XMLHttpRequest'
        }
    })
        .then(response => {
            if (response.status === 302 || response.status === 401 || response.status === 403) {
                showLegalAlert('danger', 'جلسة انتهت. يرجى تسجيل الدخول مرة أخرى.');
                setTimeout(() => {
                    window.location.href = '/accounts/login/?next=' + encodeURIComponent(window.location.pathname);
                }, 2000);
                return Promise.reject('Session expired');
            }
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            return response.json();
        })
        .then(data => {
            container.innerHTML = data.html;
            container.style.opacity = '1';
            
            // تحديث كروت الإحصاء
            if (data.stats) {
                updateHeroStats(data.stats);
            }
        })
        .catch(error => {
            console.error(`Failed to refresh ${errorType} table:`, error);
            container.style.opacity = '1';
            window.location.reload();
        });
}

function refreshContractsTable() {
    refreshLegalTable('contract');
}

function refreshPoaTable() {
    refreshLegalTable('poa');
}

function cleanupContractModalArtifacts() {
    document.querySelectorAll('.modal-backdrop').forEach(backdrop => backdrop.remove());
    document.body.classList.remove('modal-open');
    document.body.style.removeProperty('overflow');
    document.body.style.removeProperty('padding-left');
    document.body.style.removeProperty('padding-right');
}

function showLegalAlert(type, message) {
    let toaster = document.getElementById('legal-toaster');
    if (!toaster) {
        toaster = document.createElement('div');
        toaster.id = 'legal-toaster';
        Object.assign(toaster.style, {
            position: 'fixed',
            top: '20px',
            left: '50%',
            transform: 'translateX(-50%)',
            zIndex: '9999',
            display: 'flex',
            flexDirection: 'column',
            gap: '10px',
            alignItems: 'center'
        });
        document.body.appendChild(toaster);
    }

    const alert = document.createElement('div');
    alert.className = `alert alert-${type} alert-dismissible fade show shadow-lg mb-0 px-4 py-3 rounded-toast`;
    alert.style.minWidth = '300px';
    alert.style.textAlign = 'center';
    alert.style.borderRadius = '50px';
    alert.innerHTML = `
        <span class="fw-bold d-inline-block me-4">${message}</span>
        <button type="button" class="btn-close ms-0 me-2" style="position: absolute; left: 15px; top: 50%; transform: translateY(-50%);" data-bs-dismiss="alert" aria-label="إغلاق"></button>
    `;

    toaster.appendChild(alert);
    setTimeout(() => {
        alert.classList.remove('show');
        setTimeout(() => alert.remove(), 250); // wait for fade out
    }, 4000);
}

function debounce(func, wait) {
    let timeout;
    return (...args) => {
        clearTimeout(timeout);
        timeout = setTimeout(() => func.apply(this, args), wait);
    };
}

function initContractDetailModals() {
    // عرض تفاصيل العقد
    document.addEventListener('click', function(e) {
        const btn = e.target.closest('.btn-view-contract');
        if (!btn) return;
        
        e.preventDefault();
        const url = btn.dataset.url;
        const modalEl = document.getElementById('contractDetailModal');
        const contentEl = document.getElementById('contractDetailContent');
        
        if (!modalEl || !contentEl) return;

        contentEl.innerHTML = '<div class="text-center p-5"><div class="spinner-border text-primary" role="status"></div><p class="mt-2">جاري تحميل التفاصيل...</p></div>';
        const modal = bootstrap.Modal.getOrCreateInstance(modalEl);
        modal.show();

        fetch(url, { 
            headers: { 
                'X-Requested-With': 'XMLHttpRequest' 
            } 
        })
            .then(response => {
                if (response.status === 302 || response.status === 401 || response.status === 403) {
                    showLegalAlert('danger', 'جلسة انتهت. يرجى تسجيل الدخول مرة أخرى.');
                    setTimeout(() => {
                        window.location.href = '/accounts/login/?next=' + encodeURIComponent(window.location.pathname);
                    }, 2000);
                    return Promise.reject('Session expired');
                }
                return response.json();
            })
            .then(data => {
                contentEl.innerHTML = data.html;
                const printBtn = document.getElementById('btn-print-contract-modal');
                if (printBtn) {
                   printBtn.onclick = () => printContractDirectly(data.id);
                }
            })
            .catch(err => {
                contentEl.innerHTML = '<div class="alert alert-danger m-3">حدث خطأ أثناء تحميل البيانات.</div>';
            });
    });
    
    // الطباعة من الجدول مباشرة
    document.addEventListener('click', function(e) {
        const btn = e.target.closest('.btn-print-contract');
        if (!btn) return;
        e.preventDefault();
        printContractDirectly(btn.dataset.contractId);
    });
}

function initPoaDetailModals() {
    // عرض تفاصيل التوكيل
    document.addEventListener('click', function(e) {
        const btn = e.target.closest('.btn-view-poa');
        if (!btn) return;
        
        e.preventDefault();
        const url = btn.dataset.url;
        const modalEl = document.getElementById('poaDetailModal');
        const contentEl = document.getElementById('poaDetailContent');
        
        if (!modalEl || !contentEl) return;

        contentEl.innerHTML = '<div class="text-center p-5"><div class="spinner-border text-info" role="status"></div><p class="mt-2">جاري تحميل التفاصيل...</p></div>';
        const modal = bootstrap.Modal.getOrCreateInstance(modalEl);
        modal.show();

        fetch(url, { 
            headers: { 
                'X-Requested-With': 'XMLHttpRequest' 
            } 
        })
            .then(response => {
                if (response.status === 302 || response.status === 401 || response.status === 403) {
                    showLegalAlert('danger', 'جلسة انتهت. يرجى تسجيل الدخول مرة أخرى.');
                    setTimeout(() => {
                        window.location.href = '/accounts/login/?next=' + encodeURIComponent(window.location.pathname);
                    }, 2000);
                    return Promise.reject('Session expired');
                }
                return response.json();
            })
            .then(data => {
                contentEl.innerHTML = data.html;
                const printBtn = document.getElementById('btn-print-poa-modal');
                if (printBtn) {
                   printBtn.onclick = () => printPoaDirectly(data.id);
                }
            })
            .catch(err => {
                contentEl.innerHTML = '<div class="alert alert-danger m-3">حدث خطأ أثناء تحميل البيانات.</div>';
            });
    });
    
    // الطباعة من الجدول مباشرة
    document.addEventListener('click', function(e) {
        const btn = e.target.closest('.btn-print-poa');
        if (!btn) return;
        e.preventDefault();
        printPoaDirectly(btn.dataset.poaId);
    });
}

function printContractDirectly(id) {
    if (!id) return;
    fetch(`/api/contracts/${id}/`)
        .then(r => r.json())
        .then(data => {
             if (window.printUnified) {
                 window.printUnified({
                     type: 'contract',
                     title: 'تفاصيل العقد',
                     badges: [data.contract_number, data.status_display],
                     sections: [
                         {
                             title: 'بيانات العقد الأساسية',
                             fields: [
                                 { label: 'العميل', value: data.client_name },
                                 { label: 'رقم الهاتف', value: data.client_phone },
                                 { label: 'عنوان العقد', value: data.title },
                                 { label: 'رقم العقد', value: data.contract_number },
                                 { label: 'التاريخ', value: data.start_date },
                                 { label: 'القضية المرتبطة', value: data.case_subject }
                             ]
                         },
                         {
                             title: 'ملاحظات',
                             list: data.notes && data.notes !== '—' ? [data.notes] : ['لا توجد ملاحظات']
                         }
                     ]
                 });
             } else {
                 window.open(`/contracts/${id}/?print=1`, '_blank');
             }
        });
}

function printPoaDirectly(id) {
    if (!id) return;
    fetch(`/api/poa/${id}/`)
        .then(r => r.json())
        .then(data => {
             if (window.printUnified) {
                 window.printUnified({
                     type: 'poa',
                     title: 'بيانات التوكيل',
                     badges: [data.poa_number, data.type_display],
                     sections: [
                         {
                             title: 'بيانات التوكيل',
                             fields: [
                                 { label: 'الموكل', value: data.client_name },
                                 { label: 'رقم الهاتف', value: data.client_phone },
                                 { label: 'رقم التوكيل', value: data.poa_number },
                                 { label: 'نوع التوكيل', value: data.type_display },
                                 { label: 'جهة الإصدار', value: data.office },
                                 { label: 'التاريخ', value: data.issue_date }
                             ]
                         },
                         {
                             title: 'ملاحظات',
                             list: data.notes && data.notes !== '—' ? [data.notes] : ['لا توجد ملاحظات']
                         }
                     ]
                 });
             } else {
                 window.open(`/power-of-attorney/${id}/?print=1`, '_blank');
             }
        });
}

function exportContractsToExcel(event) {
    handleLegalExport(event, 'contractFilterForm', '/export/contracts/excel/', 'Excel');
}

function exportContractsToPDF(event) {
    handleLegalExport(event, 'contractFilterForm', '/export/contracts/pdf/', 'PDF');
}

function exportPoaToExcel(event) {
    handleLegalExport(event, 'poaFilterForm', '/export/poa/excel/', 'Excel');
}

function exportPoaToPDF(event) {
    handleLegalExport(event, 'poaFilterForm', '/export/poa/pdf/', 'PDF');
}

function handleLegalExport(event, formId, baseUrl, type) {
    const btn = event.target.closest('button');
    if (!btn) return;
    
    const originalHtml = btn.innerHTML;
    btn.disabled = true;
    btn.innerHTML = `<i class="fas fa-spinner fa-spin me-1"></i> جاري...`;
    
    const form = document.getElementById(formId);
    let params = new URLSearchParams();
    if(form) {
        const formData = new FormData(form);
        for (const [key, value] of formData.entries()) {
            if (value) {
                params.append(key, value);
            }
        }
    }
    
    const queryString = params.toString();
    const url = queryString ? `${baseUrl}?${queryString}` : baseUrl;
    
    if (typeof pywebview !== 'undefined' && pywebview.api && pywebview.api.saveFile) {
        fetch(url, { headers: { 'X-Desktop-Mode': 'true' } })
            .then(r => r.json())
            .then(data => {
                if (data.success) {
                    const fileTypes = type === 'PDF' 
                        ? ['PDF files (*.pdf)', 'All files (*.*)'] 
                        : ['Excel files (*.xlsx)', 'All files (*.*)'];
                    pywebview.api.saveFile(data.filename, data.content, fileTypes).catch(() => {});
                } else {
                    alert('فشل التصدير: ' + (data.error || ''));
                }
            })
            .catch(err => {
                console.error('Export error:', err);
                alert('حدث خطأ أثناء التصدير');
            })
            .finally(() => {
                btn.disabled = false;
                btn.innerHTML = originalHtml;
            });
    } else {
        if (type === 'PDF') {
            fetch(url, { headers: { 'X-Desktop-Mode': 'true' } })
                .then(r => r.json())
                .then(data => {
                    if (data.success) {
                        const byteCharacters = atob(data.content);
                        const byteNumbers = new Array(byteCharacters.length);
                        for (let i = 0; i < byteCharacters.length; i++) {
                            byteNumbers[i] = byteCharacters.charCodeAt(i);
                        }
                        const blob = new Blob([new Uint8Array(byteNumbers)], { type: 'application/pdf' });
                        const link = document.createElement('a');
                        link.href = window.URL.createObjectURL(blob);
                        link.download = data.filename;
                        link.click();
                    } else {
                        window.location.href = url;
                    }
                })
                .catch(() => { window.location.href = url; })
                .finally(() => {
                    setTimeout(() => {
                        btn.disabled = false;
                        btn.innerHTML = originalHtml;
                    }, 2000);
                });
        } else {
            window.location.href = url;
            setTimeout(() => {
                btn.disabled = false;
                btn.innerHTML = originalHtml;
            }, 2000);
        }
    }
}

/**
 * تحديث كروت الإحصاء في الصفحة
 */
function updateHeroStats(stats) {
    if (!stats) return;
    
    // تحديث إحصائيات العقود
    if (stats.total_contracts !== undefined) {
        const totalEl = document.querySelector('.hero-stat-total .value');
        if (totalEl) totalEl.textContent = stats.total_contracts;
    }
    if (stats.active_contracts !== undefined) {
        const activeEl = document.querySelector('.hero-stat-active .value');
        if (activeEl) activeEl.textContent = stats.active_contracts;
    }
    if (stats.expired_contracts !== undefined) {
        const expiredEl = document.querySelector('.hero-stat-expired .value');
        if (expiredEl) expiredEl.textContent = stats.expired_contracts;
    }
    
    // تحديث إحصائيات التوكيلات
    if (stats.total_poas !== undefined) {
        const poaTotalEl = document.querySelector('.hero-stat-pending .value');
        if (poaTotalEl) poaTotalEl.textContent = stats.total_poas;
    }
    if (stats.active_poas !== undefined) {
        const poaActiveEl = document.querySelector('.hero-stat-government .value');
        if (poaActiveEl) poaActiveEl.textContent = stats.active_poas;
    }
    if (stats.expired_poas !== undefined) {
        const poaExpiredEl = document.querySelector('.hero-stat-entity .value');
        if (poaExpiredEl) poaExpiredEl.textContent = stats.expired_poas;
    }
}
