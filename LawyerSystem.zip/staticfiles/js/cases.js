/**
 * Mizan Al-Adala - Cases Management JavaScript
 * Handles AJAX filtering, Create/Edit/Delete modals, and Print functionality
 */

document.addEventListener('DOMContentLoaded', function () {
    // 1. AJAX Filtering Logic
    initCasesFiltering();

    // 2. Modal Handlers (Create, Edit, Delete, View)
    initCasesModals();

    // 3. Print Functionality (Event Delegation)
    initCasesPrinting();

    // 4. Modal Cleanup Handlers
    initModalCleanup();
});

/**
 * Initialize AJAX Search and Filter
 */
function initCasesFiltering() {
    const filterForm = document.getElementById('filterForm');
    const tableContainer = document.getElementById('tableContainer');
    const casesCount = document.getElementById('casesCount');

    if (!filterForm || !tableContainer) return;

    let debounceTimer;

    const updateTable = (url = null) => {
        if (!url) {
            const formData = new FormData(filterForm);
            const params = new URLSearchParams(formData);
            url = window.location.pathname + '?' + params.toString();
        }

        // Update URL in browser
        window.history.pushState({}, '', url);

        // Show loading state
        tableContainer.style.opacity = '0.5';
        tableContainer.style.pointerEvents = 'none';

        fetch(url, {
            headers: { 'X-Requested-With': 'XMLHttpRequest' }
        })
            .then(response => response.json())
            .then(data => {
                if (data.error) {
                    console.error('Server error:', data.error);
                    alert('حدث خطأ: ' + data.error);
                    return;
                }
                
                if (data.html) {
                    tableContainer.innerHTML = data.html;
                    
                    // Update count if available
                    if (data.count !== undefined && casesCount) {
                        casesCount.textContent = data.count;
                    }
                    
                    // Re-initialize event listeners for new elements
                    // (initCasesPrinting uses event delegation on document, so no need to re-initialize)
                }

                tableContainer.style.opacity = '1';
                tableContainer.style.pointerEvents = 'auto';
            })
            .catch(error => {
                console.error('Filtering error:', error);
                alert('حدث خطأ في الاتصال');
                tableContainer.style.opacity = '1';
                tableContainer.style.pointerEvents = 'auto';
            });
    };

    // Listen for changes
    filterForm.querySelectorAll('select').forEach(select => {
        select.addEventListener('change', () => updateTable());
    });

    const searchInput = filterForm.querySelector('input[name="search"]');
    if (searchInput) {
        searchInput.addEventListener('input', () => {
            clearTimeout(debounceTimer);
            debounceTimer = setTimeout(() => updateTable(), 500);
        });
    }

    // Reset Filters
    const resetBtn = document.getElementById('resetFilters');
    if (resetBtn) {
        resetBtn.addEventListener('click', () => {
            filterForm.reset();
            filterForm.querySelectorAll('select').forEach(s => s.value = "");
            filterForm.querySelectorAll('input').forEach(i => i.value = "");
            updateTable();
        });
    }

    // Handle pagination
    document.addEventListener('click', function (e) {
        const pageLink = e.target.closest('#paginationContainer .page-link');
        if (pageLink) {
            e.preventDefault();
            const url = pageLink.getAttribute('href');
            if (url && url !== '#') {
                updateTable(url);
                window.scrollTo({ top: tableContainer.offsetTop - 100, behavior: 'smooth' });
            }
        }
    });
}

/**
 * Handle Add/Edit/Delete/View Modals
 */
function initCasesModals() {
    // 1. View Case Detail
    document.addEventListener('click', function (e) {
        const viewBtn = e.target.closest('.btn-view-case');
        if (viewBtn) {
            const url = viewBtn.getAttribute('data-url');
            const modalEl = document.getElementById('caseDetailModal');
            const contentArea = document.getElementById('caseDetailContent');

            if (modalEl && contentArea) {
                const modal = bootstrap.Modal.getOrCreateInstance(modalEl);
                modal.show();

                fetch(url, { headers: { 'X-Requested-With': 'XMLHttpRequest' } })
                    .then(res => res.json())
                    .then(data => {
                        contentArea.innerHTML = data.html || '<div class="alert alert-danger">❌ فشل تحميل المحتوى</div>';
                    })
                    .catch(err => {
                        console.error('Fetch error:', err);
                        contentArea.innerHTML = '<div class="alert alert-danger">❌ فشل تحميل البيانات.</div>';
                    });
            }
        }
    });

    // 2. Edit Case logic
    document.addEventListener('click', function (e) {
        const editBtn = e.target.closest('.btn-edit-case');
        if (editBtn) {
            const url = editBtn.getAttribute('data-url');
            const modalEl = document.getElementById('editCaseModal');
            const contentArea = document.getElementById('editModalContent');
            const form = document.getElementById('editCaseForm');

            const modalInstance = bootstrap.Modal.getOrCreateInstance(modalEl);
            modalEl.dataset.formSubmitted = 'false';
            modalInstance.show();

            if (form) form.setAttribute('action', url);

            fetch(url, { headers: { 'X-Requested-With': 'XMLHttpRequest' } })
                .then(res => res.json())
                .then(data => {
                    contentArea.innerHTML = data.html;
                    if (typeof window.initForm === 'function') window.initForm(contentArea);
                    if (typeof window.initDatePickers === 'function') window.initDatePickers(contentArea);
                })
                .catch(err => {
                    console.error('Fetch error:', err);
                    contentArea.innerHTML = '<div class="alert alert-danger">❌ فشل تحميل البيانات.</div>';
                });
        }
    });

    // 3. Add Case Submission
    const addForm = document.getElementById('addCaseForm');
    if (addForm) {
        addForm.addEventListener('submit', function (e) {
            e.preventDefault();
            submitAjaxForm(this, 'addCaseModal');
        });
    }

    // 4. Edit Case Submission
    const editForm = document.getElementById('editCaseForm');
    if (editForm) {
        editForm.addEventListener('submit', function (e) {
            e.preventDefault();
            submitAjaxForm(this, 'editCaseModal', true);
        });
    }

    // 5. Delete Case Confirmation
    document.addEventListener('click', function (e) {
        const deleteBtn = e.target.closest('.btn-delete-case');
        if (deleteBtn) {
            const url = deleteBtn.getAttribute('data-url');
            const caseNumber = deleteBtn.getAttribute('data-case');
            const caseSubject = deleteBtn.getAttribute('data-subject');

            const modalEl = document.getElementById('deleteCaseModal');
            const infoArea = document.getElementById('deleteCaseInfo');
            const form = document.getElementById('deleteCaseForm');

            if (modalEl && infoArea && form) {
                infoArea.textContent = `${caseNumber} - ${caseSubject}`;
                form.setAttribute('action', url);
                bootstrap.Modal.getOrCreateInstance(modalEl).show();
            }
        }
    });
}

/**
 * Generic AJAX form submission
 */
function submitAjaxForm(form, modalId, isUpdate = false) {
    const formData = new FormData(form);
    const submitBtn = form.querySelector('button[type="submit"]');
    const modalEl = document.getElementById(modalId);
    const originalText = submitBtn.innerHTML;

    submitBtn.disabled = true;
    submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin me-1"></i> جاري الحفظ...';

    fetch(form.getAttribute('action') || window.location.href, {
        method: 'POST',
        body: formData,
        headers: { 'X-Requested-With': 'XMLHttpRequest' }
    })
        .then(res => res.json())
        .then(data => {
            if (data.status === 'success') {
                modalEl.dataset.formSubmitted = 'true';
                bootstrap.Modal.getInstance(modalEl).hide();

                if (isUpdate) {
                    showSuccessMessage(data.message || '✅ تم التحديث بنجاح');
                    // Trigger refresh by calling filter logic
                    document.getElementById('resetFilters').click();
                } else {
                    window.location.reload();
                }
            } else if (data.status === 'error') {
                // تحويل الأخطاء لتنسيق مصفوفة لاستخدامها في المودال المطور
                const errorList = [];
                for (let field in data.errors) {
                    data.errors[field].forEach(err => {
                        errorList.push({ field: field, message: err });
                    });
                }

                // محاولة استخدام المودال المطور إذا وجد، وإلا استعمل alert التقليدي
                if (typeof window.showFormValidationModal === 'function') {
                    window.showFormValidationModal(errorList);
                } else {
                    let msg = '⚠️ يرجى تصحيح الأخطاء:\n';
                    errorList.forEach(e => msg += `• ${e.field}: ${e.message}\n`);
                    alert(msg);
                }
            }
        })
        .catch(err => alert('❌ حدث خطأ غير متوقع.'))
        .finally(() => {
            submitBtn.disabled = false;
            submitBtn.innerHTML = originalText;
        });
}

function showSuccessMessage(msg) {
    const alertDiv = document.createElement('div');
    alertDiv.className = 'alert alert-success alert-dismissible fade show position-fixed top-0 start-50 translate-middle-x mt-4';
    alertDiv.style.zIndex = '9999';
    alertDiv.innerHTML = `
        <i class="fas fa-check-circle me-2"></i> ${msg}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
    document.body.appendChild(alertDiv);
    setTimeout(() => alertDiv.remove(), 3000);
}

/**
 * Initialize Modal Cleanup Handlers
 */
function initModalCleanup() {
    const modals = ['addCaseModal', 'editCaseModal'];
    modals.forEach(id => {
        const el = document.getElementById(id);
        if (el) {
            // When modal is shown, initialize forms
            el.addEventListener('shown.bs.modal', function () {
                if (typeof window.initForm === 'function') {
                    window.initForm(el);
                }
                if (typeof window.initDatePickers === 'function') {
                    window.initDatePickers(el);
                }
            });

            // Before modal hides, cleanup datepickers
            el.addEventListener('hide.bs.modal', function () {
                const restoreOriginalValue = el.dataset.formSubmitted !== 'true';
                if (typeof window.cleanupCaseFormDatePickers === 'function') {
                    window.cleanupCaseFormDatePickers(el, { restoreOriginalValue });
                }

                const dateInputs = el.querySelectorAll('input[data-datepicker="true"]');
                dateInputs.forEach(input => {
                    if (input._flatpickr) {
                        input._flatpickr.close();
                        input._flatpickr.destroy();
                    }
                });
                document.querySelectorAll('.flatpickr-calendar, .flatpickr-mobile').forEach(cal => cal.remove());
                setTimeout(() => {
                    if (typeof window.cleanupCaseFormDatePickers === 'function') {
                        window.cleanupCaseFormDatePickers(el, { restoreOriginalValue });
                    } else {
                        document.querySelectorAll('.flatpickr-calendar, .flatpickr-mobile').forEach(cal => cal.remove());
                    }
                }, 0);
            });

            // After modal is hidden, reset form
            el.addEventListener('hidden.bs.modal', function () {
                const form = el.querySelector('form');
                const formContainer = el.querySelector('.case-form-container');
                if (typeof window.cleanupCaseFormDatePickers === 'function') {
                    window.cleanupCaseFormDatePickers(el, { restoreOriginalValue: false });
                } else {
                    document.querySelectorAll('.flatpickr-calendar, .flatpickr-mobile').forEach(cal => cal.remove());
                }
                if (form) {
                    form.reset();
                    const statuses = form.querySelectorAll('.file-status');
                    statuses.forEach(s => {
                        s.textContent = 'لم تُحدد أي ملّفات.';
                        s.classList.remove('text-primary', 'fw-bold');
                    });
                }
                if (formContainer) {
                    formContainer.dataset.caseFormInitialized = 'false';
                }
                el.dataset.formSubmitted = 'false';
                if (id === 'editCaseModal') {
                    const editContent = document.getElementById('editModalContent');
                    if (editContent) {
                        editContent.innerHTML = '<div class="text-center py-5"><div class="spinner-border text-primary" role="status"><span class="visually-hidden">جاري التحميل...</span></div></div>';
                    }
                }
            });
        }
    });
}

/**
 * Handle Case Printing logic
 */
function initCasesPrinting() {
    document.addEventListener('click', function (e) {
        const printBtn = e.target.closest('.btn-print-case');
        if (printBtn) {
            e.preventDefault();
            e.stopPropagation();
            const caseId = printBtn.getAttribute('data-case-id');
            printCaseDirectly(caseId);
        }
    });
}

function printCaseDirectly(caseId) {
    console.log('🖨️ printCaseDirectly called with ID:', caseId);

    fetch(`/api/cases/${caseId}/`)
        .then(response => {
            console.log('📡 API response status:', response.status);
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            return response.json();
        })
        .then(data => {
            console.log('✅ Case data received:', data);

            if (data.error) {
                throw new Error(data.error);
            }

            // بناء الأوسمة
            const badges = [
                `الحالة: ${data.status_display || '—'}`,
                `الأولوية: ${data.priority_display || '—'}`,
                `رقم: ${data.case_number || '—'}/${data.case_year || '—'}`
            ];

            // بناء الأقسام
            const sections = [];

            // 1. المعلومات الأساسية
            sections.push({
                title: 'المعلومات الأساسية',
                fields: [
                    { label: 'الموضوع', value: data.subject },
                    { label: 'نوع القضية', value: data.case_type },
                    { label: 'المحكمة', value: data.court },
                    { label: 'الأولوية', value: data.priority_display }
                ]
            });

            // 2. بيانات العميل
            sections.push({
                title: 'بيانات العميل',
                fields: [
                    { label: 'العميل', value: data.client_name },
                    { label: 'رقم الهاتف', value: data.client_phone },
                    { label: 'الهوية الوطنية', value: data.client_national_id },
                    { label: 'العنوان', value: data.client_address }
                ]
            });

            // 3. الخصوم
            if (data.opponents && data.opponents.length > 0) {
                sections.push({
                    title: 'الخصوم',
                    list: data.opponents.map(o => `${o.name} (${o.type_display || '—'})`)
                });
            }

            // 4. الجلسات
            if (data.sessions && data.sessions.length > 0) {
                sections.push({
                    title: `الجلسات (${data.sessions.length})`,
                    table: {
                        headers: ['التاريخ', 'الوقت', 'المحكمة', 'النوع', 'الحالة'],
                        rows: data.sessions.map(s => [
                            s.date || '—',
                            s.time || '—',
                            s.court || '—',
                            s.session_type || '—',
                            s.status_display || '—'
                        ])
                    }
                });
            }

            // 5. المستندات
            if (data.documents && data.documents.length > 0) {
                sections.push({
                    title: `المستندات (${data.documents.length})`,
                    table: {
                        headers: ['النوع', 'مستوى السرية', 'تاريخ الرفع'],
                        rows: data.documents.map(d => [
                            d.doc_type_display || '—',
                            d.security_level_display || '—',
                            d.uploaded_at || '—'
                        ])
                    }
                });
            }

            // 6. المهام
            if (data.tasks && data.tasks.length > 0) {
                sections.push({
                    title: `المهام (${data.tasks.length})`,
                    table: {
                        headers: ['المهمة', 'المكلف', 'موعد التسليم', 'الحالة'],
                        rows: data.tasks.map(t => [
                            t.title || '—',
                            t.assigned_to || '—',
                            t.due_date || '—',
                            t.status_display || '—'
                        ])
                    }
                });
            }

            // 7. الملخص المالي
            sections.push({
                title: 'الملخص المالي',
                fields: [
                    { label: 'إجمالي الأتعاب', value: data.total_fees },
                    { label: 'المحصل', value: data.total_payments },
                    { label: 'المصروفات', value: data.total_expenses },
                    { label: 'صافي الربح', value: data.net_profit }
                ]
            });

            console.log('📦 Prepared sections:', sections.length);
            console.log('🏷️ Prepared badges:', badges);

            // استدعاء دالة الطباعة الموحدة
            if (typeof window.printUnified === 'function') {
                window.printUnified({
                    type: 'case',
                    title: 'تقرير القضية',
                    badges: badges,
                    sections: sections,
                    footer: `تم استخراج هذا التقرير للقضية رقم ${data.case_number || '—'}`
                });
            } else {
                console.error('❌ printUnified function not found');
                alert('❌ خطأ: نظام الطباعة غير متوفر');
            }
        })
        .catch(error => {
            console.error('❌ Error in printCaseDirectly:', error);
            alert('❌ حدث خطأ أثناء الطباعة: ' + error.message);
        });
}

// Global Export Functions (called from button onclick in template)
window.exportToExcel = function () { exportFile('excel'); };
window.exportToPDF = function () { exportFile('pdf'); };

function exportFile(type) {
    const btn = event.target.closest('button');
    const originalHtml = btn.innerHTML;
    btn.disabled = true;
    btn.innerHTML = '<i class="fas fa-spinner fa-spin me-1"></i> جاري التصدير...';

    const filterForm = document.getElementById('filterForm');
    const params = new URLSearchParams(new FormData(filterForm)).toString();
    const baseUrl = type === 'excel' ? btn.dataset.excelUrl : btn.dataset.pdfUrl;
    const url = params ? `${baseUrl}?${params}` : baseUrl;

    if (typeof pywebview !== 'undefined' && pywebview.api && pywebview.api.saveFile) {
        // Desktop mode
        fetch(url, { headers: { 'X-Desktop-Mode': 'true' } })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    const fileTypes = type === 'pdf' 
                        ? ['PDF files (*.pdf)', 'All files (*.*)'] 
                        : ['Excel files (*.xlsx)', 'All files (*.*)'];
                    pywebview.api.saveFile(data.filename, data.content, fileTypes).catch(() => { });
                }
                else alert('فشل التصدير');
            })
            .finally(() => {
                btn.disabled = false;
                btn.innerHTML = originalHtml;
            });
    } else {
        // Browser mode
        window.location.href = url;
        setTimeout(() => {
            btn.disabled = false;
            btn.innerHTML = originalHtml;
        }, 2000);
    }
}
