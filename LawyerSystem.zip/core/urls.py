from django.urls import path
from django.contrib.auth import views as auth_views
from core import views

app_name = 'core'

urlpatterns = [
    # Authentication
    path('login/', auth_views.LoginView.as_view(template_name='registration/login.html'), name='login'),
    path('logout/', views.logout_view, name='logout'),
    
    # Dashboard
    path('', views.DashboardView.as_view(), name='dashboard'),

    # Cases
    path('cases/', views.CaseListView.as_view(), name='cases'),
    path('cases/create/', views.CaseCreateView.as_view(), name='case_create'),
    path('cases/<int:pk>/', views.CaseDetailView.as_view(), name='case_detail'),
    path('cases/<int:pk>/edit/', views.CaseUpdateView.as_view(), name='case_update'),
    path('cases/<int:pk>/delete/', views.CaseDeleteView.as_view(), name='case_delete'),
    path('cases/check-duplicate/', views.check_case_duplicate, name='check_case_duplicate'),

    
    # Clients
    path('clients/', views.ClientListView.as_view(), name='clients'),
    path('clients/create/', views.ClientCreateView.as_view(), name='client_create'),
    path('clients/<int:pk>/', views.ClientDetailView.as_view(), name='client_detail'),
    path('clients/<int:pk>/edit/', views.ClientUpdateView.as_view(), name='client_update'),
    path('clients/<int:pk>/delete/', views.ClientDeleteView.as_view(), name='client_delete'),
    path('clients/check-duplicate/', views.check_client_duplicate, name='check_client_duplicate'),
    path('opponents/check-duplicate/', views.check_opponent_duplicate, name='check_opponent_duplicate'),
    path('export/clients/excel/', views.export_clients_excel, name='export_clients_excel'),
    path('export/clients/pdf/', views.export_clients_pdf, name='export_clients_pdf'),

    
    # Opponents
    path('opponents/', views.OpponentListView.as_view(), name='opponents'),
    path('opponents/create/', views.OpponentCreateView.as_view(), name='opponent_create'),
    path('opponents/<int:pk>/', views.OpponentDetailView.as_view(), name='opponent_detail'),
    path('opponents/<int:pk>/edit/', views.OpponentUpdateView.as_view(), name='opponent_update'),
    path('opponents/<int:pk>/delete/', views.OpponentDeleteView.as_view(), name='opponent_delete'),
    path('export/opponents/excel/', views.export_opponents_excel, name='export_opponents_excel'),
    path('export/opponents/pdf/', views.export_opponents_pdf, name='export_opponents_pdf'),
    
    # Sessions
    path('sessions/', views.SessionListView.as_view(), name='sessions'),
    path('sessions/create/', views.SessionCreateView.as_view(), name='session_create'),
    path('sessions/<int:pk>/', views.SessionDetailView.as_view(), name='session_detail'),
    path('sessions/<int:pk>/edit/', views.SessionUpdateView.as_view(), name='session_update'),
    path('sessions/<int:pk>/delete/', views.SessionDeleteView.as_view(), name='session_delete'),
    path('export/sessions/excel/', views.export_sessions_excel, name='export_sessions_excel'),
    path('export/sessions/pdf/', views.export_sessions_pdf, name='export_sessions_pdf'),
    
    # Documents
    path('documents/', views.DocumentListView.as_view(), name='documents'),
    path('documents/upload/', views.DocumentCreateView.as_view(), name='document_upload'),
    
    # Finance
    path('fees/', views.FeeListView.as_view(), name='fees'),
    path('fees/create/', views.FeeCreateView.as_view(), name='fee_create'),
    path('fees/<int:pk>/edit/', views.FeeUpdateView.as_view(), name='fee_update'),
    path('fees/<int:pk>/delete/', views.FeeDeleteView.as_view(), name='fee_delete'),
    
    path('expenses/', views.ExpenseListView.as_view(), name='expenses'),
    path('expenses/create/', views.ExpenseCreateView.as_view(), name='expense_create'),
    path('expenses/<int:pk>/edit/', views.ExpenseUpdateView.as_view(), name='expense_update'),
    path('expenses/<int:pk>/delete/', views.ExpenseDeleteView.as_view(), name='expense_delete'),
    
    path('invoices/', views.InvoiceListView.as_view(), name='invoices'),
    path('invoices/create/', views.InvoiceCreateView.as_view(), name='invoice_create'),
    path('invoices/<int:pk>/edit/', views.InvoiceUpdateView.as_view(), name='invoice_update'),
    path('invoices/<int:pk>/delete/', views.InvoiceDeleteView.as_view(), name='invoice_delete'),
    
    # Tasks
    path('tasks/', views.TaskListView.as_view(), name='tasks'),
    path('tasks/create/', views.TaskCreateView.as_view(), name='task_create'),
    path('tasks/<int:pk>/edit/', views.TaskUpdateView.as_view(), name='task_update'),
    path('tasks/<int:pk>/delete/', views.TaskDeleteView.as_view(), name='task_delete'),
    
    # Appointments
    path('appointments/', views.AppointmentListView.as_view(), name='appointments'),
    path('appointments/create/', views.AppointmentCreateView.as_view(), name='appointment_create'),
    path('appointments/<int:pk>/edit/', views.AppointmentUpdateView.as_view(), name='appointment_update'),
    path('appointments/<int:pk>/delete/', views.AppointmentDeleteView.as_view(), name='appointment_delete'),
    path('calendar/', views.CalendarView.as_view(), name='calendar'),
    
    # Contracts
    path('contracts/', views.ContractListView.as_view(), name='contracts'),
    path('contracts/create/', views.ContractCreateView.as_view(), name='contract_create'),
    path('contracts/<int:pk>/', views.ContractDetailView.as_view(), name='contract_detail'),
    path('contracts/<int:pk>/edit/', views.ContractUpdateView.as_view(), name='contract_update'),
    path('contracts/<int:pk>/delete/', views.ContractDeleteView.as_view(), name='contract_delete'),
    
    # Power of Attorney
    path('power-of-attorney/', views.PowerOfAttorneyListView.as_view(), name='power_of_attorney'),
    path('power-of-attorney/create/', views.PowerOfAttorneyCreateView.as_view(), name='poa_create'),
    path('power-of-attorney/<int:pk>/', views.PowerOfAttorneyDetailView.as_view(), name='poa_detail'),
    path('power-of-attorney/<int:pk>/edit/', views.PowerOfAttorneyUpdateView.as_view(), name='poa_update'),
    path('power-of-attorney/<int:pk>/delete/', views.PowerOfAttorneyDeleteView.as_view(), name='poa_delete'),

    # Consultations & Declarations
    path('consultations/', views.ConsultationListView.as_view(), name='consultations'),
    path('declarations/', views.DeclarationListView.as_view(), name='declarations'),
    path('declarations/create/', views.DeclarationCreateView.as_view(), name='declaration_create'),
    
    # Reports
    path('reports/', views.ReportsView.as_view(), name='reports'),
    path('export/cases/excel/', views.export_cases_excel, name='export_cases_excel'),
    path('export/cases/pdf/', views.export_cases_pdf, name='export_cases_pdf'),
    path('export/contracts/excel/', views.export_contracts_excel, name='export_contracts_excel'),
    path('export/contracts/pdf/', views.export_contracts_pdf, name='export_contracts_pdf'),
    path('export/poa/excel/', views.export_poa_excel, name='export_poa_excel'),
    path('export/poa/pdf/', views.export_poa_pdf, name='export_poa_pdf'),
    
    # Settings
    path('settings/', views.SettingsView.as_view(), name='settings'),
    
    # User Management
    path('users/create/', views.UserCreateView.as_view(), name='user_create'),
    path('users/<int:pk>/edit/', views.UserUpdateView.as_view(), name='user_update'),
    path('users/<int:pk>/delete/', views.UserDeleteView.as_view(), name='user_delete'),

    # API endpoints (للمودالات والطباعة)
    path('api/cases/<int:pk>/', views.case_api_detail, name='case_api_detail'),
    path('api/clients/<int:pk>/', views.client_api_detail, name='client_api_detail'),
    path('api/opponents/<int:pk>/', views.opponent_api_detail, name='opponent_api_detail'),
    path('api/sessions/<int:pk>/', views.session_api_detail, name='session_api_detail'),
    path('api/contracts/<int:pk>/', views.contract_api_detail, name='contract_api_detail'),
    path('api/poa/<int:pk>/', views.poa_api_detail, name='poa_api_detail'),
    path('api/expenses/<int:pk>/', views.expense_api_detail, name='expense_api_detail'),
    path('api/tasks/<int:pk>/', views.task_api_detail, name='task_api_detail'),
    path('api/invoices/<int:pk>/', views.invoice_api_detail, name='invoice_api_detail'),
    path('api/appointments/<int:pk>/', views.appointment_api_detail, name='appointment_api_detail'),

    # Notification APIs
    path('api/notifications/', views.notifications_list_api, name='notifications_list_api'),
    path('api/notifications/<int:pk>/mark-as-read/', views.notification_mark_as_read_api, name='notification_mark_as_read_api'),
    path('api/notifications/mark-all-as-read/', views.notification_mark_all_as_read_api, name='notification_mark_all_as_read_api'),
    path('api/notifications/<int:pk>/delete/', views.notification_delete_api, name='notification_delete_api'),
    
    path('export/fees/excel/', views.export_fees_excel, name='export_fees_excel'),
    path('export/fees/pdf/', views.export_fees_pdf, name='export_fees_pdf'),
    path('export/expenses/excel/', views.export_expenses_excel, name='export_expenses_excel'),
    path('export/expenses/pdf/', views.export_expenses_pdf, name='export_expenses_pdf'),
    path('export/office-expenses/excel/', views.export_office_expenses_excel, name='export_office_expenses_excel'),
    path('export/office-expenses/pdf/', views.export_office_expenses_pdf, name='export_office_expenses_pdf'),
    path('export/invoices/excel/', views.export_invoices_excel, name='export_invoices_excel'),
    path('export/invoices/pdf/', views.export_invoices_pdf, name='export_invoices_pdf'),

    # Theme preference API
    path('core/theme/', views.theme_preference, name='theme_preference'),

    # Desktop close API
    path('core/close/', views.close_desktop_app, name='close_desktop_app'),
]
