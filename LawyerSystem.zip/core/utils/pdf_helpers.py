import logging
import os
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4, landscape
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import mm
from reportlab.lib.enums import TA_RIGHT, TA_CENTER
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import (
    SimpleDocTemplate,
    Table,
    TableStyle,
    Paragraph,
    Spacer,
    Image,
)

logger = logging.getLogger(__name__)

def format_arabic(text):
    """
    Format Arabic text for PDF display using arabic-reshaper and python-bidi.
    """
    if not text:
        return "—"
    
    try:
        import arabic_reshaper
        from bidi.algorithm import get_display
        
        # تحويل النص العربي للعرض الصحيح في PDF
        reshaped = arabic_reshaper.reshape(str(text))
        bidi_text = get_display(reshaped)
        return bidi_text
    except ImportError as e:
        logger.warning(f"[PDF Helper] ⚠️ Arabic libraries not installed: {e}")
        logger.warning("[PDF Helper] Run: pip install arabic-reshaper python-bidi")
        return str(text)
    except Exception as e:
        logger.error(f"[PDF Helper] ❌ Error formatting Arabic text: {e}")
        return str(text)

def font_supports_arabic(font_name):
    """
    Ensure the selected font can render Arabic glyphs before using it.
    """
    try:
        face = pdfmetrics.getFont(font_name).face
        cmap = getattr(face, "charToGlyph", {}) or {}
        # Simple check for common Arabic letters
        required_chars = ("ا", "م", "ل")
        return all(ord(ch) in cmap for ch in required_chars)
    except Exception as e:
        logger.warning(
            f"[PDF Helper] ⚠️ Failed to inspect font glyphs for {font_name}: {e}"
        )
        return False

def register_arabic_font(base_dir, font_name_suggested="CairoRegular"):
    """
    Registers an Arabic-supporting font if not already registered.
    Returns the name of the successfully registered font or 'Helvetica' as fallback.
    """
    # Check if a font is already registered
    registered_fonts = pdfmetrics.getRegisteredFontNames()
    
    # Try to find an already registered font that supports Arabic
    for f in registered_fonts:
        if f not in ["Helvetica", "Times-Roman", "Courier", "Symbol", "ZapfDingbats"]:
            if font_supports_arabic(f):
                return f

    # List of potential font paths in order of preference
    font_paths = [
        os.path.join(base_dir, 'static', 'fonts', 'Cairo-Regular.ttf'),
        os.path.join(base_dir, 'static', 'fonts', 'Amiri-Regular.ttf'),
        os.path.join(base_dir, 'static', 'fonts', 'arial.ttf'),
        "C:/Windows/Fonts/arial.ttf", 
        "C:/Windows/Fonts/tahoma.ttf",
    ]
    
    for font_path in font_paths:
        if os.path.exists(font_path):
            try:
                # Use a unique name for registration based on filename
                f_name = os.path.basename(font_path).replace(".ttf", "").replace("-", "")
                
                # Double check registration
                if f_name not in pdfmetrics.getRegisteredFontNames():
                    pdfmetrics.registerFont(TTFont(f_name, font_path))
                
                if font_supports_arabic(f_name):
                    logger.info(f"[PDF Helper] ✅ Successfully registered Arabic font: {f_name}")
                    return f_name
            except Exception as e:
                logger.warning(f"[PDF Helper] ⚠️ Failed to register font {font_path}: {e}")
                continue
    
    logger.error("[PDF Helper] ❌ No Arabic font was successfully registered!")
    return "Helvetica" # Default fallback


def get_office_info(base_dir):
    """
    Get office name and logo path.
    Returns: (office_name, logo_path or None)
    """
    try:
        from core.models import OfficeProfile
        office = OfficeProfile.objects.first()
        office_name = office.name if office and office.name else "مكتب المحاماة"
        office_logo = None

        if office and office.logo:
            logo_path = str(office.logo)
            office_logo = os.path.join(base_dir, 'media_files', logo_path)

        if not office_logo or not os.path.exists(office_logo):
            static_logo = os.path.join(base_dir, 'static', 'images', 'logo.png')
            if os.path.exists(static_logo):
                office_logo = static_logo

        return office_name, office_logo
    except Exception as e:
        logger.warning(f"[PDF Helper] ⚠️ Failed to get office info: {e}")
        return "مكتب المحاماة", None


def create_pdf_styles(font_name):
    """
    Create paragraph styles for PDF export.
    Returns: (title_style, normal_style, office_style)
    """
    styles = getSampleStyleSheet()

    title_style = ParagraphStyle(
        'Title',
        parent=styles['Heading1'],
        fontSize=16,
        alignment=TA_CENTER,
        fontName=font_name,
        spaceAfter=2 * mm,
    )

    normal_style = ParagraphStyle(
        'Normal',
        parent=styles['Normal'],
        fontSize=10,
        fontName=font_name,
        alignment=TA_RIGHT,
        spaceAfter=2 * mm,
    )

    office_style = ParagraphStyle(
        'Office',
        parent=styles['Heading2'],
        fontSize=13,
        alignment=TA_CENTER,
        fontName=font_name,
        spaceAfter=1 * mm,
    )

    return title_style, normal_style, office_style


def build_pdf_header(story, office_name, office_logo, office_style, title_style, title_text, filter_info=None):
    """
    Build PDF header with logo, office name, title and filters.
    """
    if office_logo and os.path.exists(office_logo):
        try:
            img = Image(office_logo, width=25 * mm, height=25 * mm)
            img.hAlign = TA_CENTER
            story.append(img)
            story.append(Spacer(1, 2 * mm))
        except Exception as e:
            logger.warning(f"[PDF Helper] ⚠️ Could not load logo: {e}")

    story.append(Paragraph(format_arabic(office_name), office_style))
    story.append(Spacer(1, 2 * mm))
    story.append(Paragraph("_" * 50, ParagraphStyle("Line", fontSize=6, alignment=TA_CENTER, fontName=office_style.fontName)))
    story.append(Spacer(1, 2 * mm))
    story.append(Paragraph(title_text, title_style))

    if filter_info:
        story.append(Spacer(1, 3 * mm))
        for f in filter_info:
            story.append(Paragraph(f, title_style))


def create_pdf_table(headers, data_rows, col_widths=None, header_color=colors.HexColor("#4F46E5")):
    """
    Create a PDF table with headers and data.
    Returns: Table object
    """
    if not col_widths:
        col_widths = [None] * len(headers)

    table_data = [headers]

    for row in data_rows:
        table_data.append(row)

    table = Table(table_data, colWidths=col_widths)
    table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), header_color),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("ALIGN", (0, 0), (-1, -1), "CENTER"),
        ("FONTNAME", (0, 0), (-1, -1), headers[0].fontName if hasattr(headers[0], 'fontName') else "Helvetica"),
        ("FONTSIZE", (0, 0), (-1, 0), 10),
        ("FONTSIZE", (0, 1), (-1, -1), 8),
        ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#F0F0F0")]),
    ]))

    return table


def export_pdf_response(buffer, story, request, filename_prefix):
    """
    Build and return PDF response.
    Returns: HttpResponse or JsonResponse
    """
    from django.http import HttpResponse, JsonResponse
    from django.utils import timezone
    import base64

    doc = SimpleDocTemplate(
        buffer,
        pagesize=landscape(A4),
        rightMargin=25 * mm,
        leftMargin=25 * mm,
        topMargin=25 * mm,
        bottomMargin=25 * mm,
    )
    doc.build(story)

    is_desktop = request.headers.get("X-Desktop-Mode") or request.GET.get("desktop")

    if is_desktop:
        content_base64 = base64.b64encode(buffer.getvalue()).decode("utf-8")
        timestamp = timezone.now().strftime("%Y%m%d_%H%M%S")
        return JsonResponse({
            "success": True,
            "filename": f"{filename_prefix}_{timestamp}.pdf",
            "content": content_base64,
            "content_type": "application/pdf"
        })

    response = HttpResponse(buffer.getvalue(), content_type="application/pdf")
    response["Content-Disposition"] = f'attachment; filename="{filename_prefix}_{timezone.now().strftime("%Y%m%d")}.pdf"'
    return response
