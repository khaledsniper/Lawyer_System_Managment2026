# ========================================
# Context Processors - Mizan Al-Adala
# ========================================

import logging

logger = logging.getLogger(__name__)


from django.core.cache import cache

def notification_count(request):
    """
    إضافة عدد الإشعارات غير المقروءة لجميع القوالب مع التخزين المؤقت
    """
    if not request.user.is_authenticated:
        return {'notification_count': 0}
        
    cache_key = f'notification_cnt_{request.user.id}'
    count = cache.get(cache_key)
    
    if count is None:
        try:
            from core.models import Notification
            count = Notification.objects.filter(target_user=request.user, is_read=False).count()
            cache.set(cache_key, count, 60) # 60 seconds cache
        except Exception as e:
            logger.exception(f'Error calculating notification count: {e}')
            count = 0

    return {'notification_count': count}


def office_profile(request):
    """
    إضافة بيانات المكتب (الاسم، الشعار) لجميع القوالب مع التخزين المؤقت
    """
    cache_key = 'global_office_profile'
    profile = cache.get(cache_key)

    if profile is None:
        try:
            from core.models import OfficeProfile
            profile = OfficeProfile.objects.first()
            cache.set(cache_key, profile, 3600*24) # 24 hours cache
        except Exception as e:
            logger.exception(f'Error getting office profile: {e}')
            profile = None

    return {'office_profile': profile}


def user_theme(request):
    """
    إضافة تفضيل المظهر للمستخدم للقوالب.
    يُمرّر مباشرةً من السيرفر لتجنب الوميض عند التحميل.
    """
    theme = 'light'
    if request.user.is_authenticated:
        theme = getattr(request.user, 'theme_preference', 'light') or 'light'
    else:
        theme = request.session.get('theme', 'light')
    return {'user_theme': theme}