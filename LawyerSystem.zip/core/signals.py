"""
إشارات Django للإشعارات التلقائية
"""
from django.db.models.signals import post_save, pre_save, post_delete
from django.dispatch import receiver
from django.utils import timezone
from .models import (
    Session,
    Contract,
    PowerOfAttorney,
    Invoice,
    Task,
    Fee,
    Payment,
    Notification,
    User
)
from django.db.models import Sum


def _notify_admins(message, notification_type):
    """
    إرسال إشعار لجميع مدراء النظام النشطين باستخدام bulk_create لتحسين الأداء.
    """
    admins = User.objects.filter(role='admin', is_active=True)
    if admins.exists():
        notifications = [
            Notification(
                message=message,
                notification_type=notification_type,
                target_user=admin
            ) for admin in admins
        ]
        Notification.objects.bulk_create(notifications)


@receiver(post_save, sender=Session)
def create_session_notification(sender, instance, created, **kwargs):
    """
    إنشاء إشعار عند إضافة جلسة جديدة
    """
    if created:
        _notify_admins(
            message=f'تم إضافة جلسة جديدة للقضية {instance.case.case_number} في {instance.date}',
            notification_type='session'
        )


@receiver(post_save, sender=Task)
def create_task_notification(sender, instance, created, **kwargs):
    """
    إنشاء إشعار عند تعيين مهمة جديدة
    """
    if created and instance.assigned_to:
        Notification.objects.create(
            message=f'تم تعيين مهمة جديدة لك: {instance.title}',
            notification_type='task',
            target_user=instance.assigned_to
        )


@receiver(post_save, sender=Invoice)
def create_invoice_notification(sender, instance, created, **kwargs):
    """
    إنشاء إشعار عند إنشاء فاتورة جديدة
    """
    if created:
        _notify_admins(
            message=f'تم إنشاء فاتورة جديدة رقم {instance.invoice_number}',
            notification_type='payment'
        )


@receiver(pre_save, sender=Contract)
def check_contract_expiry(sender, instance, **kwargs):
    """
    التحقق من انتهاء العقد وتغيير الحالة تلقائياً
    """
    if instance.pk:  # فقط عند التحديث
        try:
            old_instance = Contract.objects.get(pk=instance.pk)
            if old_instance.status == 'active' and instance.end_date < timezone.now().date():
                instance.status = 'expired'
        except Contract.DoesNotExist:
            pass


@receiver(pre_save, sender=PowerOfAttorney)
def check_poa_expiry(sender, instance, **kwargs):
    """
    التحقق من انتهاء الوكالة وتغيير الحالة تلقائياً
    """
    if instance.pk:  # فقط عند التحديث
        try:
            old_instance = PowerOfAttorney.objects.get(pk=instance.pk)
            if old_instance.status == 'active' and instance.expiry_date < timezone.now().date():
                instance.status = 'expired'
        except PowerOfAttorney.DoesNotExist:
            pass


@receiver(post_save, sender=Contract)
def create_contract_expiry_notification(sender, instance, **kwargs):
    """
    إنشاء إشعار عند قرب انتهاء العقد (أقل من 30 يوم)
    """
    if instance.status == 'active' and instance.end_date:
        days_until_expiry = (instance.end_date - timezone.now().date()).days
        if 0 <= days_until_expiry <= 30:
            # تحقق من عدم إنشاء إشعار مسبقاً اليوم
            existing = Notification.objects.filter(
                message__contains=f'العقد {instance.contract_number}',
                created_at__date=timezone.now().date()
            ).exists()

            if not existing:
                _notify_admins(
                    message=f'⚠️ العقد {instance.contract_number} سينتهي خلال {days_until_expiry} يوم',
                    notification_type='contract'
                )


@receiver(post_save, sender=PowerOfAttorney)
def create_poa_expiry_notification(sender, instance, **kwargs):
    """
    إنشاء إشعار عند قرب انتهاء الوكالة (أقل من 30 يوم).
    يستخدم update_fields لمنع الحلقة اللانهائية.
    """
    if instance.status in ['active', 'expiring_soon'] and instance.expiry_date:
        days_until_expiry = (instance.expiry_date - timezone.now().date()).days
        if 0 <= days_until_expiry <= 30:
            # تحديث الحالة المباشر باستخدام update() لتجنب إعادة تشغيل الـ signal
            if instance.status != 'expiring_soon':
                PowerOfAttorney.objects.filter(pk=instance.pk).update(status='expiring_soon')

            # تحقق من عدم إنشاء إشعار مسبقاً اليوم
            existing = Notification.objects.filter(
                message__contains=f'وكالة {instance.client.full_name}',
                created_at__date=timezone.now().date()
            ).exists()

            if not existing:
                _notify_admins(
                    message=f'⚠️ وكالة {instance.client.full_name} ستنتهي خلال {days_until_expiry} يوم',
                    notification_type='contract'
                )


@receiver([post_save, post_delete], sender=Session)
def update_case_next_session(sender, instance, **kwargs):
    """
    تحديث حقل next_session_date في نموذج Case تلقائياً عند إضافة أو تعديل أو حذف جلسة.
    يتم اختيار أقرب جلسة مجدولة (status='scheduled') في التاريخ الحالي أو لاحقاً.
    """
    case = instance.case
    # البحث عن أقرب جلسة مجدولة بدءاً من اليوم
    next_session = Session.objects.filter(
        case=case,
        status='scheduled',
        date__gte=timezone.now().date()
    ).order_by('date', 'time').first()

    if next_session:
        # تحديث التاريخ إذا وجدنا جلسة قادمة
        if case.next_session_date != next_session.date:
            case.next_session_date = next_session.date
            case.save(update_fields=['next_session_date'])
    else:
        # إذا لم توجد جلسات قادمة، نمسح الحقل
        if case.next_session_date is not None:
            case.next_session_date = None
            case.save(update_fields=['next_session_date'])


@receiver([post_save, post_delete], sender=Payment)
def update_fee_status(sender, instance, **kwargs):
    """
    تحديث حالة الأتعاب (Fee) تلقائياً بناءً على إجمالي الدفعات المسجلة.
    """
    fee = instance.fee
    # حساب إجمالي المبالغ المدفوعة لهذا النوع من الأتعاب
    total_paid = fee.payments.aggregate(total=Sum('amount'))['total'] or 0
    
    # تحديد الحالة الجديدة بناءً على المبلغ المتفق عليه
    if total_paid >= fee.agreed_amount:
        new_status = 'paid'
    elif total_paid > 0:
        new_status = 'partial'
    else:
        new_status = 'pending'
    
    # تحديث الحقل فقط إذا تغيرت الحالة لتجنب الـ Recursion إذا كان هناك Signals أخرى
    if fee.status != new_status:
        fee.status = new_status
        fee.save(update_fields=['status'])


@receiver(post_save, sender=Fee)
def sync_fee_status_on_update(sender, instance, created, **kwargs):
    """
    تأكيد مزامنة حالة الأتعاب عند تغيير المبلغ المتفق عليه (agreed_amount) يدوياً.
    """
    if not created:  # فقط عند التحديث
        # استدعاء نفس منطق تحديث الحالة
        total_paid = instance.payments.aggregate(total=Sum('amount'))['total'] or 0
        
        if total_paid >= instance.agreed_amount:
            new_status = 'paid'
        elif total_paid > 0:
            new_status = 'partial'
        else:
            new_status = 'pending'
            
        if instance.status != new_status:
            Fee.objects.filter(pk=instance.pk).update(status=new_status)


