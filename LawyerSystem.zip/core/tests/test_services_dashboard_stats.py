from datetime import timedelta
from decimal import Decimal

from django.test import TestCase
from django.utils import timezone

from core.models import (
    Appointment,
    Case,
    Client,
    Contract,
    Expense,
    Fee,
    Invoice,
    Payment,
    Task,
)
from core.services.dashboard_stats import (
    get_appointment_stats,
    get_cases_stats,
    get_client_stats,
    get_contract_stats,
    get_finance_stats,
    get_invoice_stats,
    get_task_stats,
)


class DashboardStatsServiceTests(TestCase):
    def _create_client(self, full_name='Client'):
        return Client.objects.create(full_name=full_name)

    def _create_case(self, client, case_number='CASE-1', subject='Subject'):
        return Case.objects.create(
            case_number=case_number,
            subject=subject,
            client=client,
        )

    def test_case_and_client_stats(self):
        client = self._create_client()
        self._create_case(client, case_number='C-1')
        self._create_case(client, case_number='C-2')

        case_stats = get_cases_stats()
        client_stats = get_client_stats()

        self.assertEqual(case_stats['total'], 2)
        self.assertEqual(client_stats['total'], 1)

    def test_task_stats(self):
        Task.objects.create(title='T1', status='new')
        Task.objects.create(title='T2', status='in_progress')
        Task.objects.create(title='T3', status='done')
        Task.objects.create(
            title='T4',
            status='new',
            due_date=timezone.now().date() - timedelta(days=1),
        )

        stats = get_task_stats()

        self.assertEqual(stats['total'], 4)
        self.assertEqual(stats['new'], 2)
        self.assertEqual(stats['in_progress'], 1)
        self.assertEqual(stats['done'], 1)
        self.assertEqual(stats['overdue'], 1)

    def test_appointment_stats(self):
        now = timezone.now()
        Appointment.objects.create(datetime=now + timedelta(days=1), status='scheduled')
        Appointment.objects.create(datetime=now - timedelta(days=1), status='completed')

        stats = get_appointment_stats()

        self.assertEqual(stats['total'], 2)
        self.assertEqual(stats['completed'], 1)
        self.assertEqual(stats['upcoming'], 1)

    def test_contract_stats(self):
        client = self._create_client()
        today = timezone.now().date()
        Contract.objects.create(
            contract_number='CN-1',
            type='A',
            client=client,
            start_date=today,
            end_date=today + timedelta(days=10),
            status='active',
        )
        Contract.objects.create(
            contract_number='CN-2',
            type='B',
            client=client,
            start_date=today,
            end_date=today + timedelta(days=60),
            status='active',
        )
        Contract.objects.create(
            contract_number='CN-3',
            type='C',
            client=client,
            start_date=today,
            end_date=today - timedelta(days=1),
            status='expired',
        )

        stats = get_contract_stats()

        self.assertEqual(stats['total_invoices'], 3)
        self.assertEqual(stats['active'], 2)
        self.assertEqual(stats['expiring'], 1)

    def test_invoice_stats(self):
        client = self._create_client()
        today = timezone.now().date()
        Invoice.objects.create(client=client, subtotal=Decimal('100'), status='paid', date=today)
        Invoice.objects.create(client=client, subtotal=Decimal('200'), status='pending', date=today)
        Invoice.objects.create(client=client, subtotal=Decimal('50'), status='cancelled', date=today)

        stats = get_invoice_stats()

        self.assertEqual(stats['total'], 3)
        self.assertEqual(stats['paid'], 1)
        self.assertEqual(stats['pending'], 1)
        self.assertEqual(stats['cancelled'], 1)
        self.assertEqual(stats['total_paid_amount'], Decimal('114.00'))
        self.assertEqual(stats['total_pending_amount'], Decimal('228.00'))

    def test_finance_stats(self):
        client = self._create_client()
        case = self._create_case(client, case_number='C-100')
        fee = Fee.objects.create(case=case, agreed_amount=Decimal('500'))
        Payment.objects.create(amount=Decimal('200'), date=timezone.now().date(), fee=fee)
        Expense.objects.create(
            description='Expense',
            amount=Decimal('50'),
            date=timezone.now().date(),
            case=case,
        )

        stats = get_finance_stats()

        self.assertEqual(stats['total_fees'], Decimal('500'))
        self.assertEqual(stats['total_collected'], Decimal('200'))
        self.assertEqual(stats['total_expenses'], Decimal('50'))
        self.assertEqual(stats['net_profit'], Decimal('150'))
