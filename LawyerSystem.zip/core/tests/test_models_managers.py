from decimal import Decimal

from django.test import TestCase
from django.utils import timezone

from core.models import (
    Case,
    Client,
    Expense,
    Fee,
    Invoice,
    OfficeProfile,
    Payment,
)


class ManagerStatsTests(TestCase):
    def _create_client(self, full_name='Client', client_type='individual', status='active'):
        return Client.objects.create(
            full_name=full_name,
            type=client_type,
            status=status,
        )

    def _create_case(self, client, case_number='C-1', status='active'):
        return Case.objects.create(
            case_number=case_number,
            subject='Subject',
            client=client,
            status=status,
        )

    def test_client_manager_statistics(self):
        self._create_client(full_name='A', client_type='individual', status='active')
        self._create_client(full_name='B', client_type='company', status='inactive')

        stats = Client.objects.get_statistics()

        self.assertEqual(stats['total'], 2)
        self.assertEqual(stats['individual'], 1)
        self.assertEqual(stats['company'], 1)
        self.assertEqual(stats['active'], 1)

    def test_case_manager_statistics(self):
        client = self._create_client()
        self._create_case(client, case_number='C-1', status='active')
        self._create_case(client, case_number='C-2', status='pending')
        self._create_case(client, case_number='C-3', status='won')
        self._create_case(client, case_number='C-4', status='lost')
        self._create_case(client, case_number='C-5', status='closed')

        stats = Case.objects.get_statistics()

        self.assertEqual(stats['total'], 5)
        self.assertEqual(stats['active'], 1)
        self.assertEqual(stats['pending'], 1)
        self.assertEqual(stats['won'], 1)
        self.assertEqual(stats['lost'], 1)
        self.assertEqual(stats['closed'], 1)

    def test_fee_manager_financial_summary(self):
        client = self._create_client()
        case = self._create_case(client, case_number='C-100')
        fee1 = Fee.objects.create(case=case, agreed_amount=Decimal('100'))
        fee2 = Fee.objects.create(case=case, agreed_amount=Decimal('200'))
        Payment.objects.create(amount=Decimal('50'), date=timezone.now().date(), fee=fee1)
        Payment.objects.create(amount=Decimal('100'), date=timezone.now().date(), fee=fee2)
        Expense.objects.create(description='Expense', amount=Decimal('30'), date=timezone.now().date(), case=case)

        stats = Fee.objects.get_financial_summary()

        self.assertEqual(stats['total_fees'], Decimal('300'))
        self.assertEqual(stats['total_collected'], Decimal('150'))
        self.assertEqual(stats['total_expenses'], Decimal('30'))
        self.assertEqual(stats['net_profit'], Decimal('120'))


class ModelBehaviorTests(TestCase):
    def test_client_id_auto_generated(self):
        client = Client.objects.create(full_name='Auto ID')
        self.assertTrue(client.client_id.startswith('CLT-'))

        another = Client.objects.create(full_name='Auto ID 2')
        self.assertNotEqual(client.client_id, another.client_id)

    def test_invoice_save_computes_totals_and_number(self):
        OfficeProfile.objects.create(name='Office', default_tax_rate=Decimal('10'))
        client = Client.objects.create(full_name='Invoice Client')
        today = timezone.now().date()

        invoice = Invoice.objects.create(
            client=client,
            subtotal=Decimal('100'),
            status='paid',
            date=today,
        )

        self.assertEqual(invoice.tax_rate, Decimal('10'))
        self.assertEqual(invoice.tax_amount, Decimal('10.00'))
        self.assertEqual(invoice.total, Decimal('110.00'))
        self.assertTrue(invoice.invoice_number.startswith(f'INV-{today.year}-'))

