from django.contrib.auth import get_user_model
from django.test import TestCase
from django.urls import reverse

from core.models import Case, Client


class IntegrationViewsTests(TestCase):
    def setUp(self):
        user_model = get_user_model()
        self.user = user_model.objects.create_user(
            username='tester',
            password='testpass123',
        )
        self.client.force_login(self.user)

    def _create_client(self, full_name='Client'):
        return Client.objects.create(full_name=full_name)

    def _create_case(self, client, case_number='C-1'):
        return Case.objects.create(
            case_number=case_number,
            subject='Subject',
            client=client,
        )

    def test_dashboard_page_loads(self):
        response = self.client.get(reverse('core:dashboard'))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'الرئيسية', status_code=200)

    def test_cases_page_loads(self):
        client = self._create_client()
        self._create_case(client, case_number='C-100')
        response = self.client.get(reverse('core:cases'))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'C-100', status_code=200)

    def test_clients_page_loads(self):
        self._create_client(full_name='Client One')
        response = self.client.get(reverse('core:clients'))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'Client One', status_code=200)

    def test_reports_page_loads(self):
        response = self.client.get(reverse('core:reports'))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'التقارير', status_code=200)

