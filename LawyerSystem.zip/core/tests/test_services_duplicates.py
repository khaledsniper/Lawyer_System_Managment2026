from django.test import TestCase

from core.models import Case, Client
from core.services.duplicates import check_case_duplicate, check_client_duplicate


class DuplicateChecksTests(TestCase):
    def _create_client(self, full_name='Test Client', phone='', national_id=''):
        return Client.objects.create(
            full_name=full_name,
            phone=phone,
            national_id=national_id,
        )

    def _create_case(self, client, case_number='CASE-1', subject='Subject'):
        return Case.objects.create(
            case_number=case_number,
            subject=subject,
            client=client,
        )

    def test_case_duplicate_by_case_number(self):
        client = self._create_client()
        self._create_case(client, case_number='C-100')

        result = check_case_duplicate(case_number='C-100', client_id='', pk=None)

        self.assertTrue(result['duplicate'])
        self.assertEqual(result['field'], 'case_number')

    def test_case_duplicate_by_client_info(self):
        client = self._create_client()
        self._create_case(client, case_number='C-101')

        result = check_case_duplicate(case_number='', client_id=str(client.id), pk=None)

        self.assertTrue(result['info'])
        self.assertEqual(result['client_cases_count'], 1)

    def test_client_duplicate_by_full_name(self):
        self._create_client(full_name='Same Name')

        result = check_client_duplicate(full_name='Same Name', phone='', national_id='', pk=None)

        self.assertTrue(result['duplicate'])
        self.assertEqual(result['field'], 'full_name')

    def test_client_duplicate_by_phone(self):
        self._create_client(full_name='Phone Owner', phone='0100')

        result = check_client_duplicate(full_name='', phone='0100', national_id='', pk=None)

        self.assertTrue(result['duplicate'])
        self.assertEqual(result['field'], 'phone')

    def test_client_duplicate_by_national_id(self):
        self._create_client(full_name='ID Owner', national_id='12345678901234')

        result = check_client_duplicate(full_name='', phone='', national_id='12345678901234', pk=None)

        self.assertTrue(result['duplicate'])
        self.assertEqual(result['field'], 'national_id')

