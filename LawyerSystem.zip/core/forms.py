"""
Forms for the core app.
"""

import re

from django import forms
from django.core.exceptions import ValidationError
from django.db.models import Q
from .models.legal import (
    Contract,
    PowerOfAttorney,
    ContractStatus,
    ContractType,
    PowerOfAttorneyType,
)
from .models import Appointment, Case, Client, Opponent, Session, Task, Court, Expense


class BaseRTLModelForm(forms.ModelForm):
    """
    نماذج أساسية تدعم التوجه من اليمين لليسار (RTL) وتصميم Bootstrap
    """

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for field_name, field in self.fields.items():
            current_class = field.widget.attrs.get("class", "")

            if isinstance(field.widget, (forms.Select, forms.SelectMultiple)):
                if "form-select" not in current_class:
                    field.widget.attrs["class"] = (
                        current_class + " form-select"
                    ).strip()
            elif isinstance(
                field.widget, (forms.CheckboxInput, forms.CheckboxSelectMultiple)
            ):
                if "form-check-input" not in current_class:
                    field.widget.attrs["class"] = (
                        current_class + " form-check-input"
                    ).strip()
            else:
                if "form-control" not in current_class:
                    field.widget.attrs["class"] = (
                        current_class + " form-control"
                    ).strip()

            field.widget.attrs.update(
                {
                    "dir": "rtl",
                }
            )


class CaseForm(BaseRTLModelForm):
    custom_opponent = forms.CharField(
        required=False,
        widget=forms.TextInput(
            attrs={
                "placeholder": "أضف خصم جديد",
            }
        ),
        label="خصم آخر (غير مسجل)",
    )

    next_session_date = forms.DateField(
        required=False,
        input_formats=["%d/%m/%Y", "%Y-%m-%d"],
        widget=forms.TextInput(
            attrs={
                "placeholder": "dd/mm/yyyy",
                "autocomplete": "off",
                "data-date-format": "dd/mm/yyyy",
                "class": "form-control",
                "dir": "ltr",
            }
        ),
        label="تاريخ الجلسة القادمة",
    )

    class Meta:
        model = Case
        fields = [
            "case_number",
            "case_year",
            "subject",
            "case_type",
            "client",
            "opponents",
            "court",
            "status",
            "priority",
            "position",
            "next_session_date",
            "notes",
        ]
        widgets = {
            "case_year": forms.Select(choices=[(y, y) for y in range(2000, 2101)]),
            "notes": forms.Textarea(attrs={"rows": 3}),
        }
        labels = {
            "case_number": "رقم القضية",
            "case_year": "السنة",
            "subject": "موضوع القضية",
            "client": "العميل",
            "opponents": "الخصوم",
            "court": "المحكمة",
            "case_type": "نوع القضية",
            "status": "الحالة",
            "priority": "الأولوية",
            "position": "موقف المكتب",
            "next_session_date": "تاريخ الجلسة القادمة",
            "notes": "ملاحظات",
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["court"].empty_label = "اختر المحكمة"

        # تعيين السنة الحالية كقيمة افتراضية لحقل السنة
        from datetime import date

        current_year = date.today().year
        if not self.instance.pk and not self.data:  # فقط في حالة الإضافة وليس التعديل
            self.initial["case_year"] = current_year

        self.order_fields(
            [
                "case_number",
                "case_year",
                "subject",
                "case_type",
                "client",
                "opponents",
                "custom_opponent",
                "court",
                "status",
                "priority",
                "position",
                "next_session_date",
                "notes",
            ]
        )

    def clean_case_number(self):
        case_number = self.cleaned_data.get("case_number")
        if case_number:
            instance = getattr(self, "instance", None)
            qs = Case.objects.filter(case_number=case_number)
            if instance and instance.pk:
                qs = qs.exclude(pk=instance.pk)
            if qs.exists():
                existing = qs.first()
                client_name = (
                    existing.client.full_name
                    if existing and existing.client
                    else "غير محدد"
                )
                raise ValidationError(
                    f'⚠️ رقم القضية "{case_number}" مستخدم بالفعل للعميل: {client_name}'
                )
        return case_number

    def clean(self):
        cleaned_data = super().clean()
        client = cleaned_data.get("client")
        subject = cleaned_data.get("subject")

        if client and subject:
            instance = getattr(self, "instance", None)
            qs = Case.objects.filter(client=client, subject__iexact=subject)
            if instance and instance.pk:
                qs = qs.exclude(pk=instance.pk)
            if qs.exists():
                existing = qs.first()
                case_num = existing.case_number if existing else "غير محدد"
                self.add_error(
                    "subject",
                    f"⚠️ يوجد بالفعل قضية بنفس الموضوع لهذا العميل (رقم القضية: {case_num})",
                )

        return cleaned_data

    def save(self, commit=True):
        case = super().save(commit=commit)
        custom_opponent = self.cleaned_data.get("custom_opponent")
        if custom_opponent:
            if commit:
                opponent, _ = Opponent.objects.get_or_create(name=custom_opponent)
                case.opponents.add(opponent)
            else:
                old_save_m2m = self.save_m2m

                def new_save_m2m():
                    old_save_m2m()
                    opponent, _ = Opponent.objects.get_or_create(name=custom_opponent)
                    case.opponents.add(opponent)

                self.save_m2m = new_save_m2m
        return case


class ClientForm(BaseRTLModelForm):
    class Meta:
        model = Client
        fields = [
            "full_name",
            "national_id",
            "commercial_register",
            "tax_card",
            "phone",
            "additional_phone",
            "job",
            "type",
            "status",
            "address",
            "notes",
        ]
        widgets = {
            "full_name": forms.TextInput(attrs={"placeholder": "الاسم الكامل"}),
            "national_id": forms.TextInput(
                attrs={
                    "placeholder": "14 رقم",
                    "maxlength": "14",
                    "pattern": "[0-9]{14}",
                    "title": "الرقم القومي يجب أن يتكون من 14 رقماً",
                }
            ),
            "commercial_register": forms.TextInput(
                attrs={"placeholder": "رقم السجل التجاري"}
            ),
            "tax_card": forms.TextInput(attrs={"placeholder": "رقم البطاقة الضريبية"}),
            "phone": forms.TextInput(attrs={"placeholder": "رقم الهاتف"}),
            "additional_phone": forms.TextInput(attrs={"placeholder": "رقم إضافي"}),
            "job": forms.TextInput(attrs={"placeholder": "الوظيفة"}),
            "status": forms.Select(),
            "address": forms.Textarea(attrs={"rows": 2}),
            "notes": forms.Textarea(attrs={"rows": 2}),
        }

    def clean_full_name(self):
        full_name = self.cleaned_data.get("full_name", "").strip()
        if full_name:
            instance = getattr(self, "instance", None)
            qs = Client.objects.filter(full_name__iexact=full_name)
            if instance and instance.pk:
                qs = qs.exclude(pk=instance.pk)
            if qs.exists():
                existing = qs.first()
                phone = existing.phone or "غير محدد"
                raise ValidationError(
                    f"⚠️ يوجد عميل بنفس الاسم بالفعل (الهاتف: {phone})"
                )
        return full_name

    def clean_phone(self):
        phone = self.cleaned_data.get("phone")
        if phone:
            phone = re.sub(r"[^\d+]", "", phone)
            instance = getattr(self, "instance", None)
            qs = Client.objects.filter(phone=phone)
            if instance and instance.pk:
                qs = qs.exclude(pk=instance.pk)
            if qs.exists():
                existing = qs.first()
                full_name = existing.full_name if existing else "غير محدد"
                raise ValidationError(f"⚠️ رقم الهاتف مسجل بالفعل للعميل: {full_name}")
        return phone

    def clean_additional_phone(self):
        phone = self.cleaned_data.get("additional_phone")
        if phone:
            phone = re.sub(r"[^\d+]", "", phone)
        return phone

    def clean_national_id(self):
        national_id = self.cleaned_data.get("national_id")
        if not national_id:
            return national_id

        # التحقق من الرقم القومي فقط إذا كان النوع فرد
        client_type = self.data.get("type") or self.initial.get("type")
        if client_type == "company":
            return national_id

        national_id = national_id.replace(" ", "").replace("-", "")
        if not national_id.isdigit():
            raise ValidationError("الرقم القومي يجب أن يحتوي على أرقام فقط")
        if len(national_id) != 14:
            raise ValidationError("الرقم القومي يجب أن يكون 14 رقماً")
        instance = getattr(self, "instance", None)
        qs = Client.objects.filter(national_id=national_id)
        if instance and instance.pk:
            qs = qs.exclude(pk=instance.pk)
        if qs.exists():
            existing = qs.first()
            full_name = existing.full_name if existing else "غير محدد"
            raise ValidationError(f"⚠️ الرقم القومي مسجل بالفعل للعميل: {full_name}")
        return national_id

    def clean(self):
        cleaned_data = super().clean()
        client_type = cleaned_data.get("type")

        # التأكد من إدخال بيانات الهوية حسب النوع
        if client_type == "individual":
            if not cleaned_data.get("national_id"):
                self.add_error("national_id", "الرقم القومي مطلوب للأفراد")
        elif client_type == "company":
            if not cleaned_data.get("commercial_register"):
                self.add_error("commercial_register", "السجل التجاري مطلوب للشركات")

        return cleaned_data


class ExpenseForm(BaseRTLModelForm):
    date = forms.DateField(
        input_formats=["%d/%m/%Y", "%Y-%m-%d"],
        widget=forms.DateInput(
            format="%d/%m/%Y",
            attrs={
                "data-datepicker": "true",
                "placeholder": "dd/mm/yyyy",
                "dir": "ltr",
            },
        ),
        label="التاريخ",
    )

    class Meta:
        model = Expense
        fields = [
            "description",
            "category",
            "amount",
            "case",
            "receipt",
            "receipt_number",
            "payment_method",
            "date",
            "notes",
        ]
        widgets = {
            "description": forms.TextInput(attrs={"placeholder": "مثال: رسوم تسجيل، أمانة خبير..."}),
            "amount": forms.NumberInput(attrs={
                "step": "1", 
                "min": "0",
                "placeholder": "0",
                "inputmode": "numeric",
                "class": "no-spinners"
            }),
            "receipt_number": forms.TextInput(attrs={"placeholder": "رقم الإيصال الورقي"}),
            "payment_method": forms.Select(choices=[
                ('', 'اختر طريقة الدفع'),
                ('cash', 'نقدي'),
                ('bank_transfer', 'تحويل بنكي'),
                ('wallet', 'محفظة كاش'),
            ]),
            "notes": forms.Textarea(attrs={
                "rows": 3,
                "placeholder": "أضف ملاحظات إضافية هنا..."
            })
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        
        # تحديد نوع المصروف
        expense_type = self.initial.get('expense_type') or (self.instance and self.instance.expense_type) or 'case'
        
        # Override category choices based on expense type
        if expense_type == 'office':
            # فئات مصروفات المكتب
            office_choices = [
                ('', 'اختر نوع المصروف'),
                ('rent', 'الإيجار الشهري'),
                ('salaries', 'رواتب وعمالة'),
                ('invoices', 'فواتير'),
                ('maintenance', 'صيانة'),
                ('office_supplies', 'مستلزمات مكتبية'),
                ('hospitality', 'ضيافة ومشروبات'),
                ('cleaning', 'أدوات نظافة'),
                ('other', 'أخرى'),
            ]
            self.fields["category"].choices = office_choices
        else:
            # فئات مصروفات القضايا (الافتراضية)
            original_choices = [c for c in self.fields["category"].choices if c[0]]
            self.fields["category"].choices = [('', 'اختر نوع المصروف')] + original_choices
        
        if not self.instance.pk:
            self.initial["category"] = ''
            
        self.fields["case"].empty_label = "بدون قضية"
        self.fields["description"].label = "البيان"
        self.fields["amount"].label = "المبلغ"
        
        # إذا كان مصروف قضية، نجعل حقل القضية مطلوباً
        if expense_type == 'case':
             self.fields["case"].required = True
             self.fields["case"].label = "القضية المرتبطة"
        else:
             self.fields["case"].required = False
             self.fields["case"].label = "القضية (اختياري)"


class SessionForm(BaseRTLModelForm):
    class Meta:
        model = Session
        fields = [
            "case",
            "court",
            "date",
            "time",
            "session_type",
            "status",
            "minutes",
            "attachments",
        ]
        field_order = [
            "case",
            "court",
            "date",
            "time",
            "session_type",
            "status",
            "minutes",
            "attachments",
        ]
        widgets = {
            "date": forms.DateInput(
                attrs={
                    "class": "form-control",
                    "data-datepicker": "true",
                    "placeholder": "dd/mm/yyyy",
                }
            ),
            "time": forms.TimeInput(
                attrs={
                    "class": "form-control",
                    "data-timepicker": "true",
                    "placeholder": "hh:mm",
                }
            ),
            "minutes": forms.Textarea(attrs={"rows": 4}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        # تخصيص الحقول
        self.fields["court"].empty_label = "اختر المحكمة"

        # تصنيف المحاكم: النشطة أولاً، ثم_nonactive في النهاية
        active_courts = Court.objects.filter(is_active=True).order_by("name")
        # في حالة التعديل، نسمح بجميع المحاكم لتجنب أخطاء التحقق إذا كانت المحكمة غير نشطة
        if self.instance and self.instance.pk:
            self.fields["court"].queryset = Court.objects.all().order_by("-is_active", "name")
        else:
            self.fields["court"].queryset = active_courts

        self.fields["session_type"].empty_label = "اختر نوع الجلسة"

        # ترتيب حالات الجلسة ليطابق الفلاتر
        self.fields["status"].choices = [
            ("scheduled", "مجدولة"),
            ("completed", "مكتملة"),
            ("cancelled", "ملغاة"),
            ("postponed", "مؤجلة"),
        ]

        # تسميات الحقول
        self.fields["case"].label = "القضية*"
        self.fields["date"].label = "التاريخ*"
        self.fields["minutes"].label = "محضر الجلسة"
        self.fields["attachments"].label = "إضافة مرفقات"


class TaskForm(BaseRTLModelForm):
    class Meta:
        model = Task
        fields = [
            "title",
            "description",
            "case",
            "assigned_to",
            "status",
            "priority",
            "due_date",
        ]
        widgets = {
            "title": forms.TextInput(attrs={"placeholder": "عنوان المهمة"}),
            "description": forms.Textarea(attrs={"rows": 3}),
            "due_date": forms.DateInput(
                attrs={
                    "class": "form-control",
                    "data-datepicker": "true",
                    "placeholder": "dd/mm/yyyy",
                }
            ),
        }


class AppointmentForm(BaseRTLModelForm):
    class Meta:
        model = Appointment
        fields = ["type", "client", "location", "datetime", "status", "case"]
        widgets = {
            "location": forms.TextInput(attrs={"placeholder": "مكان الموعد"}),
            "datetime": forms.DateTimeInput(attrs={"type": "datetime-local"}),
        }


class ContractForm(BaseRTLModelForm):
    start_date = forms.DateField(
        input_formats=["%d/%m/%Y", "%Y-%m-%d"],
        widget=forms.DateInput(
            format="%d/%m/%Y",
            attrs={
                "data-datepicker": "true",
                "placeholder": "dd/mm/yyyy",
                "dir": "ltr",
            },
        ),
        label="تاريخ البدء",
    )
    end_date = forms.DateField(
        input_formats=["%d/%m/%Y", "%Y-%m-%d"],
        widget=forms.DateInput(
            format="%d/%m/%Y",
            attrs={
                "data-datepicker": "true",
                "placeholder": "dd/mm/yyyy",
                "dir": "ltr",
            },
        ),
        label="تاريخ الانتهاء",
    )
    value = forms.IntegerField(
        min_value=0,
        label="القيمة",
        widget=forms.NumberInput(
            attrs={
                "step": "1",
                "min": "0",
                "inputmode": "numeric",
                "class": "contract-value-input",
            }
        ),
    )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["status"].choices = ContractStatus.choices
        self.fields["type"].choices = ContractType.choices

    class Meta:
        model = Contract
        fields = [
            "contract_number",
            "type",
            "client",
            "value",
            "start_date",
            "end_date",
            "status",
            "contract_images",
            "notes",
        ]
        widgets = {
            "contract_images": forms.FileInput(
                attrs={
                    "accept": "image/*",
                    "class": "form-control d-none",
                    "id": "id_contract_image_field",
                    "data-preview-target": "contractImagePreview",
                    "data-container-target": "contractImagePreviewContainer",
                    "data-name-target": "contractImageNameDisplay",
                }
            ),
            "notes": forms.Textarea(attrs={"rows": 3}),
        }


class PowerOfAttorneyForm(BaseRTLModelForm):
    issue_date = forms.DateField(
        input_formats=["%d/%m/%Y", "%Y-%m-%d"],
        widget=forms.DateInput(
            format="%d/%m/%Y",
            attrs={
                "data-datepicker": "true",
                "placeholder": "dd/mm/yyyy",
                "dir": "ltr",
            },
        ),
        label="تاريخ الإصدار",
    )
    expiry_date = forms.DateField(
        input_formats=["%d/%m/%Y", "%Y-%m-%d"],
        widget=forms.DateInput(
            format="%d/%m/%Y",
            attrs={
                "data-datepicker": "true",
                "placeholder": "dd/mm/yyyy",
                "dir": "ltr",
            },
        ),
        label="تاريخ الانتهاء",
    )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["type"].choices = PowerOfAttorneyType.choices

    class Meta:
        model = PowerOfAttorney
        fields = [
            "client",
            "type",
            "issue_date",
            "expiry_date",
            "issuer",
            "status",
            "poa_images",
            "notes",
        ]
        widgets = {
            "poa_images": forms.FileInput(
                attrs={
                    "accept": "image/*",
                    "class": "form-control d-none",
                    "id": "id_poa_image_field",
                    "data-preview-target": "poaImagePreview",
                    "data-container-target": "poaImagePreviewContainer",
                    "data-name-target": "poaImageNameDisplay",
                }
            ),
            "notes": forms.Textarea(attrs={"rows": 3}),
        }
