"""
Management Command للإشعارات اليومية التلقائية
- تذكير بالجلسات خلال 24 ساعة
- تذكير بالعقود والوكالات المنتهية
- تحديث حالة العقود والوكالات المنتهية
"""
from datetime import date, timedelta
from django.core.management.base import BaseCommand
from core.models import (
    Session,
    Contract,
    PowerOfAttorney,
    Invoice,
    Task,
    Notification,
    User
)


class Command(BaseCommand):
    help = 'إرسال الإشعارات اليومية وتحديث الحالات التلقائية'

    def handle(self, *args, **kwargs):
        self.stdout.write('🔄 بدء تنفيذ المهام اليومية التلقائية...')
        
        # 1. إشعارات الجلسات خلال 24 ساعة
        self.notify_upcoming_sessions()
        
        # 2. تحديث حالة العقود المنتهية
        self.update_expired_contracts()
        
        # 3. تحديث حالة الوكالات المنتهية
        self.update_expired_poas()
        
        # 4. إشعارات العقود التي ستنتهي خلال 30 يوم
        self.notify_expiring_contracts()
        
        # 5. إشعارات الوكالات التي ستنتهي خلال 30 يوم
        self.notify_expiring_poas()
        
        # 6. إشعارات المهام المتأخرة
        self.notify_overdue_tasks()
        
        # 7. إشعارات الفواتير غير المدفوعة
        self.notify_unpaid_invoices()
        
        self.stdout.write(self.style.SUCCESS('✅ اكتملت المهام اليومية التلقائية'))

    def notify_upcoming_sessions(self):
        """إشعارات الجلسات خلال 24 ساعة"""
        tomorrow = date.today() + timedelta(days=1)
        sessions = Session.objects.filter(
            date=tomorrow,
            status='scheduled'
        ).select_related('case', 'case__client')
        
        admin_user = User.objects.filter(is_superuser=True).first() or User.objects.filter(role='admin').first()
        if not admin_user:
            return
        
        count = 0
        for session in sessions:
            # تحقق من عدم وجود إشعار مسبق
            exists = Notification.objects.filter(
                message__contains=f'جلسة {session.case.case_number}',
                created_at__date=date.today()
            ).exists()
            
            if not exists:
                Notification.objects.create(
                    message=f'⏰ تذكير: جلسة غد للقضية {session.case.case_number} - {session.case.subject}',
                    notification_type='session',
                    target_user=admin_user
                )
                count += 1
        
        self.stdout.write(f'   📅 تم إرسال {count} إشعارات للجلسات')

    def update_expired_contracts(self):
        """تحديث حالة العقود المنتهية"""
        today = date.today()
        expired = Contract.objects.filter(
            status='active',
            end_date__lt=today
        )
        
        count = expired.count()
        expired.update(status='expired')
        
        self.stdout.write(f'   📄 تم تحديث {count} عقود إلى "منتهية"')

    def update_expired_poas(self):
        """تحديث حالة الوكالات المنتهية"""
        today = date.today()
        expired = PowerOfAttorney.objects.filter(
            status='active',
            expiry_date__lt=today
        )
        
        count = expired.count()
        expired.update(status='expired')
        
        self.stdout.write(f'   📜 تم تحديث {count} وكالات إلى "منتهية"')

    def notify_expiring_contracts(self):
        """إشعارات العقود التي ستنتهي خلال 30 يوم"""
        thirty_days_later = date.today() + timedelta(days=30)
        expiring = Contract.objects.filter(
            status='active',
            end_date__lte=thirty_days_later,
            end_date__gte=date.today()
        )
        
        admin_user = User.objects.filter(is_superuser=True).first() or User.objects.filter(role='admin').first()
        if not admin_user:
            return

        count = 0
        for contract in expiring:
            days_left = (contract.end_date - date.today()).days
            
            # تحقق من عدم وجود إشعار مسبق اليوم
            exists = Notification.objects.filter(
                message__contains=f'العقد {contract.contract_number}',
                created_at__date=date.today()
            ).exists()
            
            if not exists:
                Notification.objects.create(
                    message=f'⚠️ العقد {contract.contract_number} سينتهي خلال {days_left} يوم',
                    notification_type='contract',
                    target_user=admin_user
                )
                count += 1
        
        self.stdout.write(f'   ⚠️ تم إرسال {count} إشعارات للعقود المنتهية قريباً')

    def notify_expiring_poas(self):
        """إشعارات الوكالات التي ستنتهي خلال 30 يوم"""
        thirty_days_later = date.today() + timedelta(days=30)
        expiring = PowerOfAttorney.objects.filter(
            status__in=['active', 'expiring_soon'],
            expiry_date__lte=thirty_days_later,
            expiry_date__gte=date.today()
        )
        
        admin_user = User.objects.filter(is_superuser=True).first() or User.objects.filter(role='admin').first()
        if not admin_user:
            return

        count = 0
        for poa in expiring:
            days_left = (poa.expiry_date - date.today()).days
            
            # تحديث الحالة إلى "قارب على الانتهاء"
            if poa.status != 'expiring_soon':
                poa.status = 'expiring_soon'
                poa.save(update_fields=['status'])
            
            # تحقق من عدم وجود إشعار مسبق اليوم
            exists = Notification.objects.filter(
                message__contains=f'وكالة {poa.client.full_name}',
                created_at__date=date.today()
            ).exists()
            
            if not exists:
                Notification.objects.create(
                    message=f'⚠️ وكالة {poa.client.full_name} ستنتهي خلال {days_left} يوم',
                    notification_type='contract',
                    target_user=admin_user
                )
                count += 1
        
        self.stdout.write(f'   ⚠️ تم إرسال {count} إشعارات للوكالات المنتهية قريباً')

    def notify_overdue_tasks(self):
        """إشعارات المهام المتأخرة"""
        overdue = Task.objects.filter(
            status__in=['new', 'in_progress'],
            due_date__lt=date.today()
        ).select_related('assigned_to')
        
        count = 0
        for task in overdue:
            exists = Notification.objects.filter(
                message__contains=f'المهمة {task.title}',
                created_at__date=date.today()
            ).filter(message__contains='متأخرة').exists()
            
            if not exists and task.assigned_to:
                Notification.objects.create(
                    message=f'🔴 المهمة "{task.title}" متأخرة (تاريخ الاستحقاق: {task.due_date})',
                    notification_type='task',
                    target_user=task.assigned_to
                )
                count += 1
        
        self.stdout.write(f'   📋 تم إرسال {count} إشعارات للمهام المتأخرة')

    def notify_unpaid_invoices(self):
        """إشعارات الفواتير غير المدفوعة"""
        unpaid = Invoice.objects.filter(
            status='pending',
            due_date__lt=date.today()
        ).select_related('client')
        
        admin_user = User.objects.filter(is_superuser=True).first() or User.objects.filter(role='admin').first()
        if not admin_user:
            return

        count = 0
        for invoice in unpaid:
            exists = Notification.objects.filter(
                message__contains=f'الفاتورة {invoice.invoice_number}',
                created_at__date=date.today()
            ).exists()
            
            if not exists:
                Notification.objects.create(
                    message=f'💰 الفاتورة {invoice.invoice_number} غير مدفوعة (تاريخ الاستحقاق: {invoice.due_date})',
                    notification_type='payment',
                    target_user=admin_user
                )
                count += 1
        
        self.stdout.write(f'   💰 تم إرسال {count} إشعارات للفواتير غير المدفوعة')
