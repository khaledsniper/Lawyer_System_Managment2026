import os
import shutil
from pathlib import Path
from django.core.management.base import BaseCommand
from django.conf import settings
from django.utils import timezone


def _get_backup_dir():
    """Get backup directory.
    
    All backups stay in project media_files/backups during development.
    This can be changed later for production packaging.
    """
    return Path(settings.MEDIA_ROOT) / 'backups'


class Command(BaseCommand):
    help = 'إنشاء نسخة احتياطية من قاعدة بيانات SQLite وحفظها في مجلد backups/'

    def handle(self, *args, **options):
        # 1. الحصول على مسار قاعدة البيانات الحالية
        db_path = settings.DATABASES['default']['NAME']

        # التأكد من أنها SQLite (إذا تغيرت لاحقاً لن يعمل هذا السكربت العادي وتحتاج pg_dump)
        if 'sqlite' not in settings.DATABASES['default']['ENGINE'].lower():
            self.stdout.write(self.style.ERROR('تم تصميم هذا الأمر حالياً لـ SQLite فقط.'))
            return

        # 2. تحديد مسار الوجهة
        backup_dir = _get_backup_dir()

        # التأكد من وجود المجلد
        if not os.path.exists(backup_dir):
            os.makedirs(backup_dir)

        # 3. صياغة اسم الملف (db_backup_2024-03-21_14-30-00.sqlite3)
        timestamp = timezone.now().strftime('%Y-%m-%d_%H-%M-%S')
        backup_filename = f"db_backup_{timestamp}.sqlite3"
        backup_path = os.path.join(backup_dir, backup_filename)

        try:
            # 4. نسخ الملف (إغلاق قاعدة البيانات أولاً اختيارياً أو نسخ مباشر إذا كان SQLite)
            shutil.copy2(db_path, backup_path)

            # 5. تنظيف النسخ القديمة (إبقاء آخر 30 نسخة مثلاً)
            all_backups = sorted(
                [os.path.join(backup_dir, f) for f in os.listdir(backup_dir) if f.startswith('db_backup_')],
                key=os.path.getmtime
            )

            if len(all_backups) > 30:
                for old_backup in all_backups[:-30]:
                    os.remove(old_backup)
                    self.stdout.write(self.style.WARNING(f'تم حذف نسخة قديمة: {os.path.basename(old_backup)}'))

            self.stdout.write(self.style.SUCCESS(f'✅ تم إنشاء نسخة احتياطية بنجاح: {backup_filename}'))

        except Exception as e:
            self.stdout.write(self.style.ERROR(f'❌ حدث خطأ أثناء النسخ الاحتياطي: {str(e)}'))
