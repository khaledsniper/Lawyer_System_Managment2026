from django.shortcuts import redirect
from django.views.generic import ListView, DetailView, CreateView, UpdateView, DeleteView, TemplateView
from django.urls import reverse_lazy
from django.contrib.auth.mixins import LoginRequiredMixin
from django.db.models import Q, Count
from django.utils import timezone
from django.contrib import messages
from django.http import JsonResponse

from core.forms import AppointmentForm, TaskForm
from core.permissions import PermissionRequiredMixin, RoleRequiredMixin, ROLE_ADMIN
from core.models import Task, Appointment, Session

class TaskListView(PermissionRequiredMixin, LoginRequiredMixin, ListView):
    model = Task
    template_name = 'core/tasks.html'
    context_object_name = 'tasks'
    paginate_by = 50
    permission_module = 'tasks'
    permission_action = 'view'

    def get_queryset(self):
        queryset = Task.objects.all().select_related('case', 'assigned_to')
        status = self.request.GET.get('status')
        if status:
            queryset = queryset.filter(status=status)
        priority = self.request.GET.get('priority')
        if priority:
            queryset = queryset.filter(priority=priority)
        assigned_to = self.request.GET.get('assigned_to')
        if assigned_to:
            queryset = queryset.filter(assigned_to_id=assigned_to)
        search = self.request.GET.get('search')
        if search:
            queryset = queryset.filter(
                Q(title__icontains=search) |
                Q(description__icontains=search) |
                Q(case__case_number__icontains=search)
            )
        return queryset.order_by('-id')

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        task_stats = Task.objects.aggregate(
            total=Count('id'),
            new=Count('id', filter=Q(status='new')),
            in_progress=Count('id', filter=Q(status='in_progress')),
            done=Count('id', filter=Q(status='done')),
            overdue=Count('id', filter=Q(status__in=['new', 'in_progress'], due_date__lt=timezone.now().date())),
        )
        context['total_tasks'] = task_stats['total']
        context['new_tasks'] = task_stats['new']
        context['in_progress_tasks'] = task_stats['in_progress']
        context['done_tasks'] = task_stats['done']
        context['overdue_tasks'] = task_stats['overdue']
        
        # إضافة نموذج المهمة للمودال
        context['task_form'] = TaskForm()
        
        return context

class TaskCreateView(PermissionRequiredMixin, LoginRequiredMixin, CreateView):
    model = Task
    form_class = TaskForm
    template_name = 'core/entity_form.html'
    success_url = reverse_lazy('core:tasks')
    permission_module = 'tasks'
    permission_action = 'add'

    def get_success_url(self):
        return self.request.POST.get('next') or self.request.GET.get('next') or str(self.success_url)

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context.update({
            'page_title': 'إضافة مهمة',
            'page_subtitle': 'أدخل بيانات المهمة ثم احفظها.',
            'cancel_url': reverse_lazy('core:tasks'),
            'submit_label': 'إضافة مهمة',
            'submit_btn_class': 'btn-primary',
        })
        return context

    def form_valid(self, form):
        self.object = form.save()
        if self.request.headers.get('X-Requested-With') == 'XMLHttpRequest':
            return JsonResponse({'status': 'success', 'message': 'تم إنشاء المهمة بنجاح'})
        messages.success(self.request, '✅ تم إنشاء المهمة بنجاح')
        return redirect(self.get_success_url())

    def form_invalid(self, form):
        if self.request.headers.get('X-Requested-With') == 'XMLHttpRequest':
            return JsonResponse({'status': 'error', 'errors': form.errors}, status=400)
        return super().form_invalid(form)


class TaskUpdateView(PermissionRequiredMixin, LoginRequiredMixin, UpdateView):
    model = Task
    form_class = TaskForm
    template_name = 'core/entity_form.html'
    success_url = reverse_lazy('core:tasks')
    permission_module = 'tasks'
    permission_action = 'change'

    def get_success_url(self):
        return self.request.POST.get('next') or self.request.GET.get('next') or str(self.success_url)

    def get(self, request, *args, **kwargs):
        self.object = self.get_object()
        if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
            context = self.get_context_data()
            from django.template.loader import render_to_string
            html = render_to_string('core/includes/task_form_modal_content.html', context, request=request)
            return JsonResponse({'html': html})
        return super().get(request, *args, **kwargs)

    def form_valid(self, form):
        self.object = form.save()
        if self.request.headers.get('X-Requested-With') == 'XMLHttpRequest':
            return JsonResponse({'status': 'success', 'message': 'تم تحديث المهمة بنجاح'})
        messages.success(self.request, '✅ تم تحديث المهمة بنجاح')
        return super().form_valid(form)

    def form_invalid(self, form):
        if self.request.headers.get('X-Requested-With') == 'XMLHttpRequest':
            return JsonResponse({'status': 'error', 'errors': form.errors}, status=400)
        return super().form_invalid(form)

class TaskDeleteView(RoleRequiredMixin, LoginRequiredMixin, DeleteView):
    role_required = [ROLE_ADMIN]
    model = Task
    template_name = 'core/task_confirm_delete.html'
    success_url = reverse_lazy('core:tasks')

    def get(self, request, *args, **kwargs):
        self.object = self.get_object()
        if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
            from django.template.loader import render_to_string
            html = render_to_string('core/includes/task_delete_modal_content.html', {'object': self.object}, request=request)
            return JsonResponse({'html': html})
        return super().get(request, *args, **kwargs)

    def delete(self, request, *args, **kwargs):
        obj = self.get_object()
        task_title = obj.title
        success_url = self.get_success_url()
        obj.delete()
        if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
            return JsonResponse({'status': 'success', 'message': f'تم حذف المهمة "{task_title}" بنجاح'})
        messages.success(request, f'✅ تم حذف المهمة "{task_title}" بنجاح')
        return redirect(success_url)

class AppointmentListView(PermissionRequiredMixin, LoginRequiredMixin, ListView):
    model = Appointment
    template_name = 'core/appointments.html'
    context_object_name = 'appointments'
    paginate_by = 10
    permission_module = 'appointments'
    permission_action = 'view'

    def get_queryset(self):
        queryset = Appointment.objects.all().select_related('client')
        apt_type = self.request.GET.get('type')
        if apt_type:
            queryset = queryset.filter(type=apt_type)
        status = self.request.GET.get('status')
        if status:
            queryset = queryset.filter(status=status)
        search = self.request.GET.get('search')
        if search:
            queryset = queryset.filter(
                Q(client__full_name__icontains=search) |
                Q(location__icontains=search)
            )
        return queryset.order_by('-datetime')

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['total_appointments'] = Appointment.objects.count()
        context['today_appointments'] = Appointment.objects.filter(datetime__date=timezone.now().date()).count()
        context['upcoming_appointments'] = Appointment.objects.filter(datetime__gt=timezone.now(), status='scheduled').count()
        context['completed_appointments'] = Appointment.objects.filter(status='completed').count()
        
        # إضافة نموذج الموعد للمودال
        context['appointment_form'] = AppointmentForm()
        
        return context

class AppointmentCreateView(PermissionRequiredMixin, LoginRequiredMixin, CreateView):
    model = Appointment
    form_class = AppointmentForm
    template_name = 'core/entity_form.html'
    success_url = reverse_lazy('core:appointments')
    permission_module = 'appointments'
    permission_action = 'add'

    def get_success_url(self):
        return self.request.POST.get('next') or self.request.GET.get('next') or str(self.success_url)

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context.update({
            'page_title': 'إضافة موعد',
            'page_subtitle': 'أدخل بيانات الموعد ثم احفظها.',
            'cancel_url': reverse_lazy('core:appointments'),
            'submit_label': 'إضافة موعد',
            'submit_btn_class': 'btn-info text-white',
        })
        return context

    def form_valid(self, form):
        self.object = form.save()
        if self.request.headers.get('X-Requested-With') == 'XMLHttpRequest':
            return JsonResponse({'status': 'success', 'message': 'تم إضافة الموعد بنجاح'})
        messages.success(self.request, '✅ تم إضافة الموعد بنجاح')
        return redirect(self.get_success_url())

    def form_invalid(self, form):
        if self.request.headers.get('X-Requested-With') == 'XMLHttpRequest':
            return JsonResponse({'status': 'error', 'errors': form.errors}, status=400)
        return super().form_invalid(form)


class AppointmentUpdateView(PermissionRequiredMixin, LoginRequiredMixin, UpdateView):
    model = Appointment
    form_class = AppointmentForm
    template_name = 'core/entity_form.html'
    success_url = reverse_lazy('core:appointments')
    permission_module = 'appointments'
    permission_action = 'change'

    def get_success_url(self):
        return self.request.POST.get('next') or self.request.GET.get('next') or str(self.success_url)

    def get(self, request, *args, **kwargs):
        self.object = self.get_object()
        if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
            context = self.get_context_data()
            from django.template.loader import render_to_string
            html = render_to_string('core/includes/appointment_form_modal_content.html', context, request=request)
            return JsonResponse({'html': html})
        return super().get(request, *args, **kwargs)

    def form_valid(self, form):
        self.object = form.save()
        if self.request.headers.get('X-Requested-With') == 'XMLHttpRequest':
            return JsonResponse({'status': 'success', 'message': 'تم تحديث الموعد بنجاح'})
        messages.success(self.request, '✅ تم تحديث الموعد بنجاح')
        return super().form_valid(form)

    def form_invalid(self, form):
        if self.request.headers.get('X-Requested-With') == 'XMLHttpRequest':
            return JsonResponse({'status': 'error', 'errors': form.errors}, status=400)
        return super().form_invalid(form)

class AppointmentDeleteView(RoleRequiredMixin, LoginRequiredMixin, DeleteView):
    role_required = [ROLE_ADMIN]
    model = Appointment
    template_name = 'core/appointment_confirm_delete.html'
    success_url = reverse_lazy('core:appointments')

    def get(self, request, *args, **kwargs):
        self.object = self.get_object()
        if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
            from django.template.loader import render_to_string
            html = render_to_string('core/includes/appointment_delete_modal_content.html', {'object': self.object}, request=request)
            return JsonResponse({'html': html})
        return super().get(request, *args, **kwargs)

    def delete(self, request, *args, **kwargs):
        self.object = self.get_object()
        success_url = self.get_success_url()
        self.object.delete()
        if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
            return JsonResponse({'status': 'success', 'message': 'تم حذف الموعد بنجاح'})
        messages.success(request, '✅ تم حذف الموعد بنجاح')
        return redirect(success_url)

class CalendarView(PermissionRequiredMixin, LoginRequiredMixin, TemplateView):
    template_name = 'core/calendar.html'
    permission_module = 'appointments'
    permission_action = 'view'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['appointments'] = Appointment.objects.filter(datetime__month=timezone.now().month, datetime__year=timezone.now().year)
        context['sessions'] = Session.objects.filter(date__month=timezone.now().month, date__year=timezone.now().year)
        return context
