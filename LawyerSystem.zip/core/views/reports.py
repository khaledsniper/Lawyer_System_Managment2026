from django.views.generic import TemplateView
from django.contrib.auth.mixins import LoginRequiredMixin
from core.services.dashboard_stats import get_reports_stats
from core.models import Fee, Invoice

class ReportsView(LoginRequiredMixin, TemplateView):
    template_name = 'core/reports.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        
        # استخدام الـ Managers الموحد للتخلص من التكرار
        reports_stats = get_reports_stats()
        case_stats = reports_stats['case_stats']
        client_stats = reports_stats['client_stats']
        finance_stats = reports_stats['finance_stats']
        
        context.update({
            'total_cases': case_stats['total'],
            'active_cases': case_stats['active'],
            'won_cases': case_stats['won'],
            'pending_cases': case_stats['pending'],
            'closed_cases': case_stats['closed'],
            'total_clients': client_stats['total'],
            'individual_clients': client_stats['individual'],
            'company_clients': client_stats['company'],
            'total_fees': finance_stats['total_fees'],
            'total_collected': finance_stats['total_collected'],
            'total_expenses': finance_stats['total_expenses'],
            'net_profit': finance_stats['net_profit'],
        })
        invoice_stats = reports_stats['invoice_stats']
        task_stats = reports_stats['task_stats']
        appointment_stats = reports_stats['appointment_stats']
        contract_stats = reports_stats['contract_stats']

        context['total_invoices'] = invoice_stats['total_invoices']
        context['paid_invoices'] = invoice_stats['paid']
        context['pending_invoices'] = invoice_stats['pending']
        context['total_tasks'] = task_stats['total']
        context['completed_tasks'] = task_stats['done']
        context['pending_tasks'] = task_stats['new'] + task_stats['in_progress']
        context['total_appointments'] = appointment_stats['total']
        context['completed_appointments'] = appointment_stats['completed']
        context['upcoming_appointments'] = appointment_stats['upcoming']
        context['total_contracts'] = contract_stats['total']
        context['active_contracts'] = contract_stats['active']
        context['expiring_contracts'] = contract_stats['expiring']
        context['cases_by_type'] = reports_stats['cases_by_type']
        context['expenses_by_category'] = reports_stats['expenses_by_category']
        
        # إضافة البيانات المالية التفصيلية (الأقسام السفلية)
        context['recent_fees'] = Fee.objects.all().select_related('case__client').order_by('-id')[:5]
        context['recent_invoices'] = Invoice.objects.all().select_related('client').order_by('-id')[:5]
        
        return context
