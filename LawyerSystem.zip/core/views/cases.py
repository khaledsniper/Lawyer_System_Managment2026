import logging
from django.shortcuts import redirect
from django.views.generic import (
    ListView,
    DetailView,
    CreateView,
    UpdateView,
    DeleteView,
)
from django.urls import reverse_lazy
from django.template.loader import render_to_string
from django.contrib.auth.mixins import LoginRequiredMixin
from django.contrib.auth.decorators import login_required
from django.db.models import Q
from django.db.models.functions import Lower
from django.utils import timezone
from datetime import date
from django.contrib import messages
from django.http import JsonResponse
from reportlab.lib.units import mm

from core.permissions import (
    PermissionRequiredMixin,
    RoleRequiredMixin,
    ROLE_ADMIN,
    permission_required,
)
from core.models import Case, Client, Opponent, Session, Document, Court
from core.forms import CaseForm, SessionForm
from core.services.duplicates import (
    check_case_duplicate as check_case_duplicate_service,
)
from core.services.export_helpers import UnifiedExportService, ExportConfig
from core.services.case_detail import build_case_detail_context, get_case_with_related

from .mixins import FilteredListViewMixin

logger = logging.getLogger(__name__)

# Maximum rows for export to prevent memory issues
MAX_EXPORT_ROWS = 10000


def get_filtered_cases_queryset(request, search_fields=None):
    queryset = (
        Case.objects.all()
        .select_related("client")
        .prefetch_related("opponents")
        .annotate(lower_client_name=Lower("client__full_name"))
    )
    status = request.GET.get("status")
    if status:
        queryset = queryset.filter(status=status)
    case_type = request.GET.get("case_type")
    if case_type:
        queryset = queryset.filter(case_type=case_type)
    court = request.GET.get("court")
    if court:
        # Check if court is an ID or a string (for backward compatibility during migration)
        if court.isdigit():
            queryset = queryset.filter(court_id=court)
        else:
            queryset = queryset.filter(court__name__icontains=court)

    # تطبيق البحث العام
    if search_fields:
        search_query = request.GET.get("search", "").strip()
        if search_query:
            search_filter = Q()
            for field in search_fields:
                search_filter |= Q(**{f"{field}__icontains": search_query})
            queryset = queryset.filter(search_filter)

    return queryset.distinct().order_by("-created_at", "-id")


class CaseListView(
    PermissionRequiredMixin, LoginRequiredMixin, FilteredListViewMixin, ListView
):
    model = Case
    template_name = "core/cases.html"
    context_object_name = "cases"
    search_fields = ["case_number", "subject", "client__full_name"]
    page_size_options = (25, 50, 75, 100)
    permission_module = "cases"
    permission_action = "view"

    def get(self, request, *args, **kwargs):
        # Handle AJAX requests for filtering
        if request.headers.get("X-Requested-With") == "XMLHttpRequest":
            try:
                self.object_list = self.get_queryset()
                context = self.get_context_data()
                from django.template.loader import render_to_string
                from django.http import JsonResponse

                # Render only the table container
                html = render_to_string(
                    "core/includes/cases_table_partial.html", context, request=request
                )

                # Return both HTML and count
                return JsonResponse({"html": html, "count": self.object_list.count()})
            except Exception as e:
                logger.error(f"AJAX error: {str(e)}", exc_info=True)
                from django.http import JsonResponse

                return JsonResponse({"error": str(e)}, status=500)

        return super().get(request, *args, **kwargs)

    def get_queryset(self):
        return get_filtered_cases_queryset(self.request, self.search_fields)

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        case_stats = Case.objects.get_statistics()
        context.update(
            {
                "total_cases": case_stats["total"],
                "active_cases": case_stats["active"],
                "pending_cases": case_stats["pending"],
                "won_cases": case_stats["won"],
                "closed_cases": case_stats["closed"],
                "page_size_options": self.page_size_options,
                "clients": Client.objects.all()
                .only("id", "full_name")
                .order_by("full_name"),
                "opponents": Opponent.objects.all().only("id", "name").order_by("name"),
                "courts": Court.objects.all().order_by("name"),
                "years_range": range(2000, 2100),
                "current_year": timezone.now().year,
                "form": CaseForm(),
            }
        )
        return context




@login_required
def check_case_duplicate(request):
    case_number = request.GET.get("case_number", "").strip()
    client_id = request.GET.get("client_id", "").strip()
    pk = request.GET.get("pk", "").strip()
    result = check_case_duplicate_service(
        case_number=case_number,
        client_id=client_id,
        pk=pk,
    )
    return JsonResponse(result)


class CaseCreateView(PermissionRequiredMixin, LoginRequiredMixin, CreateView):
    model = Case
    form_class = CaseForm
    template_name = "core/case_standalone_form.html"
    success_url = reverse_lazy("core:cases")
    permission_module = "cases"
    permission_action = "add"

    def get(self, request, *args, **kwargs):
        if request.headers.get("X-Requested-With") == "XMLHttpRequest":
            context = self.get_context_data()
            html = render_to_string("core/case_form.html", context, request=request)
            return JsonResponse({"html": html})
        return super().get(request, *args, **kwargs)

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context["clients"] = (
            Client.objects.all().only("id", "full_name").order_by("full_name")
        )
        context["opponents"] = (
            Opponent.objects.all().only("id", "name").order_by("name")
        )
        context["current_year"] = timezone.now().year
        context["years_range"] = range(2000, 2100)
        return context

    def form_valid(self, form):
        self.object = form.save()
        files = self.request.FILES.getlist("attachments")
        for f in files:
            Document.objects.create(file=f, case=self.object, doc_type="other")
        if self.request.headers.get("X-Requested-With") == "XMLHttpRequest":
            return JsonResponse(
                {
                    "status": "success",
                    "message": f"تم حفظ القضية رقم {self.object.case_number} بنجاح",
                    "case_id": self.object.id,
                }
            )
        messages.success(self.request, "✅ تم إضافة القضية بنجاح")
        return super().form_valid(form)

    def form_invalid(self, form):
        if self.request.headers.get("X-Requested-With") == "XMLHttpRequest":
            return JsonResponse({"status": "error", "errors": form.errors}, status=400)
        messages.error(self.request, "❌ هناك أخطاء في النموذج")
        return super().form_invalid(form)


class CaseDetailView(PermissionRequiredMixin, LoginRequiredMixin, DetailView):
    model = Case
    template_name = "core/case_detail_modal.html"
    context_object_name = "case"
    permission_module = "cases"
    permission_action = "view"

    def get(self, request, *args, **kwargs):
        self.object = get_case_with_related(self.kwargs.get("pk"))
        context = build_case_detail_context(self.object)
        if request.headers.get("X-Requested-With") == "XMLHttpRequest":
            html = render_to_string(self.template_name, context, request=request)
            return JsonResponse({"html": html})
        return render(request, self.template_name, context)


class CaseUpdateView(PermissionRequiredMixin, LoginRequiredMixin, UpdateView):
    model = Case
    form_class = CaseForm
    template_name = "core/case_standalone_form.html"
    success_url = reverse_lazy("core:cases")
    permission_module = "cases"
    permission_action = "change"

    def get(self, request, *args, **kwargs):
        self.object = self.get_object()
        if request.headers.get("X-Requested-With") == "XMLHttpRequest":
            context = self.get_context_data()
            html = render_to_string("core/case_form.html", context, request=request)
            return JsonResponse({"html": html})
        return super().get(request, *args, **kwargs)

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context["clients"] = (
            Client.objects.all().only("id", "full_name").order_by("full_name")
        )
        context["opponents"] = (
            Opponent.objects.filter(is_active=True).only("id", "name").order_by("name")
        )
        context["current_year"] = timezone.now().year
        context["years_range"] = range(2000, 2100)
        return context

    def form_valid(self, form):
        self.object = form.save()
        files = self.request.FILES.getlist("attachments")
        for f in files:
            Document.objects.create(file=f, case=self.object, doc_type="other")
        if self.request.headers.get("X-Requested-With") == "XMLHttpRequest":
            return JsonResponse(
                {
                    "status": "success",
                    "message": f"تم تحديث القضية رقم {self.object.case_number} بنجاح",
                    "case_id": self.object.id,
                }
            )
        messages.success(self.request, "✅ تم تحديث بيانات القضية بنجاح")
        return super().form_valid(form)

    def form_invalid(self, form):
        if self.request.headers.get("X-Requested-With") == "XMLHttpRequest":
            return JsonResponse({"status": "error", "errors": form.errors}, status=400)
        messages.error(self.request, "❌ هناك أخطاء في النموذج")
        return super().form_invalid(form)


class CaseDeleteView(RoleRequiredMixin, LoginRequiredMixin, DeleteView):
    role_required = [ROLE_ADMIN]
    model = Case
    template_name = "core/case_confirm_delete.html"
    success_url = reverse_lazy("core:cases")

    def get(self, request, *args, **kwargs):
        self.object = self.get_object()
        if request.headers.get("X-Requested-With") == "XMLHttpRequest":
            html = render_to_string("core/includes/generic_delete_modal_content.html", {"object": self.object}, request=request)
            return JsonResponse({"html": html})
        return super().get(request, *args, **kwargs)

    def delete(self, request, *args, **kwargs):
        self.object = self.get_object()
        success_url = self.get_success_url()
        self.object.delete()
        if request.headers.get("X-Requested-With") == "XMLHttpRequest":
            return JsonResponse({"status": "success", "message": "تم حذف القضية بنجاح"})
        return redirect(success_url)


class SessionListView(
    PermissionRequiredMixin, LoginRequiredMixin, FilteredListViewMixin, ListView
):
    model = Session
    template_name = "core/sessions.html"
    context_object_name = "sessions"
    search_fields = ["case__case_number", "case__subject", "court__name"]
    page_size_options = (25, 50, 75, 100)
    permission_module = "sessions"
    permission_action = "view"

    def get_queryset(self):
        from datetime import timedelta

        queryset = Session.objects.all().select_related("case", "case__client", "court")

        # تطبيق البحث العام عبر الـ Mixin
        queryset = self.apply_search(queryset)

        # فلتر الحالة
        status = self.request.GET.get("status")
        if status:
            queryset = queryset.filter(status=status)

        # فلتر نوع الجلسة
        session_type = self.request.GET.get("session_type")
        if session_type:
            queryset = queryset.filter(session_type=session_type)

        # Time filter
        time_filter = self.request.GET.get("time_filter")
        today = date.today()
        if time_filter == "today":
            queryset = queryset.filter(date=today)
        elif time_filter == "tomorrow":
            queryset = queryset.filter(date=today + timedelta(days=1))
        elif time_filter == "upcoming":
            queryset = queryset.filter(date__gt=today)
        elif time_filter == "past":
            queryset = queryset.filter(date__lt=today)

        # الترتيب
        if time_filter in ["today", "tomorrow", "upcoming"]:
            return queryset.order_by("date", "time")

        return queryset.order_by("-date", "-time")

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context.update(
            {
                "total_sessions": Session.objects.count(),
                "scheduled_sessions": Session.objects.filter(
                    status="scheduled"
                ).count(),
                "completed_sessions": Session.objects.filter(
                    status="completed"
                ).count(),
                "postponed_sessions": Session.objects.filter(
                    status="postponed"
                ).count(),
                "todays_sessions": Session.objects.filter(date=date.today()).count(),
                "upcoming_sessions": Session.objects.filter(
                    date__gt=date.today()
                ).count(),
                "page_size_options": self.page_size_options,
            }
        )

        # إضافة نموذج الجلسة للمودال
        from core.forms import SessionForm

        context["session_form"] = SessionForm()

        return context


class SessionCreateView(PermissionRequiredMixin, LoginRequiredMixin, CreateView):
    model = Session
    form_class = SessionForm
    template_name = "core/entity_form.html"
    success_url = reverse_lazy("core:sessions")
    permission_module = "sessions"
    permission_action = "add"

    def get_success_url(self):
        return (
            self.request.POST.get("next")
            or self.request.GET.get("next")
            or str(self.success_url)
        )

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context.update(
            {
                "page_title": "إضافة جلسة",
                "page_subtitle": "أدخل بيانات الجلسة القضائية ثم احفظ التغييرات.",
                "cancel_url": reverse_lazy("core:sessions"),
                "submit_label": "إضافة جلسة",
                "submit_btn_class": "btn-danger",
            }
        )
        return context

    def form_valid(self, form):
        self.object = form.save()
        if self.request.headers.get("X-Requested-With") == "XMLHttpRequest":
            return JsonResponse(
                {"status": "success", "message": "تم إضافة الجلسة بنجاح"}
            )
        messages.success(self.request, "✅ تم إضافة الجلسة بنجاح")
        return redirect(self.get_success_url())

    def form_invalid(self, form):
        if self.request.headers.get("X-Requested-With") == "XMLHttpRequest":
            return JsonResponse({"status": "error", "errors": form.errors}, status=400)
        return super().form_invalid(form)


class SessionDetailView(PermissionRequiredMixin, LoginRequiredMixin, DetailView):
    model = Session
    template_name = "core/session_detail.html"
    context_object_name = "session"
    permission_module = "sessions"
    permission_action = "view"


class SessionUpdateView(PermissionRequiredMixin, LoginRequiredMixin, UpdateView):
    model = Session
    form_class = SessionForm
    template_name = "core/entity_form.html"
    success_url = reverse_lazy("core:sessions")
    permission_module = "sessions"
    permission_action = "change"

    def get(self, request, *args, **kwargs):
        self.object = self.get_object()
        if request.headers.get("X-Requested-With") == "XMLHttpRequest":
            context = self.get_context_data()
            context["session"] = self.object
            from django.template.loader import render_to_string

            html = render_to_string(
                "core/includes/session_update_modal.html", context, request=request
            )
            from django.http import JsonResponse

            return JsonResponse({"html": html})
        return super().get(request, *args, **kwargs)

    def get_success_url(self):
        return (
            self.request.POST.get("next")
            or self.request.GET.get("next")
            or str(self.success_url)
        )

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context.update(
            {
                "page_title": "تعديل جلسة",
                "page_subtitle": "عدّل بيانات الجلسة ثم احفظ التغييرات.",
                "cancel_url": reverse_lazy("core:sessions"),
                "submit_label": "حفظ التعديلات",
                "submit_btn_class": "btn-danger",
            }
        )
        return context

    def form_valid(self, form):
        self.object = form.save()

        # Debug logging
        logger.info(
            f"Session {self.object.id} updated - session_type: '{self.object.session_type}', status: '{self.object.status}'"
        )

        if self.request.headers.get("X-Requested-With") == "XMLHttpRequest":
            from django.http import JsonResponse

            return JsonResponse(
                {
                    "status": "success",
                    "message": "✅ تم تحديث بيانات الجلسة بنجاح",
                    "session_id": self.object.id,
                    "debug": {
                        "session_type": self.object.session_type,
                        "status": self.object.status,
                        "date": str(self.object.date),
                    },
                }
            )
        messages.success(self.request, "✅ تم تحديث الجلسة بنجاح")
        return super().form_valid(form)

    def form_invalid(self, form):
        if self.request.headers.get("X-Requested-With") == "XMLHttpRequest":
            from django.http import JsonResponse

            return JsonResponse({"status": "error", "errors": form.errors}, status=400)
        messages.error(self.request, "❌ هناك أخطاء في النموذج")
        return super().form_invalid(form)


class SessionDeleteView(RoleRequiredMixin, LoginRequiredMixin, DeleteView):
    role_required = [ROLE_ADMIN]
    model = Session
    template_name = "core/session_confirm_delete.html"
    success_url = reverse_lazy("core:sessions")

    def get(self, request, *args, **kwargs):
        self.object = self.get_object()
        if request.headers.get("X-Requested-With") == "XMLHttpRequest":
            html = render_to_string("core/includes/generic_delete_modal_content.html", {"object": self.object}, request=request)
            return JsonResponse({"html": html})
        return super().get(request, *args, **kwargs)

    def delete(self, request, *args, **kwargs):
        self.object = self.get_object()
        success_url = self.get_success_url()
        self.object.delete()
        if request.headers.get("X-Requested-With") == "XMLHttpRequest":
            return JsonResponse({"status": "success", "message": "تم حذف الجلسة بنجاح"})
        messages.success(request, "✅ تم حذف الجلسة بنجاح")
        return redirect(success_url)


class DocumentListView(LoginRequiredMixin, ListView):
    model = Document
    template_name = "core/documents.html"
    context_object_name = "documents"


class DocumentCreateView(LoginRequiredMixin, CreateView):
    model = Document
    fields = "__all__"
    template_name = "core/document_form.html"
    success_url = reverse_lazy("core:documents")


@login_required
@permission_required("cases", "view")
def export_cases_excel(request):
    """Export cases to Excel (unified export)."""
    service = UnifiedExportService(request)
    return service.export(CASE_EXPORT_CONFIG, format="excel")


@login_required
@permission_required("cases", "view")
def export_cases_pdf(request):
    """Export cases to PDF (unified export)."""
    service = UnifiedExportService(request)
    return service.export(CASE_EXPORT_CONFIG, format="pdf")


# ========================================
# Session Export Functions
# ========================================


def _get_filtered_sessions_queryset(request):
    """Get filtered sessions queryset matching the list view filters."""
    from datetime import timedelta

    queryset = Session.objects.all().select_related("case", "case__client", "court")
    status = request.GET.get("status")
    if status:
        queryset = queryset.filter(status=status)
    search = request.GET.get("search")
    if search:
        queryset = queryset.filter(
            Q(case__case_number__icontains=search)
            | Q(case__subject__icontains=search)
            | Q(court__name__icontains=search)
        )
    # Time filter
    time_filter = request.GET.get("time_filter")
    today = date.today()
    tomorrow = today + timedelta(days=1)
    # تطبيق الفلاتر
    if time_filter == "today":
        queryset = queryset.filter(date=today)
    elif time_filter == "tomorrow":
        queryset = queryset.filter(date=tomorrow)
    elif time_filter == "upcoming":
        queryset = queryset.filter(date__gt=today)
    elif time_filter == "past":
        queryset = queryset.filter(date__lt=today)

    # تطبيق الترتيب الديناميكي حسب الفلتر (مطابق لعرض القائمة)
    if time_filter in ["today", "tomorrow", "upcoming"]:
        queryset = queryset.order_by("date", "time")
    elif time_filter == "past":
        queryset = queryset.order_by("-date", "-time")
    else:
        queryset = queryset.order_by("-date", "-time")

    return queryset


@login_required
@permission_required("sessions", "view")
def export_sessions_excel(request):
    """Export sessions to Excel (unified export)."""
    service = UnifiedExportService(request)
    return service.export(SESSION_EXPORT_CONFIG, format="excel")


@login_required
@permission_required("sessions", "view")
def export_sessions_pdf(request):
    """Export sessions to PDF (unified export)."""
    service = UnifiedExportService(request)
    return service.export(SESSION_EXPORT_CONFIG, format="pdf")


# ============================================
# Unified Export: Row Mappers & Configs
# ============================================


def _map_case_row(case, is_pdf=False):
    if is_pdf:
        return [
            case.get_status_display() or case.status or "—",
            str(case.court) if case.court else "—",
            str(case.case_type) if case.case_type else "—",
            (case.subject or "")[:55] + "..."
            if case.subject and len(case.subject) > 55
            else (case.subject or "—"),
            case.client.full_name if case.client else "—",
            case.case_number or "—",
        ]
    return [
        case.case_number or "",
        case.client.full_name if case.client else "",
        case.subject or "",
        case.case_type or "",
        str(case.court) if case.court else "",
        case.get_status_display() or case.status or "",
    ]


def _map_session_row(session, is_pdf=False):
    if is_pdf:
        return [
            session.get_status_display() or "",
            str(session.court) if session.court else "—",
            session.get_session_type_display() if session.session_type else "—",
            session.time.strftime("%H:%M") if session.time else "—",
            session.date.strftime("%Y-%m-%d") if session.date else "—",
            session.case.client.full_name if session.case.client else "—",
            (session.case.subject or "")[:45] + "..."
            if session.case.subject and len(session.case.subject) > 45
            else (session.case.subject or "—"),
            session.case.case_number or "—",
        ]
    return [
        session.case.case_number or "",
        session.case.subject or "",
        session.case.client.full_name if session.case.client else "",
        session.date.strftime("%Y-%m-%d") if session.date else "",
        session.time.strftime("%H:%M") if session.time else "",
        session.get_session_type_display() or "غير محدد",
        str(session.court) if session.court else "",
        session.get_status_display() or "",
    ]


CASE_EXPORT_CONFIG = ExportConfig(
    model_name="القضايا",
    queryset_fn=lambda req: get_filtered_cases_queryset(req),
    excel_headers=[
        "رقم القضية",
        "العميل",
        "الموضوع",
        "نوع القضية",
        "المحكمة",
        "الحالة",
    ],
    pdf_headers=["الحالة", "المحكمة", "النوع", "الموضوع", "العميل", "رقم القضية"],
    row_mapper=_map_case_row,
    pdf_col_widths=[
        15 * mm, # الحالة
        35 * mm, # المحكمة
        15 * mm, # النوع
        55 * mm, # الموضوع
        45 * mm, # العميل
        15 * mm, # رقم القضية
    ],
    theme_color="4F46E5",
    filename_prefix="cases",
)

SESSION_EXPORT_CONFIG = ExportConfig(
    model_name="الجلسات",
    queryset_fn=lambda req: _get_filtered_sessions_queryset(req),
    excel_headers=[
        "رقم القضية",
        "موضوع القضية",
        "العميل",
        "تاريخ الجلسة",
        "وقت الجلسة",
        "نوع الجلسة",
        "المحكمة",
        "الحالة",
    ],
    pdf_headers=[
        "الحالة",
        "المحكمة",
        "نوع الجلسة",
        "وقت الجلسة",
        "تاريخ الجلسة",
        "العميل",
        "موضوع القضية",
        "رقم القضية",
    ],
    row_mapper=_map_session_row,
    pdf_col_widths=[
        15 * mm, # الحالة
        32 * mm, # المحكمة
        15 * mm, # نوع الجلسة
        15 * mm, # وقت الجلسة
        20 * mm, # تاريخ الجلسة
        30 * mm, # العميل
        36 * mm, # موضوع القضية
        15 * mm, # رقم القضية
    ],
    theme_color="7C3AED",
    filename_prefix="sessions",
)
