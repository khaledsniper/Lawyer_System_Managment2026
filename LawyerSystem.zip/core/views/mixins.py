from django.db.models import Q
from django.views.generic import ListView
from django.http import JsonResponse
from django.template.loader import render_to_string

class FilteredListViewMixin(ListView):
    """
    Mixin لتسهيل عمليات الفلترة والبحث والتحكم في عدد العناصر في الصفحة
    """
    search_fields = []  # الحقول التي سيتم البحث فيها
    default_paginate_by = 25
    
    def get_paginate_by(self, queryset):
        """الحصول على عدد العناصر في الصفحة من الـ URL"""
        for param in ['page_size', 'paginate_by', 'limit']:
            val = self.request.GET.get(param)
            if val:
                try: return int(val)
                except: pass
        return self.default_paginate_by

    def apply_filters(self, queryset, field_map):
        """
        تطبيق الفلاتر على الـ queryset بناءً على معاملات GET.
        field_map: dict يربط اسم معامل GET بحقل الـ ORM
        مثال: {'status': 'status', 'case__client': 'client'}
        """
        for orm_field, get_param in field_map.items():
            value = self.request.GET.get(get_param)
            if value:
                queryset = queryset.filter(**{orm_field: value})
        return queryset

    def apply_search(self, queryset):
        search_query = self.request.GET.get('search', '').strip()
        if search_query and self.search_fields:
            search_filter = Q()
            for field in self.search_fields:
                search_filter |= Q(**{f"{field}__icontains": search_query})
            queryset = queryset.filter(search_filter)
        return queryset

    def get(self, request, *args, **kwargs):
        if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
            self.object_list = self.get_queryset()
            context = self.get_context_data()
            
            # تحديد التمبلت الجزئي إذا كان موجوداً، وإلا استخدام التمبلت الأصلي
            partial_template = getattr(self, 'partial_template_name', self.template_name)
            html = render_to_string(partial_template, context, request=request)
            
            # استخراج الإحصائيات من السياق إذا كانت موجودة
            stats = {}
            for key, value in context.items():
                if key.endswith('_count') or key in ['total_contracts', 'active_contracts', 'expired_contracts', 
                                                       'total_poas', 'active_poas', 'expired_poas', 'expiring_soon',
                                                       'total_cases', 'active_cases', 'pending_cases', 'won_cases', 'closed_cases',
                                                       'total_clients', 'active_clients', 'total_opponents', 'active_opponents']:
                    try:
                        stats[key] = int(value)
                    except (TypeError, ValueError):
                        stats[key] = value
            
            return JsonResponse({'html': html, 'stats': stats if stats else None})
        return super().get(request, *args, **kwargs)
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        
        # تمرير قيم الفلاتر للتمبلت للحفاظ عليها عند التنقل
        context['current_search'] = self.request.GET.get('search', '')
        context['current_paginate_by'] = self.get_paginate_by(None)
        
        # بناء رابط الفلترة لاستخدامه في الـ Pagination
        query_params = self.request.GET.copy()
        query_params.pop('page', None)
        context['pagination_querystring'] = query_params.urlencode()
        
        return context
