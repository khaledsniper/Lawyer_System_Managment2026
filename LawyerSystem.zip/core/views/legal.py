from django.shortcuts import redirect
from django.views.generic import (
    ListView,
    DetailView,
    CreateView,
    UpdateView,
    DeleteView,
)
from django.urls import reverse_lazy
from django.template.loader import render_to_string
from django.contrib.auth.mixins import LoginRequiredMixin
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.http import JsonResponse
from django.db.models import Q
from django.utils import timezone
from datetime import timedelta

from core.permissions import (
    PermissionRequiredMixin,
    RoleRequiredMixin,
    ROLE_ADMIN,
    permission_required,
)
from core.services.export_helpers import UnifiedExportService, ExportConfig
from core.models import Contract, PowerOfAttorney, Declaration, Consultation
from ..forms import ContractForm, PowerOfAttorneyForm
from .mixins import FilteredListViewMixin

# Max rows for exports to prevent memory issues
MAX_EXPORT_ROWS = 10000

# For PDF column widths
from reportlab.lib.units import mm


class ConsultationListView(PermissionRequiredMixin, LoginRequiredMixin, ListView):
    model = Consultation
    template_name = "core/consultations.html"
    context_object_name = "consultations"
    permission_module = "consultations"
    permission_action = "view"


class ContractListView(
    PermissionRequiredMixin, LoginRequiredMixin, FilteredListViewMixin, ListView
):
    model = Contract
    template_name = "core/contracts.html"
    context_object_name = "contracts"
    search_fields = ["contract_number", "client__full_name"]
    partial_template_name = "core/partials/contract_list_partial.html"
    paginate_by = 50
    page_size_options = (25, 50, 75, 100)
    permission_module = "contracts"
    permission_action = "view"

    def get_queryset(self):
        queryset = Contract.objects.all().select_related("client")
        queryset = self.apply_search(queryset)

        status = self.request.GET.get("status")
        if status:
            queryset = queryset.filter(status=status)
        contract_type = self.request.GET.get("type")
        if contract_type:
            queryset = queryset.filter(type=contract_type)
        return queryset.order_by("client__full_name")

    def get_paginate_by(self, queryset):
        page_size = self.request.GET.get("page_size")
        try:
            page_size = int(page_size)
        except (TypeError, ValueError):
            return self.paginate_by
        return page_size if page_size in self.page_size_options else self.paginate_by

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)

        # إذا لم يكن الطلب عبر AJAX، نحتاج إلى توفير إحصائيات تجميعية وبيانات التوكيلات المبدئية للتبويبات
        if not self.request.headers.get("X-Requested-With") == "XMLHttpRequest":
            context["total_contracts"] = Contract.objects.count()
            context["active_contracts"] = Contract.objects.filter(
                status="active"
            ).count()
            context["expired_contracts"] = Contract.objects.filter(
                status="expired"
            ).count()
            context["expiring_soon"] = Contract.objects.filter(
                status="active",
                end_date__lte=timezone.now().date() + timedelta(days=30),
            ).count()

            context["total_poas"] = PowerOfAttorney.objects.count()
            context["active_poas"] = PowerOfAttorney.objects.filter(
                status="active"
            ).count()
            context["expired_poas"] = PowerOfAttorney.objects.filter(
                status="expired"
            ).count()
            context["expiring_soon_poas"] = PowerOfAttorney.objects.filter(
                status="expiring_soon"
            ).count()

            # جلب أول 50 توكيل لعرضهم افتراضياً في التبويب الثاني
            context["poas"] = (
                PowerOfAttorney.objects.all()
                .select_related("client")
                .order_by("client__full_name")[:50]
            )

        context["page_size_options"] = self.page_size_options
        context["current_page_size"] = self.get_paginate_by(self.object_list)
        context["contract_status_choices"] = Contract._meta.get_field("status").choices
        context["active_tab"] = "contracts"
        return context


class ContractCreateView(PermissionRequiredMixin, LoginRequiredMixin, CreateView):
    model = Contract
    form_class = ContractForm
    template_name = "core/contract_form.html"
    success_url = reverse_lazy("core:contracts")
    permission_module = "contracts"
    permission_action = "add"

    def get(self, request, *args, **kwargs):
        if request.headers.get("X-Requested-With") == "XMLHttpRequest":
            self.object = None
            context = self.get_context_data()
            html = render_to_string(
                "core/includes/contract_form_modal_content.html",
                context,
                request=request,
            )
            return JsonResponse({"html": html})
        return super().get(request, *args, **kwargs)

    def form_valid(self, form):
        self.object = form.save()
        if self.request.headers.get("X-Requested-With") == "XMLHttpRequest":
            return JsonResponse(
                {
                    "status": "success",
                    "message": f"تم إضافة العقد {self.object.contract_number} بنجاح",
                    "contract_id": self.object.pk,
                }
            )
        messages.success(
            self.request, f"✅ تم إضافة العقد {self.object.contract_number} بنجاح"
        )
        return redirect(self.get_success_url())

    def form_invalid(self, form):
        if self.request.headers.get("X-Requested-With") == "XMLHttpRequest":
            context = self.get_context_data(form=form)
            html = render_to_string(
                "core/includes/contract_form_modal_content.html",
                context,
                request=self.request,
            )
            return JsonResponse({"status": "error", "html": html}, status=400)
        messages.error(self.request, "❌ هناك أخطاء في نموذج العقد")
        return super().form_invalid(form)


class ContractDetailView(PermissionRequiredMixin, LoginRequiredMixin, DetailView):
    model = Contract
    template_name = "core/contract_detail_modal.html"
    context_object_name = "contract"
    permission_module = "contracts"
    permission_action = "view"

    def get(self, request, *args, **kwargs):
        self.object = self.get_object()
        if request.headers.get("X-Requested-With") == "XMLHttpRequest":
            from core.models import OfficeProfile
            office = OfficeProfile.objects.first()
            html = render_to_string(self.template_name, {
                'contract': self.object,
                'office_profile': office
            }, request=request)
            return JsonResponse({'html': html})
        return super().get(request, *args, **kwargs)




class ContractUpdateView(PermissionRequiredMixin, LoginRequiredMixin, UpdateView):
    model = Contract
    form_class = ContractForm
    template_name = "core/contract_form.html"
    success_url = reverse_lazy("core:contracts")
    permission_module = "contracts"
    permission_action = "change"

    def get(self, request, *args, **kwargs):
        self.object = self.get_object()
        if request.headers.get("X-Requested-With") == "XMLHttpRequest":
            context = self.get_context_data()
            html = render_to_string(
                "core/includes/contract_form_modal_content.html",
                context,
                request=request,
            )
            return JsonResponse({"html": html})
        return super().get(request, *args, **kwargs)

    def form_valid(self, form):
        self.object = form.save()
        if self.request.headers.get("X-Requested-With") == "XMLHttpRequest":
            return JsonResponse(
                {
                    "status": "success",
                    "message": f"تم تحديث العقد {self.object.contract_number} بنجاح",
                    "contract_id": self.object.pk,
                }
            )
        messages.success(
            self.request, f"✅ تم تحديث العقد {self.object.contract_number} بنجاح"
        )
        return redirect(self.get_success_url())

    def form_invalid(self, form):
        if self.request.headers.get("X-Requested-With") == "XMLHttpRequest":
            self.object = self.get_object()
            context = self.get_context_data(form=form)
            html = render_to_string(
                "core/includes/contract_form_modal_content.html",
                context,
                request=self.request,
            )
            return JsonResponse({"status": "error", "html": html}, status=400)
        messages.error(self.request, "❌ هناك أخطاء في نموذج العقد")
        return super().form_invalid(form)


class ContractDeleteView(RoleRequiredMixin, LoginRequiredMixin, DeleteView):
    role_required = [ROLE_ADMIN]
    model = Contract
    template_name = "core/contract_confirm_delete.html"
    success_url = reverse_lazy("core:contracts")

    def get(self, request, *args, **kwargs):
        self.object = self.get_object()
        if request.headers.get("X-Requested-With") == "XMLHttpRequest":
            html = render_to_string("core/includes/generic_delete_modal_content.html", {"object": self.object}, request=request)
            return JsonResponse({"html": html})
        return super().get(request, *args, **kwargs)

    def delete(self, request, *args, **kwargs):
        obj = self.get_object()
        contract_number = obj.contract_number
        success_url = self.get_success_url()
        obj.delete()
        if request.headers.get("X-Requested-With") == "XMLHttpRequest":
            return JsonResponse({"status": "success", "message": f"✅ تم حذف العقد {contract_number} بنجاح"})
        messages.success(request, f"✅ تم حذف العقد {contract_number} بنجاح")
        return redirect(success_url)


class PowerOfAttorneyListView(
    PermissionRequiredMixin, LoginRequiredMixin, FilteredListViewMixin, ListView
):
    model = PowerOfAttorney
    template_name = "core/contracts.html"
    context_object_name = "poas"
    search_fields = ["client__full_name", "issuer"]
    partial_template_name = "core/partials/poa_list_partial.html"
    paginate_by = 50
    page_size_options = (25, 50, 75, 100)
    permission_module = "power_of_attorney"
    permission_action = "view"

    def get_queryset(self):
        queryset = PowerOfAttorney.objects.all().select_related("client")
        queryset = self.apply_search(queryset)

        status = self.request.GET.get("status")
        if status:
            queryset = queryset.filter(status=status)
        poa_type = self.request.GET.get("type")
        if poa_type:
            queryset = queryset.filter(type=poa_type)
        return queryset.order_by("client__full_name")

    def get_paginate_by(self, queryset):
        page_size = self.request.GET.get("page_size")
        try:
            page_size = int(page_size)
        except (TypeError, ValueError):
            return self.paginate_by
        return page_size if page_size in self.page_size_options else self.paginate_by

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)

        # إذا لم يكن الطلب عبر AJAX، نحتاج إلى توفير إحصائيات تجميعية وبيانات العقود المبدئية للتبويبات
        if not self.request.headers.get("X-Requested-With") == "XMLHttpRequest":
            context["total_contracts"] = Contract.objects.count()
            context["active_contracts"] = Contract.objects.filter(
                status="active"
            ).count()
            context["expired_contracts"] = Contract.objects.filter(
                status="expired"
            ).count()
            context["expiring_soon"] = Contract.objects.filter(
                status="active",
                end_date__lte=timezone.now().date() + timedelta(days=30),
            ).count()

            context["total_poas"] = PowerOfAttorney.objects.count()
            context["active_poas"] = PowerOfAttorney.objects.filter(
                status="active"
            ).count()
            context["expired_poas"] = PowerOfAttorney.objects.filter(
                status="expired"
            ).count()
            context["expiring_soon_poas"] = PowerOfAttorney.objects.filter(
                status="expiring_soon"
            ).count()

            # جلب أول 50 عقد لعرضهم في التبويب الأول
            context["contracts"] = (
                Contract.objects.all()
                .select_related("client")
                .order_by("client__full_name")[:50]
            )
            context["active_tab"] = "poas"

        context["page_size_options"] = self.page_size_options
        context["current_page_size"] = self.get_paginate_by(self.object_list)
        context["contract_status_choices"] = Contract._meta.get_field("status").choices
        return context


class PowerOfAttorneyCreateView(
    PermissionRequiredMixin, LoginRequiredMixin, CreateView
):
    model = PowerOfAttorney
    form_class = PowerOfAttorneyForm
    template_name = "core/poa_form.html"
    success_url = reverse_lazy("core:power_of_attorney")
    permission_module = "power_of_attorney"
    permission_action = "add"

    def get(self, request, *args, **kwargs):
        if request.headers.get("X-Requested-With") == "XMLHttpRequest":
            self.object = None
            context = self.get_context_data()
            html = render_to_string(
                "core/includes/poa_form_modal_content.html", context, request=request
            )
            return JsonResponse({"html": html})
        return super().get(request, *args, **kwargs)

    def form_valid(self, form):
        self.object = form.save()
        if self.request.headers.get("X-Requested-With") == "XMLHttpRequest":
            return JsonResponse(
                {
                    "status": "success",
                    "message": f"تم إضافة التوكيل للعميل {self.object.client.full_name} بنجاح",
                    "poa_id": self.object.pk,
                }
            )
        messages.success(
            self.request,
            f"✅ تم إضافة التوكيل للعميل {self.object.client.full_name} بنجاح",
        )
        return redirect(self.get_success_url())

    def form_invalid(self, form):
        if self.request.headers.get("X-Requested-With") == "XMLHttpRequest":
            context = self.get_context_data(form=form)
            html = render_to_string(
                "core/includes/poa_form_modal_content.html",
                context,
                request=self.request,
            )
            return JsonResponse({"status": "error", "html": html}, status=400)
        messages.error(self.request, "❌ هناك أخطاء في نموذج التوكيل")
        return super().form_invalid(form)


class PowerOfAttorneyDetailView(PermissionRequiredMixin, LoginRequiredMixin, DetailView):
    model = PowerOfAttorney
    template_name = "core/poa_detail_modal.html"
    context_object_name = "poa"
    permission_module = "power_of_attorney"
    permission_action = "view"

    def get(self, request, *args, **kwargs):
        self.object = self.get_object()
        if request.headers.get("X-Requested-With") == "XMLHttpRequest":
            from core.models import OfficeProfile
            office = OfficeProfile.objects.first()
            html = render_to_string(self.template_name, {
                'poa': self.object,
                'office_profile': office
            }, request=request)
            return JsonResponse({'html': html})
        return super().get(request, *args, **kwargs)




class PowerOfAttorneyUpdateView(
    PermissionRequiredMixin, LoginRequiredMixin, UpdateView
):
    model = PowerOfAttorney
    form_class = PowerOfAttorneyForm
    template_name = "core/poa_form.html"
    success_url = reverse_lazy("core:power_of_attorney")
    permission_module = "power_of_attorney"
    permission_action = "change"

    def get(self, request, *args, **kwargs):
        self.object = self.get_object()
        if request.headers.get("X-Requested-With") == "XMLHttpRequest":
            context = self.get_context_data()
            html = render_to_string(
                "core/includes/poa_form_modal_content.html", context, request=request
            )
            return JsonResponse({"html": html})
        return super().get(request, *args, **kwargs)

    def form_valid(self, form):
        self.object = form.save()
        if self.request.headers.get("X-Requested-With") == "XMLHttpRequest":
            return JsonResponse(
                {
                    "status": "success",
                    "message": f"تم تحديث التوكيل للعميل {self.object.client.full_name} بنجاح",
                    "poa_id": self.object.pk,
                }
            )
        messages.success(
            self.request,
            f"✅ تم تحديث التوكيل للعميل {self.object.client.full_name} بنجاح",
        )
        return redirect(self.get_success_url())

    def form_invalid(self, form):
        if self.request.headers.get("X-Requested-With") == "XMLHttpRequest":
            self.object = self.get_object()
            context = self.get_context_data(form=form)
            html = render_to_string(
                "core/includes/poa_form_modal_content.html",
                context,
                request=self.request,
            )
            return JsonResponse({"status": "error", "html": html}, status=400)
        messages.error(self.request, "❌ هناك أخطاء في نموذج التوكيل")
        return super().form_invalid(form)


class PowerOfAttorneyDeleteView(RoleRequiredMixin, LoginRequiredMixin, DeleteView):
    role_required = [ROLE_ADMIN]
    model = PowerOfAttorney
    template_name = "core/poa_confirm_delete.html"
    success_url = reverse_lazy("core:power_of_attorney")

    def get(self, request, *args, **kwargs):
        self.object = self.get_object()
        if request.headers.get("X-Requested-With") == "XMLHttpRequest":
            html = render_to_string("core/includes/generic_delete_modal_content.html", {"object": self.object}, request=request)
            return JsonResponse({"html": html})
        return super().get(request, *args, **kwargs)

    def delete(self, request, *args, **kwargs):
        self.object = self.get_object()
        success_url = self.get_success_url()
        self.object.delete()
        if request.headers.get("X-Requested-With") == "XMLHttpRequest":
            return JsonResponse({"status": "success", "message": "✅ تم حذف الوكالة بنجاح"})
        messages.success(request, "✅ تم حذف الوكالة بنجاح")
        return redirect(success_url)


class DeclarationListView(PermissionRequiredMixin, LoginRequiredMixin, ListView):
    model = Declaration
    template_name = "core/declarations.html"
    context_object_name = "declarations"
    permission_module = "declarations"
    permission_action = "view"


class DeclarationCreateView(PermissionRequiredMixin, LoginRequiredMixin, CreateView):
    model = Declaration
    fields = "__all__"
    template_name = "core/declaration_form.html"
    success_url = reverse_lazy("core:declarations")
    permission_module = "declarations"
    permission_action = "add"


# ========================================
# Contracts Export Functions
# ========================================


@login_required
@permission_required("contracts", "view")
def export_contracts_excel(request):
    """Export contracts to Excel (unified export)."""
    service = UnifiedExportService(request)
    return service.export(CONTRACT_EXPORT_CONFIG, format="excel")


@login_required
@permission_required("contracts", "view")
def export_contracts_pdf(request):
    """Export contracts to PDF (unified export)."""
    service = UnifiedExportService(request)
    return service.export(CONTRACT_EXPORT_CONFIG, format="pdf")


def _get_filtered_contracts_queryset(request):
    queryset = Contract.objects.all().select_related("client")
    status = request.GET.get("status")
    if status:
        queryset = queryset.filter(status=status)
    ctype = request.GET.get("type")
    if ctype:
        queryset = queryset.filter(type=ctype)
    search = request.GET.get("search")
    if search:
        queryset = queryset.filter(
            Q(contract_number__icontains=search)
            | Q(client__full_name__icontains=search)
        )
    return queryset.order_by("client__full_name")


# ========================================
# Power of Attorney Export Functions
# ========================================


def _get_filtered_poa_queryset(request):
    queryset = PowerOfAttorney.objects.all().select_related("client")
    status = request.GET.get("status")
    if status:
        queryset = queryset.filter(status=status)
    ptype = request.GET.get("type")
    if ptype:
        queryset = queryset.filter(type=ptype)
    search = request.GET.get("search")
    if search:
        queryset = queryset.filter(
            Q(client__full_name__icontains=search) | Q(issuer__icontains=search)
        )
    return queryset.order_by("client__full_name")


@login_required
@permission_required("power_of_attorney", "view")
def export_poa_excel(request):
    """Export POAs to Excel (unified export)."""
    service = UnifiedExportService(request)
    return service.export(POA_EXPORT_CONFIG, format="excel")


@login_required
@permission_required("power_of_attorney", "view")
def export_poa_pdf(request):
    """Export POAs to PDF (unified export)."""
    service = UnifiedExportService(request)
    return service.export(POA_EXPORT_CONFIG, format="pdf")


# ============================================
# Unified Export: Row Mappers
# ============================================


def _map_contract_row(contract, is_pdf=False):
    """Map Contract instance to row data."""
    if is_pdf:
        return [
            contract.get_status_display() or "—",
            contract.end_date.strftime("%Y-%m-%d") if contract.end_date else "—",
            contract.start_date.strftime("%Y-%m-%d") if contract.start_date else "—",
            contract.get_type_display() if contract.type else "—",
            contract.client.full_name if contract.client else "—",
            contract.contract_number or "—",
        ]
    return [
        contract.contract_number or "",
        contract.client.full_name if contract.client else "",
        contract.get_type_display() if contract.type else "",
        contract.start_date.strftime("%Y-%m-%d") if contract.start_date else "",
        contract.end_date.strftime("%Y-%m-%d") if contract.end_date else "",
        contract.get_status_display() or "",
    ]


def _map_poa_row(poa, is_pdf=False):
    """Map PowerOfAttorney instance to row data."""
    if is_pdf:
        return [
            poa.get_status_display() or "—",
            poa.get_type_display() or "—",
            poa.issuer or "—",
            poa.expiry_date.strftime("%Y-%m-%d") if poa.expiry_date else "—",
            poa.issue_date.strftime("%Y-%m-%d") if poa.issue_date else "—",
            poa.client.full_name if poa.client else "—",
        ]
    return [
        poa.client.full_name if poa.client else "",
        poa.expiry_date.strftime("%Y-%m-%d") if poa.expiry_date else "",
        poa.issue_date.strftime("%Y-%m-%d") if poa.issue_date else "",
        poa.issuer or "",
        poa.get_type_display() if poa.type else "",
        poa.get_status_display() if poa.status else "",
    ]


# ============================================
# Unified Export: Configurations
# ============================================

CONTRACT_EXPORT_CONFIG = ExportConfig(
    model_name="العقود",
    queryset_fn=_get_filtered_contracts_queryset,
    excel_headers=[
        "رقم العقد",
        "العميل",
        "النوع",
        "تاريخ البداية",
        "تاريخ النهاية",
        "الحالة",
    ],
    pdf_headers=[
        "الحالة",
        "تاريخ النهاية",
        "تاريخ البداية",
        "النوع",
        "العميل",
        "رقم العقد",
    ],
    row_mapper=_map_contract_row,
    right_align_cols=[1, 4, 5],
    pdf_col_widths=[24 * mm, 28 * mm, 28 * mm, 28 * mm, 32 * mm, 28 * mm],
    theme_color="3B82F6",
    filename_prefix="contracts",
)

POA_EXPORT_CONFIG = ExportConfig(
    model_name="التوكيلات",
    queryset_fn=_get_filtered_poa_queryset,
    excel_headers=[
        "العميل",
        "تاريخ الانتهاء",
        "تاريخ الإصدار",
        "الجهة المصدرة",
        "النوع",
        "الحالة",
    ],
    pdf_headers=[
        "الحالة",
        "النوع",
        "الجهة المصدرة",
        "تاريخ الانتهاء",
        "تاريخ الإصدار",
        "العميل",
    ],
    row_mapper=_map_poa_row,
    right_align_cols=[1, 2, 5],
    pdf_col_widths=[28 * mm, 30 * mm, 35 * mm, 24 * mm, 24 * mm, 45 * mm],
    theme_color="10B981",
    filename_prefix="poa",
)
