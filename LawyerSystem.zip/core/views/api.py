import logging

from django.shortcuts import get_object_or_404
from django.http import JsonResponse
from django.contrib.auth.decorators import login_required
from django.core.cache import cache
from core.models import Case, Client, Opponent, OfficeProfile, Notification
from core.permissions import permission_required
from core.services.case_detail import (
    build_case_api_payload,
    build_case_detail_context,
    get_case_with_related,
)

logger = logging.getLogger(__name__)


def _server_error(message="حدث خطأ غير متوقع. برجاء المحاولة مرة أخرى.", status=500):
    return JsonResponse({"error": message}, status=status)


@login_required
@permission_required('cases', 'view')
def case_api_detail(request, pk):
    try:
        case = get_case_with_related(pk)
        
        if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
            context = build_case_detail_context(case)
            from django.template.loader import render_to_string
            html = render_to_string('core/case_detail_modal.html', context, request=request)
            return JsonResponse({'html': html})
        
        data = build_case_api_payload(case)
        return JsonResponse(data)
    except Case.DoesNotExist:
        return JsonResponse({'error': 'Case not found'}, status=404)
    except Exception:
        logger.exception("case_api_detail failed (pk=%s)", pk)
        return _server_error()

@login_required
@permission_required('clients', 'view')
def client_api_detail(request, pk):
    try:
        client = Client.objects.get(pk=pk)
        office = OfficeProfile.objects.first()

        # Calculate paid amount for invoices
        
        data = {
            'full_name': client.full_name,
            'type': client.type,
            'type_display': client.get_type_display(),
            'status': client.status,
            'status_display': client.get_status_display(),
            'national_id': client.national_id or '—',
            'commercial_register': client.commercial_register or '—',
            'tax_card': client.tax_card or '—',
            'phone': client.phone or '—',
            'additional_phone': client.additional_phone or '—',
            'job': client.job or '—',
            'address': client.address or '—',
            'notes': client.notes or '—',
            'created_at': client.created_at.strftime('%Y-%m-%d') if client.created_at else '—',
            
            'office': {
                'name': office.name if office else 'دِرْعٌ وَسَيْفٌ',
                'logo': office.logo.url if office and office.logo else '/static/images/logo.png',
                'phone': office.phone if office else '—',
                'address': office.address if office else '—',
            },

            'cases': [
                {
                    'case_number': c.case_number or '—',
                    'case_year': c.case_year or '—',
                    'subject': c.subject or '—',
                    'court': {'name': c.court.name} if c.court else None,
                    'case_type': c.case_type or '—',
                    'status_display': c.get_status_display(),
                } for c in client.cases.all().select_related('court')
            ],

            'contracts': [
                {
                    'contract_number': c.contract_number or '—',
                    'type_display': c.get_type_display() if hasattr(c, 'get_type_display') else (c.type or '—'),
                    'date': (
                        c.start_date.strftime('%Y-%m-%d')
                        if getattr(c, 'start_date', None)
                        else (c.end_date.strftime('%Y-%m-%d') if getattr(c, 'end_date', None) else '—')
                    ),
                    'status_display': c.get_status_display() if hasattr(c, 'get_status_display') else (c.status or '—'),
                } for c in client.contracts.all()
            ],

            'invoices': [
                {
                    'invoice_number': inv.invoice_number or '—',
                    'date': inv.date.strftime('%Y-%m-%d') if inv.date else '—',
                    'total_amount_formatted': f"{float(inv.total):,.2f}" if inv.total else '—',
                    'paid_amount_formatted': '0.00',
                    'remaining_amount_formatted': f"{float(inv.total):,.2f}" if inv.total else '—',
                    'status_display': inv.get_status_display() if hasattr(inv, 'get_status_display') else (inv.status or '—'),
                } for inv in client.invoices.all()
            ],

            'attachments': [
                {
                    'file_name': att.file.name.split('/')[-1] if att.file else '—',
                    'uploaded_at': att.uploaded_at.strftime('%Y-%m-%d') if hasattr(att, 'uploaded_at') and att.uploaded_at else '—',
                } for att in client.attachments.all()
            ]
        }
        return JsonResponse(data)
    except Client.DoesNotExist:
        return JsonResponse({'error': 'Client not found'}, status=404)
    except Exception:
        logger.exception("client_api_detail failed (pk=%s)", pk)
        return _server_error()

@login_required
@permission_required('opponents', 'view')
def opponent_api_detail(request, pk):
    try:
        opponent = Opponent.objects.get(pk=pk)
        data = {
            'name': opponent.name,
            'type': opponent.type,
            'type_display': opponent.get_type_display(),
            'phone': opponent.phone or '—',
            'opponent_lawyer': opponent.opponent_lawyer or '—',
            'job': opponent.job or '—',
            'business_activity': opponent.business_activity or '—',
            'address': opponent.address or '—',
            'notes': opponent.notes or '—',
            'is_active': opponent.is_active,
            'created_at': opponent.created_at.strftime('%Y-%m-%d') if opponent.created_at else '—',
            'updated_at': opponent.updated_at.strftime('%Y-%m-%d') if hasattr(opponent, 'updated_at') and opponent.updated_at else '—',
            'cases': []
        }
        for case in opponent.cases.all().select_related('client', 'court'):
            data['cases'].append({
                'case_number': case.case_number or '—',
                'case_year': case.case_year or '—',
                'subject': case.subject or '—',
                'client_name': case.client.full_name if case.client else '—',
                'case_type': case.case_type or '—',
                'court': case.court.name if case.court else '—',
                'status_display': case.get_status_display() or '—'
            })
        return JsonResponse(data)
    except Opponent.DoesNotExist:
        return JsonResponse({'error': 'Opponent not found'}, status=404)
    except Exception:
        logger.exception("opponent_api_detail failed (pk=%s)", pk)
        return _server_error()


@login_required
@permission_required('sessions', 'view')
def session_api_detail(request, pk):
    """API endpoint لتفاصيل الجلسة"""
    try:
        from core.models import Session
        
        session = Session.objects.select_related('case', 'case__client').get(pk=pk)
        data = {
            'case_id': session.case.id,
            'case_number': session.case.case_number or '—',
            'case_subject': session.case.subject or '—',
            'client_name': session.case.client.full_name if session.case.client else '—',
            'client_phone': session.case.client.phone if session.case.client else '—',
            'date': session.date.strftime('%Y-%m-%d') if session.date else '—',
            'time': session.time.strftime('%H:%M') if session.time else '—',
            'court': session.court.name if session.court else '—',
            'session_type': session.session_type or '—',
            'minutes': session.minutes or '—',
            'status': session.status,
            'status_display': session.get_status_display(),
            'created_at': session.case.created_at.strftime('%Y-%m-%d') if session.case.created_at else '—',
        }
        return JsonResponse(data)
    except Session.DoesNotExist:
        return JsonResponse({'error': 'Session not found'}, status=404)
    except Exception:
        logger.exception("session_api_detail failed (pk=%s)", pk)
        return _server_error()

@login_required
def notifications_list_api(request):
    """API endpoint لجلب قائمة الإشعارات"""
    notifications = Notification.objects.filter(
        target_user=request.user
    ).order_by('-created_at')[:10]  # آخر 10 إشعارات فقط
    
    data = []
    for notification in notifications:
        icon = 'fa-bell'
        color = '#64748b'
        bg_color = 'rgba(100,116,139,0.1)'
        
        if notification.notification_type == 'session':
            icon = 'fa-gavel'
            color = '#dc2626'
            bg_color = 'rgba(220,38,38,0.1)'
        elif notification.notification_type == 'payment':
            icon = 'fa-coins'
            color = '#059669'
            bg_color = 'rgba(5,150,105,0.1)'
        elif notification.notification_type == 'task':
            icon = 'fa-tasks'
            color = '#2563eb'
            bg_color = 'rgba(37,99,235,0.1)'
        elif notification.notification_type == 'case':
            icon = 'fa-briefcase'
            color = '#d97706'
            bg_color = 'rgba(217,119,6,0.1)'
        elif notification.notification_type == 'contract':
            icon = 'fa-file-contract'
            color = '#7c3aed'
            bg_color = 'rgba(124,58,237,0.1)'
        
        data.append({
            'id': notification.id,
            'message': notification.message,
            'type': notification.notification_type,
            'icon': icon,
            'color': color,
            'bg_color': bg_color,
            'is_read': notification.is_read,
            'created_at': notification.created_at.strftime('%d %b %Y - %I:%M %p'),
        })
    
    return JsonResponse({'notifications': data, 'count': len(data)})


@login_required
def notification_mark_as_read_api(request, pk):
    """API endpoint لتمييز إشعار كمقروء"""
    if request.method == 'POST':
        notification = get_object_or_404(Notification, pk=pk, target_user=request.user)
        notification.is_read = True
        notification.save()
        
        # تحديث الكاش
        cache_key = f'notification_cnt_{request.user.id}'
        cache.delete(cache_key)
        
        return JsonResponse({'status': 'success', 'id': pk})
    
    return JsonResponse({'status': 'error', 'message': 'Method not allowed'}, status=405)


@login_required
def notification_mark_all_as_read_api(request):
    """API endpoint لتمييز كل الإشعارات كمقروءة"""
    if request.method == 'POST':
        Notification.objects.filter(
            target_user=request.user,
            is_read=False
        ).update(is_read=True)
        
        # تحديث الكاش
        cache_key = f'notification_cnt_{request.user.id}'
        cache.delete(cache_key)
        
        return JsonResponse({'status': 'success'})
    
    return JsonResponse({'status': 'error', 'message': 'Method not allowed'}, status=405)


@login_required
def notification_delete_api(request, pk):
    """API endpoint لحذف إشعار"""
    if request.method == 'POST':
        notification = get_object_or_404(Notification, pk=pk, target_user=request.user)
        notification.delete()
        
        # تحديث الكاش
        cache_key = f'notification_cnt_{request.user.id}'
        cache.delete(cache_key)
        
        return JsonResponse({'status': 'success', 'id': pk})
    
    return JsonResponse({'status': 'error', 'message': 'Method not allowed'}, status=405)

@login_required
@permission_required('contracts', 'view')
def contract_api_detail(request, pk):
    """API endpoint لتفاصيل العقد"""
    try:
        from core.models import Contract
        contract = get_object_or_404(Contract.objects.select_related('client'), pk=pk)
        
        if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
            from django.template.loader import render_to_string
            office = OfficeProfile.objects.first()
            html = render_to_string('core/contract_detail_modal.html', {
                'contract': contract,
                'office_profile': office
            }, request=request)
            return JsonResponse({'html': html})
        
        data = {
            'id': contract.pk,
            'contract_number': contract.contract_number or '—',
            'title': contract.type or '—',
            'client_name': contract.client.full_name if contract.client else '—',
            'client_phone': contract.client.phone if contract.client else '—',
            'case_subject': '—', # لا توجد علاقة مباشرة في الموديل الحالي
            'start_date': contract.start_date.strftime('%Y-%m-%d') if contract.start_date else '—',
            'end_date': contract.end_date.strftime('%Y-%m-%d') if contract.end_date else '—',
            'status': contract.status,
            'status_display': contract.get_status_display(),
            'notes': contract.notes or '—',
        }
        return JsonResponse(data)
    except Exception:
        logger.exception("contract_api_detail failed (pk=%s)", pk)
        return _server_error()


@login_required
@permission_required('power_of_attorney', 'view')
def poa_api_detail(request, pk):
    """API endpoint لتفاصيل التوكيل"""
    try:
        from core.models import PowerOfAttorney
        poa = get_object_or_404(PowerOfAttorney.objects.select_related('client'), pk=pk)
        
        if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
            from django.template.loader import render_to_string
            office = OfficeProfile.objects.first()
            html = render_to_string('core/poa_detail_modal.html', {
                'poa': poa,
                'office_profile': office
            }, request=request)
            return JsonResponse({'html': html})
        
        data = {
            'id': poa.pk,
            'poa_number': '—', # الموديل لا يحتوي على رقم توكيل مستقل
            'client_name': poa.client.full_name if poa.client else '—',
            'client_phone': poa.client.phone if poa.client else '—',
            'type': poa.type,
            'type_display': poa.get_type_display(),
            'office': poa.issuer or '—',
            'issue_date': poa.issue_date.strftime('%Y-%m-%d') if poa.issue_date else '—',
            'expiry_date': poa.expiry_date.strftime('%Y-%m-%d') if poa.expiry_date else '—',
            'notes': poa.notes or '—',
        }
        return JsonResponse(data)
    except Exception:
        logger.exception("poa_api_detail failed (pk=%s)", pk)
        return _server_error()


@login_required
@permission_required('expenses', 'view')
def expense_api_detail(request, pk):
    from core.models import Expense
    try:
        expense = get_object_or_404(Expense.objects.select_related('case', 'case__client'), pk=pk)
        office = OfficeProfile.objects.first()

        if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
            from django.template.loader import render_to_string
            html = render_to_string('core/expense_detail_modal.html', {
                'expense': expense,
                'office_profile': office
            }, request=request)
            return JsonResponse({'html': html})

        data = {
            'id': expense.pk,
            'expense_type': expense.expense_type,
            'expense_type_display': expense.get_expense_type_display(),
            'description': expense.description,
            'category': expense.category,
            'category_display': expense.get_category_display(),
            'amount': str(expense.amount),
            'amount_formatted': f"{float(expense.amount):,.2f}",
            'date': expense.date.strftime('%Y-%m-%d') if expense.date else '—',
            'date_formatted': expense.date.strftime('%d/%m/%Y') if expense.date else '—',
            'has_receipt': bool(expense.receipt),
            'receipt_url': expense.receipt.url if expense.receipt else None,
            'created_at': expense.created_at.strftime('%Y-%m-%d %H:%M') if expense.created_at else '—',
            'updated_at': expense.updated_at.strftime('%Y-%m-%d %H:%M') if expense.updated_at else '—',
            'case': {
                'id': expense.case.pk,
                'case_number': expense.case.case_number,
                'client_name': expense.case.client.full_name if expense.case.client else '—',
                'subject': expense.case.subject if expense.case else '—',
                'court_name': expense.case.court.name if expense.case.court else '—',
                'status_display': expense.case.get_status_display() if expense.case else '—',
            } if expense.case else None,
            'office': {
                'name': office.name if office else 'دِرْعٌ وَسَيْفٌ',
                'logo': office.logo.url if office and office.logo else '/static/images/logo.png',
                'phone': office.phone if office else '—',
                'address': office.address if office else '—',
            },
        }
        return JsonResponse(data)
    except Exception:
        logger.exception("expense_api_detail failed (pk=%s)", pk)
        return _server_error()


@login_required
@permission_required('tasks', 'view')
def task_api_detail(request, pk):
    """API endpoint لتفاصيل المهمة"""
    try:
        from core.models import Task
        task = get_object_or_404(Task.objects.select_related('case', 'assigned_to'), pk=pk)
        
        if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
            from django.template.loader import render_to_string
            html = render_to_string('core/task_detail_modal.html', {
                'task': task
            }, request=request)
            return JsonResponse({'html': html})
        
        data = {
            'id': task.pk,
            'title': task.title,
            'description': task.description or '—',
            'status': task.status,
            'status_display': task.get_status_display(),
            'priority': task.priority,
            'priority_display': task.get_priority_display(),
            'due_date': task.due_date.strftime('%Y-%m-%d') if task.due_date else '—',
            'assigned_to': task.assigned_to.get_full_name() if task.assigned_to else (task.assigned_to.username if task.assigned_to else '—'),
            'case_number': task.case.case_number if task.case else '—',
        }
        return JsonResponse(data)
    except Exception:
        logger.exception("task_api_detail failed (pk=%s)", pk)
        return _server_error()


@login_required
@permission_required('invoices', 'view')
def invoice_api_detail(request, pk):
    """API endpoint لتفاصيل الفاتورة"""
    try:
        from core.models import Invoice
        invoice = get_object_or_404(Invoice.objects.select_related('client'), pk=pk)
        
        if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
            from django.template.loader import render_to_string
            office = OfficeProfile.objects.first()
            html = render_to_string('core/invoice_detail_modal.html', {
                'invoice': invoice,
                'office_profile': office
            }, request=request)
            return JsonResponse({'html': html})
        
        return JsonResponse({
            'id': invoice.pk,
            'invoice_number': invoice.invoice_number,
            'client_name': invoice.client.full_name,
            'total': str(invoice.total),
            'status': invoice.status,
        })
    except Exception:
        logger.exception("invoice_api_detail failed (pk=%s)", pk)
        return _server_error()


@login_required
@permission_required('appointments', 'view')
def appointment_api_detail(request, pk):
    """API endpoint لتفاصيل الموعد"""
    try:
        from core.models import Appointment
        appointment = get_object_or_404(Appointment.objects.select_related('client', 'case'), pk=pk)
        
        if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
            from django.template.loader import render_to_string
            html = render_to_string('core/appointment_detail_modal.html', {
                'appointment': appointment
            }, request=request)
            return JsonResponse({'html': html})
        
        return JsonResponse({
            'id': appointment.pk,
            'client_name': appointment.client.full_name if appointment.client else '—',
            'datetime': appointment.datetime.strftime('%Y-%m-%d %H:%M'),
            'location': appointment.location or '—',
            'status': appointment.status,
        })
    except Exception:
        logger.exception("appointment_api_detail failed (pk=%s)", pk)
        return _server_error()
