from .dashboard import DashboardView
from .cases import (
    CaseListView, CaseCreateView, CaseDetailView, CaseUpdateView, CaseDeleteView, check_case_duplicate,
    SessionListView, SessionCreateView, SessionDetailView, SessionUpdateView, SessionDeleteView,
    DocumentListView, DocumentCreateView, export_cases_excel, export_cases_pdf,
    export_sessions_excel, export_sessions_pdf
)
from .clients import (
    ClientListView, ClientCreateView, ClientDetailView, ClientUpdateView, ClientDeleteView, check_client_duplicate, check_opponent_duplicate,
    OpponentListView, OpponentCreateView, OpponentDetailView, OpponentUpdateView, OpponentDeleteView,
    export_clients_excel, export_clients_pdf,
    export_opponents_excel, export_opponents_pdf
)
from .finance import (
    FeeListView, FeeCreateView, FeeUpdateView, FeeDeleteView,
    ExpenseListView, ExpenseCreateView,
    ExpenseUpdateView, ExpenseDeleteView,
    InvoiceListView, InvoiceCreateView, InvoiceUpdateView, InvoiceDeleteView,
    export_finance_excel, export_finance_pdf,
    export_fees_excel, export_fees_pdf,
    export_expenses_excel, export_expenses_pdf,
    export_office_expenses_excel, export_office_expenses_pdf,
    export_invoices_excel, export_invoices_pdf
)
from .tasks import (
    TaskListView, TaskCreateView, TaskUpdateView, TaskDeleteView,
    AppointmentListView, AppointmentCreateView, AppointmentUpdateView, AppointmentDeleteView,
    CalendarView
)
from .legal import (
    ContractListView, ContractCreateView, ContractDetailView, ContractUpdateView, ContractDeleteView,
    PowerOfAttorneyListView, PowerOfAttorneyCreateView, PowerOfAttorneyDetailView, PowerOfAttorneyUpdateView, PowerOfAttorneyDeleteView,
    DeclarationListView, DeclarationCreateView, ConsultationListView,
    export_contracts_excel, export_contracts_pdf, export_poa_excel, export_poa_pdf
)
from .system import (
    SettingsView, UserCreateView, UserUpdateView, UserDeleteView, logout_view, theme_preference, close_desktop_app
)
from .reports import ReportsView
from .api import (
    case_api_detail, client_api_detail, opponent_api_detail, session_api_detail,
    contract_api_detail, poa_api_detail, expense_api_detail,
    task_api_detail, invoice_api_detail, appointment_api_detail,
    notifications_list_api, notification_mark_as_read_api, notification_mark_all_as_read_api, notification_delete_api
)
