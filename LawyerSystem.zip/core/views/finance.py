from django.shortcuts import redirect
from django.views.generic import DetailView, CreateView, UpdateView, DeleteView
from django.urls import reverse_lazy
from django.contrib.auth.mixins import LoginRequiredMixin
from django.contrib.auth.decorators import login_required
from django.db.models import Q, Sum, Count
from django.contrib import messages
from django.http import JsonResponse
from django.template.loader import render_to_string
from django.conf import settings
from core.services.excel_export import ExcelExporter
from core.services.pdf_export import PDFExporter
from reportlab.lib.units import mm
from core.services.export_helpers import UnifiedExportService, ExportConfig
from core.forms import ExpenseForm
from core.permissions import (
    PermissionRequiredMixin,
    RoleRequiredMixin,
    ROLE_ADMIN,
    permission_required,
)
from core.models import Fee, Expense, Invoice
from .mixins import FilteredListViewMixin

# Maximum rows for export to prevent memory issues
MAX_EXPORT_ROWS = 10000


class FeeListView(PermissionRequiredMixin, LoginRequiredMixin, FilteredListViewMixin):
    model = Fee
    template_name = "core/fees.html"
    context_object_name = "fees"
    paginate_by = 50
    permission_module = "fees"
    permission_action = "view"

    def get_queryset(self):
        queryset = Fee.objects.all().select_related("case__client")

        # الفلترة بواسطة الميكسن
        queryset = self.apply_filters(
            queryset,
            {
                "status": "status",
                "case__client": "client",
            },
        )

        search = self.request.GET.get("search")
        if search:
            queryset = queryset.filter(
                Q(case__case_number__icontains=search)
                | Q(case__client__full_name__icontains=search)
                | Q(case__subject__icontains=search)
            )
        return queryset.order_by("-id")

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        stats = Fee.objects.aggregate(
            total=Sum("agreed_amount"),
            paid=Sum("agreed_amount", filter=Q(status="paid")),
            pending=Sum("agreed_amount", filter=Q(status="pending")),
        )
        context["total_fees"] = stats["total"] or 0
        context["paid_fees"] = stats["paid"] or 0
        context["pending_fees"] = stats["pending"] or 0
        from core.models import Case

        context["cases"] = (
            Case.objects.all()
            .only("id", "case_number", "client__full_name")
            .select_related("client")
            .order_by("-id")
        )
        return context


class FeeCreateView(PermissionRequiredMixin, LoginRequiredMixin, CreateView):
    model = Fee
    fields = ["case", "fee_type", "agreed_amount", "status"]
    template_name = "core/fee_form.html"
    success_url = reverse_lazy("core:fees")
    permission_module = "fees"
    permission_action = "add"

    def form_valid(self, form):
        messages.success(self.request, "✅ تم إضافة الأتعاب بنجاح")
        return super().form_valid(form)


class FeeUpdateView(PermissionRequiredMixin, LoginRequiredMixin, UpdateView):
    model = Fee
    fields = ["case", "fee_type", "agreed_amount", "status"]
    template_name = "core/fee_form.html"
    success_url = reverse_lazy("core:fees")
    permission_module = "fees"
    permission_action = "change"

    def get(self, request, *args, **kwargs):
        self.object = self.get_object()
        if request.headers.get("X-Requested-With") == "XMLHttpRequest":
            context = self.get_context_data()
            html = render_to_string(
                "core/includes/fee_form_modal_content.html", context, request=request
            )
            return JsonResponse({"html": html})
        return super().get(request, *args, **kwargs)

    def form_valid(self, form):
        self.object = form.save()
        if self.request.headers.get("X-Requested-With") == "XMLHttpRequest":
            return JsonResponse(
                {"status": "success", "message": "تم تحديث الأتعاب بنجاح"}
            )
        messages.success(self.request, "✅ تم تحديث الأتعاب بنجاح")
        return super().form_valid(form)


class FeeDeleteView(RoleRequiredMixin, LoginRequiredMixin, DeleteView):
    role_required = [ROLE_ADMIN]
    model = Fee
    template_name = "core/fee_confirm_delete.html"
    success_url = reverse_lazy("core:fees")

    def delete(self, request, *args, **kwargs):
        self.object = self.get_object()
        success_url = self.get_success_url()
        self.object.delete()
        if request.headers.get("X-Requested-With") == "XMLHttpRequest":
            return JsonResponse(
                {"status": "success", "message": "تم حذف الأتعاب بنجاح"}
            )
        messages.success(request, "✅ تم حذف الأتعاب بنجاح")
        return redirect(success_url)


class ExpenseListView(
    PermissionRequiredMixin, LoginRequiredMixin, FilteredListViewMixin
):
    model = Expense
    template_name = "core/expenses.html"
    context_object_name = "expenses"
    paginate_by = 25
    permission_module = "expenses"
    permission_action = "view"

    def get(self, request, *args, **kwargs):
        # Handle AJAX requests for filtering
        if request.headers.get("X-Requested-With") == "XMLHttpRequest":
            try:
                self.object_list = self.get_queryset()
                context = self.get_context_data()
                from django.template.loader import render_to_string
                from django.http import JsonResponse
                from django.db.models import Sum

                # Render only the table container based on active tab
                active_tab = request.GET.get('tab', 'case')
                if active_tab == 'office':
                    html = render_to_string(
                        "core/partials/office_expenses_table.html", context, request=request
                    )
                else:
                    html = render_to_string(
                        "core/partials/case_expenses_table.html", context, request=request
                    )

                # حساب الإحصاءات المحدثة
                total_stats = Expense.objects.aggregate(total=Sum("amount"))
                total_expenses = total_stats["total"] or 0
                
                case_expenses = Expense.objects.filter(expense_type="case").aggregate(
                    total=Sum("amount")
                )
                case_expenses_total = case_expenses["total"] or 0
                
                office_expenses = Expense.objects.filter(expense_type="office").aggregate(
                    total=Sum("amount")
                )
                office_expenses_total = office_expenses["total"] or 0
                
                # تنسيق الإحصاءات
                def format_currency(value):
                    try:
                        return f"{float(value):,.2f} {getattr(settings, 'CURRENCY_SYMBOL', 'ج.م')}"
                    except (ValueError, TypeError):
                        return f"{value} {getattr(settings, 'CURRENCY_SYMBOL', 'ج.م')}"

                # Return both HTML, count and stats
                return JsonResponse(
                    {
                        "html": html,
                        "count": self.object_list.count(),
                        "stats": {
                            "total": format_currency(total_expenses),
                            "case_expenses": format_currency(case_expenses_total),
                            "office_expenses": format_currency(office_expenses_total),
                        }
                    }
                )
            except Exception as e:
                return JsonResponse({"error": str(e)}, status=500)

        return super().get(request, *args, **kwargs)

    def get_queryset(self):
        queryset = Expense.objects.all().select_related("case")
        active_tab = self.request.GET.get("tab", "case")

        # فلترة النوع حسب التبويب النشط
        queryset = queryset.filter(expense_type=active_tab)

        # الفلاتر الإضافية
        queryset = self.apply_filters(
            queryset,
            {
                "category": "category",
            },
        )

        # فلتر التاريخ لمصروفات المكتب فقط
        if active_tab == "office":
            date_filter = self.request.GET.get("date_filter")
            from django.utils import timezone
            from datetime import timedelta, datetime
            
            if date_filter and date_filter != "all":
                now = timezone.now()
                today = now.date()
                
                if date_filter == "today":
                    queryset = queryset.filter(date=today)
                elif date_filter == "week":
                    # بداية الأسبوع (السبت)
                    week_start = today - timedelta(days=today.weekday() + 1)
                    week_end = week_start + timedelta(days=6)
                    queryset = queryset.filter(date__gte=week_start, date__lte=week_end)
                elif date_filter == "month":
                    queryset = queryset.filter(date__year=today.year, date__month=today.month)
                elif date_filter == "year":
                    queryset = queryset.filter(date__year=today.year)
                elif date_filter == "custom":
                    start_date = self.request.GET.get("start_date")
                    end_date = self.request.GET.get("end_date")
                    if start_date:
                        queryset = queryset.filter(date__gte=start_date)
                    if end_date:
                        queryset = queryset.filter(date__lte=end_date)

        # فلتر حسب القضية (فقط لمصروفات القضايا)
        if active_tab == "case":
            case_id = self.request.GET.get("case")
            if case_id:
                queryset = queryset.filter(case_id=case_id)

        # البحث العام
        search = self.request.GET.get("search")
        if search:
            if active_tab == "case":
                queryset = queryset.filter(
                    Q(description__icontains=search)
                    | Q(case__case_number__icontains=search)
                )
            else:
                queryset = queryset.filter(description__icontains=search)

        return queryset.order_by("-date")

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)

        # إحصائيات المصروفات
        total_stats = Expense.objects.aggregate(total=Sum("amount"))
        context["total_expenses"] = total_stats["total"] or 0

        # مصروفات القضايا
        case_expenses = Expense.objects.filter(expense_type="case").aggregate(
            total=Sum("amount")
        )
        context["case_expenses_total"] = case_expenses["total"] or 0

        # مصروفات المكتب
        office_expenses = Expense.objects.filter(expense_type="office").aggregate(
            total=Sum("amount")
        )
        context["office_expenses_total"] = office_expenses["total"] or 0

        from core.models import Case, ExpenseCategory

        context["cases"] = (
            Case.objects.all()
            .only("id", "case_number", "client__full_name")
            .select_related("client")
            .order_by("-id")
        )
        context["expense_categories"] = ExpenseCategory.choices

        # التبويب النشط
        context["active_tab"] = self.request.GET.get("tab", "case")
        
        # حساب عدد المصروفات لكل تبويب للعدادات
        active_tab = self.request.GET.get("tab", "case")
        if active_tab == "office":
            context["office_expenses_count"] = self.object_list.count()
        else:
            context["office_expenses_count"] = Expense.objects.filter(expense_type="office").count()
        
        # إضافة بيانات منفصلة لكل جدول
        # بيانات مصروفات القضايا للقالب الجزئي
        if hasattr(self, 'object_list') and self.object_list is not None:
            # إذا كان هناك object_list (من get_queryset)، استخدمه
            active_tab = self.request.GET.get("tab", "case")
            if active_tab == "office":
                context["office_expenses_data"] = self.object_list
                context["case_expenses_data"] = Expense.objects.filter(expense_type="case").select_related("case").order_by("-date")
            else:
                context["case_expenses_data"] = self.object_list
                context["office_expenses_data"] = Expense.objects.filter(expense_type="office").select_related("case").order_by("-date")
        else:
            # التحميل الأول للصفحة (ليس AJAX)
            context["case_expenses_data"] = Expense.objects.filter(expense_type="case").select_related("case").order_by("-date")
            context["office_expenses_data"] = Expense.objects.filter(expense_type="office").select_related("case").order_by("-date")

        return context


class ExpenseCreateView(PermissionRequiredMixin, LoginRequiredMixin, CreateView):
    model = Expense
    form_class = ExpenseForm
    template_name = "core/expense_form.html"
    success_url = reverse_lazy("core:expenses")
    permission_module = "expenses"
    permission_action = "add"

    def get_initial(self):
        initial = super().get_initial()
        initial["expense_type"] = self.request.GET.get("expense_type", "case")
        return initial
    
    def get_form_kwargs(self):
        kwargs = super().get_form_kwargs()
        # تأكد من تمرير initial بشكل صحيح
        if 'initial' not in kwargs:
            kwargs['initial'] = {}
        kwargs['initial']['expense_type'] = self.request.GET.get("expense_type", "case")
        return kwargs

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        from core.models import Case

        context["cases"] = Case.objects.all().select_related("client").order_by("-id")
        context["expense"] = getattr(self, "object", None)
        # Get expense_type from GET (initial load) or POST (validation errors)
        expense_type = (
            self.request.GET.get("expense_type")
            or self.request.POST.get("expense_type")
            or "case"
        )
        context["selected_expense_type"] = expense_type
        return context

    def get(self, request, *args, **kwargs):
        self.object = None
        if request.headers.get("X-Requested-With") == "XMLHttpRequest":
            context = self.get_context_data()
            # اختيار القالب بناءً على نوع المصروف
            expense_type = request.GET.get("expense_type", "case")
            if expense_type == "office":
                template_name = "core/includes/office_expense_form_modal_content.html"
            else:
                template_name = "core/includes/case_expense_form_modal_content.html"
            
            html = render_to_string(
                template_name,
                context,
                request=request,
            )
            return JsonResponse({"html": html})
        return super().get(request, *args, **kwargs)

    def form_valid(self, form):
        # تعيين نوع المصروف يدوياً بما أنه تمت إزالته من النموذج
        self.object = form.save(commit=False)
        # Get expense_type from POST (hidden input) with fallback to GET for compatibility
        expense_type = self.request.POST.get("expense_type") or self.request.GET.get(
            "expense_type", "case"
        )
        self.object.expense_type = expense_type
        self.object.save()
        form.save_m2m()

        if self.request.headers.get("X-Requested-With") == "XMLHttpRequest":
            return JsonResponse(
                {
                    "status": "success",
                    "message": "تم إضافة المصروف بنجاح",
                    "expense_id": self.object.pk,
                    "expense_type": self.object.expense_type,
                }
            )
        messages.success(self.request, "✅ تم إضافة المصروف بنجاح")
        return super().form_valid(form)

    def form_invalid(self, form):
        if self.request.headers.get("X-Requested-With") == "XMLHttpRequest":
            self.object = None
            context = self.get_context_data(form=form)
            html = render_to_string(
                "core/includes/expense_form_modal_content.html",
                context,
                request=self.request,
            )
            return JsonResponse({"status": "error", "html": html}, status=400)
        return super().form_invalid(form)


class ExpenseUpdateView(PermissionRequiredMixin, LoginRequiredMixin, UpdateView):
    model = Expense
    form_class = ExpenseForm
    template_name = "core/expense_form.html"
    success_url = reverse_lazy("core:expenses")
    permission_module = "expenses"
    permission_action = "change"

    def get_form_kwargs(self):
        kwargs = super().get_form_kwargs()
        # تأكد من تمرير expense_type من الكائن الموجود
        if self.object and hasattr(self.object, 'expense_type'):
            if 'initial' not in kwargs:
                kwargs['initial'] = {}
            kwargs['initial']['expense_type'] = self.object.expense_type
        return kwargs

    def get(self, request, *args, **kwargs):
        self.object = self.get_object()
        if request.headers.get("X-Requested-With") == "XMLHttpRequest":
            context = self.get_context_data()
            # اختيار القالب بناءً على نوع المصروف من الكائن
            expense_type = self.object.expense_type if self.object else "case"
            if expense_type == "office":
                template_name = "core/includes/office_expense_form_modal_content.html"
            else:
                template_name = "core/includes/case_expense_form_modal_content.html"
            
            html = render_to_string(
                template_name,
                context,
                request=request,
            )
            return JsonResponse({"html": html})
        return super().get(request, *args, **kwargs)

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        from core.models import Case

        context["cases"] = Case.objects.all().select_related("client").order_by("-id")
        context["expense"] = self.object
        context["selected_expense_type"] = (
            self.object.expense_type if self.object else "case"
        )
        return context

    def form_valid(self, form):
        if self.request.headers.get("X-Requested-With") == "XMLHttpRequest":
            self.object = form.save()
            return JsonResponse(
                {
                    "status": "success",
                    "message": "تم تحديث المصروف بنجاح",
                    "expense_id": self.object.pk,
                    "expense_type": self.object.expense_type,
                }
            )
        messages.success(self.request, "✅ تم تحديث المصروف بنجاح")
        return super().form_valid(form)

    def form_invalid(self, form):
        if self.request.headers.get("X-Requested-With") == "XMLHttpRequest":
            self.object = self.get_object()
            context = self.get_context_data(form=form)
            html = render_to_string(
                "core/includes/expense_form_modal_content.html",
                context,
                request=self.request,
            )
            return JsonResponse({"status": "error", "html": html}, status=400)
        return super().form_invalid(form)


class ExpenseDeleteView(RoleRequiredMixin, LoginRequiredMixin, DeleteView):
    role_required = [ROLE_ADMIN]
    model = Expense
    template_name = "core/expense_confirm_delete.html"
    success_url = reverse_lazy("core:expenses")

    def get(self, request, *args, **kwargs):
        self.object = self.get_object()
        if request.headers.get("X-Requested-With") == "XMLHttpRequest":
            html = render_to_string(
                "core/includes/expense_delete_modal_content.html",
                self.get_context_data(object=self.object),
                request=request,
            )
            return JsonResponse({"html": html})
        return super().get(request, *args, **kwargs)

    def post(self, request, *args, **kwargs):
        self.object = self.get_object()
        description = self.object.description
        expense_type = self.object.expense_type
        self.object.delete()
        if request.headers.get("X-Requested-With") == "XMLHttpRequest":
            return JsonResponse(
                {
                    "status": "success",
                    "message": f'تم حذف المصروف "{description}" بنجاح',
                    "expense_type": expense_type,
                }
            )
        messages.success(request, f'✅ تم حذف المصروف "{description}" بنجاح')
        return redirect(self.get_success_url())


class InvoiceListView(
    PermissionRequiredMixin, LoginRequiredMixin, FilteredListViewMixin
):
    model = Invoice
    template_name = "core/invoices.html"
    context_object_name = "invoices"
    paginate_by = 50
    permission_module = "invoices"
    permission_action = "view"

    def get_queryset(self):
        queryset = Invoice.objects.all().select_related("client")

        queryset = self.apply_filters(
            queryset,
            {
                "status": "status",
                "client": "client",
            },
        )

        search = self.request.GET.get("search")
        if search:
            queryset = queryset.filter(
                Q(invoice_number__icontains=search)
                | Q(client__full_name__icontains=search)
            )
        return queryset.order_by("-id")

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        invoice_stats = Invoice.objects.aggregate(
            count_all=Count("id"),
            paid=Count("id", filter=Q(status="paid")),
            pending=Count("id", filter=Q(status="pending")),
            cancelled=Count("id", filter=Q(status="cancelled")),
            total_paid_amount=Sum("total", filter=Q(status="paid")),
            total_pending_amount=Sum("total", filter=Q(status="pending")),
        )
        context["total_invoices"] = invoice_stats["count_all"]
        context["paid_invoices"] = invoice_stats["paid"]
        context["pending_invoices"] = invoice_stats["pending"]
        context["cancelled_invoices"] = invoice_stats["cancelled"]
        context["total_amount"] = invoice_stats["total_paid_amount"] or 0
        context["pending_amount"] = invoice_stats["total_pending_amount"] or 0
        return context


class InvoiceCreateView(PermissionRequiredMixin, LoginRequiredMixin, CreateView):
    model = Invoice
    fields = ["client", "subtotal", "tax_rate", "status", "date", "due_date"]
    template_name = "core/invoice_form.html"
    success_url = reverse_lazy("core:invoices")
    permission_module = "invoices"
    permission_action = "add"

    def get(self, request, *args, **kwargs):
        self.object = None
        if request.headers.get("X-Requested-With") == "XMLHttpRequest":
            context = self.get_context_data()
            html = render_to_string(
                "core/includes/invoice_form_modal_content.html",
                context,
                request=request,
            )
            return JsonResponse({"html": html})
        return super().get(request, *args, **kwargs)

    def form_valid(self, form):
        self.object = form.save()
        if self.request.headers.get("X-Requested-With") == "XMLHttpRequest":
            return JsonResponse(
                {"status": "success", "message": "تم إنشاء الفاتورة بنجاح"}
            )
        messages.success(self.request, "✅ تم إنشاء الفاتورة بنجاح")
        return super().form_valid(form)

    def form_invalid(self, form):
        if self.request.headers.get("X-Requested-With") == "XMLHttpRequest":
            context = self.get_context_data(form=form)
            html = render_to_string(
                "core/includes/invoice_form_modal_content.html",
                context,
                request=self.request,
            )
            return JsonResponse({"status": "error", "html": html}, status=400)
        return super().form_invalid(form)


class InvoiceUpdateView(PermissionRequiredMixin, LoginRequiredMixin, UpdateView):
    model = Invoice
    fields = ["client", "subtotal", "tax_rate", "status", "date", "due_date"]
    template_name = "core/invoice_form.html"
    success_url = reverse_lazy("core:invoices")
    permission_module = "invoices"
    permission_action = "change"

    def get(self, request, *args, **kwargs):
        self.object = self.get_object()
        if request.headers.get("X-Requested-With") == "XMLHttpRequest":
            context = self.get_context_data()
            html = render_to_string(
                "core/includes/invoice_form_modal_content.html",
                context,
                request=request,
            )
            return JsonResponse({"html": html})
        return super().get(request, *args, **kwargs)

    def form_valid(self, form):
        self.object = form.save()
        if self.request.headers.get("X-Requested-With") == "XMLHttpRequest":
            return JsonResponse(
                {"status": "success", "message": "تم تحديث الفاتورة بنجاح"}
            )
        messages.success(self.request, "✅ تم تحديث الفاتورة بنجاح")
        return super().form_valid(form)

    def form_invalid(self, form):
        if self.request.headers.get("X-Requested-With") == "XMLHttpRequest":
            context = self.get_context_data(form=form)
            html = render_to_string(
                "core/includes/invoice_form_modal_content.html",
                context,
                request=self.request,
            )
            return JsonResponse({"status": "error", "html": html}, status=400)
        return super().form_invalid(form)


class InvoiceDeleteView(RoleRequiredMixin, LoginRequiredMixin, DeleteView):
    role_required = [ROLE_ADMIN]
    model = Invoice
    template_name = "core/invoice_confirm_delete.html"
    success_url = reverse_lazy("core:invoices")

    def get(self, request, *args, **kwargs):
        self.object = self.get_object()
        if request.headers.get("X-Requested-With") == "XMLHttpRequest":
            context = self.get_context_data()
            html = render_to_string(
                "core/includes/invoice_delete_modal_content.html",
                context,
                request=request,
            )
            return JsonResponse({"html": html})
        return super().get(request, *args, **kwargs)

    def delete(self, request, *args, **kwargs):
        obj = self.get_object()
        invoice_number = obj.invoice_number
        success_url = self.get_success_url()
        obj.delete()
        if request.headers.get("X-Requested-With") == "XMLHttpRequest":
            return JsonResponse(
                {
                    "status": "success",
                    "message": f"تم حذف الفاتورة {invoice_number} بنجاح",
                }
            )
        messages.success(request, f"✅ تم حذف الفاتورة {invoice_number} بنجاح")
        return redirect(success_url)


@login_required
@permission_required("fees", "view")
@permission_required("expenses", "view")
@permission_required("invoices", "view")
def export_finance_excel(request):
    """Export comprehensive financial report (Fees, Expenses, Invoices)."""
    # 1. Fees Sheet
    fees_headers = [
        "رقم القضية",
        "العميل",
        "نوع الأتعاب",
        "المبلغ المتفق عليه",
        "الحالة",
    ]
    exporter = ExcelExporter(title="الأتعاب", headers=fees_headers, fill_color="4F46E5")
    exporter.apply_headers()

    # تحسين الاستعلام + منع تحميل كل السجلات
    fees = Fee.objects.select_related("case", "case__client").all()[:MAX_EXPORT_ROWS]
    for row_num, fee in enumerate(fees, 2):
        row_data = [
            fee.case.case_number or "",
            fee.case.client.full_name if fee.case.client else "",
            fee.get_fee_type_display(),
            float(fee.agreed_amount),
            fee.get_status_display(),
        ]
        exporter.write_row(row_num, row_data, right_align_cols=[4])

    # 2. Expenses Sheet
    exp_headers = ["التاريخ", "الوصف", "الفئة", "المبلغ", "القضية المرتبطة"]
    exporter.add_sheet("المصروفات", exp_headers, fill_color="EF4444")

    # تحسين الاستعلام + منع تحميل كل السجلات
    expenses = Expense.objects.select_related("case").all()[:MAX_EXPORT_ROWS]
    for row_num, exp in enumerate(expenses, 2):
        row_data = [
            exp.date.strftime("%Y-%m-%d") if exp.date else "",
            exp.description or "",
            exp.get_category_display(),
            float(exp.amount),
            exp.case.case_number if exp.case else "مكتب",
        ]
        exporter.write_row(row_num, row_data, right_align_cols=[1, 4])

    # 3. Invoices Sheet
    inv_headers = [
        "رقم الفاتورة",
        "العميل",
        "التاريخ",
        "المبلغ الفرعي",
        "الضريبة",
        "الإجمالي",
        "الحالة",
    ]
    exporter.add_sheet("الفواتير", inv_headers, fill_color="10B981")

    # تحسين الاستعلام + منع تحميل كل السجلات
    invoices = Invoice.objects.select_related("client").all()[:MAX_EXPORT_ROWS]
    for row_num, inv in enumerate(invoices, 2):
        row_data = [
            inv.invoice_number or "",
            inv.client.full_name if inv.client else "",
            inv.date.strftime("%Y-%m-%d") if inv.date else "",
            float(inv.subtotal),
            float(inv.tax_amount),
            float(inv.total),
            inv.get_status_display(),
        ]
        exporter.write_row(row_num, row_data, right_align_cols=[3, 4, 5, 6])

    return exporter.generate_response(request, "financial_report")


@login_required
@permission_required("fees", "view")
def export_fees_excel(request):
    service = UnifiedExportService(request)
    return service.export(FEES_EXPORT_CONFIG, format="excel")


@login_required
@permission_required("fees", "view")
def export_fees_pdf(request):
    service = UnifiedExportService(request)
    return service.export(FEES_EXPORT_CONFIG, format="pdf")


@login_required
@permission_required("expenses", "view")
def export_expenses_excel(request):
    service = UnifiedExportService(request)
    return service.export(EXPENSES_EXPORT_CONFIG, format="excel")


@login_required
@permission_required("expenses", "view")
def export_expenses_pdf(request):
    service = UnifiedExportService(request)
    return service.export(EXPENSES_EXPORT_CONFIG, format="pdf")


@login_required
@permission_required("expenses", "view")
def export_office_expenses_excel(request):
    service = UnifiedExportService(request)
    return service.export(OFFICE_EXPENSES_EXPORT_CONFIG, format="excel")


@login_required
@permission_required("expenses", "view")
def export_office_expenses_pdf(request):
    service = UnifiedExportService(request)
    return service.export(OFFICE_EXPENSES_EXPORT_CONFIG, format="pdf")


@login_required
@permission_required("invoices", "view")
def export_invoices_excel(request):
    service = UnifiedExportService(request)
    return service.export(INVOICES_EXPORT_CONFIG, format="excel")


@login_required
@permission_required("invoices", "view")
def export_invoices_pdf(request):
    service = UnifiedExportService(request)
    return service.export(INVOICES_EXPORT_CONFIG, format="pdf")


@login_required
@permission_required("fees", "view")
@permission_required("expenses", "view")
@permission_required("invoices", "view")
def export_finance_pdf(request):
    """Export comprehensive financial report to PDF."""
    exporter = PDFExporter(request, title="تقرير الأتعاب والمصروفات")
    exporter.add_header()

    # جلب البيانات مع تحسين الأداء + منع تحميل كل السجلات
    fees = Fee.objects.select_related("case", "case__client").all()[:MAX_EXPORT_ROWS]
    expenses = Expense.objects.select_related("case").all()[:MAX_EXPORT_ROWS]
    invoices = Invoice.objects.select_related("client").all()[:MAX_EXPORT_ROWS]

    # إعداد بيانات جدول الأتعاب
    fees_headers = [
        "الحالة",
        "المبلغ المتفق عليه",
        "نوع الأتعاب",
        "العميل",
        "رقم القضية",
    ]
    fees_data = []
    for fee in fees:
        fees_data.append(
            [
                fee.get_status_display(),
                float(fee.agreed_amount),
                fee.get_fee_type_display(),
                fee.case.client.full_name if fee.case.client else "—",
                fee.case.case_number if fee.case.case_number else "—",
            ]
        )

    # إعداد بيانات جدول المصروفات
    expenses_headers = ["المبلغ", "الفئة", "الوصف", "التاريخ", "القضية"]
    expenses_data = []
    for exp in expenses:
        expenses_data.append(
            [
                float(exp.amount),
                exp.get_category_display(),
                exp.description or "—",
                exp.date.strftime("%Y-%m-%d") if exp.date else "—",
                exp.case.case_number if exp.case else "مكتب",
            ]
        )

    # إعداد بيانات جدول الفواتير
    invoices_headers = [
        "الإجمالي",
        "الضريبة",
        "المبلغ الفرعي",
        "التاريخ",
        "العميل",
        "رقم الفاتورة",
    ]
    invoices_data = []
    for inv in invoices:
        invoices_data.append(
            [
                float(inv.total),
                float(inv.tax_amount),
                float(inv.subtotal),
                inv.date.strftime("%Y-%m-%d") if inv.date else "—",
                inv.client.full_name if inv.client else "—",
                inv.invoice_number or "—",
            ]
        )

    from reportlab.lib.units import mm

    # إضافة جدول الأتعاب
    exporter.add_title("جدول الأتعاب")
    exporter.add_table(
        fees_headers,
        fees_data,
        [25 * mm, 25 * mm, 30 * mm, 40 * mm, 30 * mm],
        theme_color="4F46E5",
    )

    # إضافة جدول المصروفات
    exporter.add_title("جدول المصروفات")
    exporter.add_table(
        expenses_headers,
        expenses_data,
        [20 * mm, 25 * mm, 40 * mm, 20 * mm, 30 * mm],
        theme_color="EF4444",
    )

    # إضافة جدول الفواتير
    exporter.add_title("جدول الفواتير")
    exporter.add_table(
        invoices_headers,
        invoices_data,
        [20 * mm, 15 * mm, 15 * mm, 20 * mm, 40 * mm, 20 * mm],
        theme_color="10B981",
    )

    return exporter.generate_response("financial_report")


# ============================================
# Unified Export: Row Mappers & Configs (Finance)
# ============================================


def _map_fee_row(fee, is_pdf=False):
    if is_pdf:
        return [
            fee.get_status_display() or "—",
            float(fee.agreed_amount) if fee.agreed_amount is not None else 0,
            fee.get_fee_type_display() or "—",
            fee.case.client.full_name if fee.case and fee.case.client else "—",
            fee.case.case_number if fee.case else "—",
        ]
    return [
        fee.case.case_number if fee.case else "",
        fee.case.client.full_name if fee.case and fee.case.client else "",
        fee.get_fee_type_display() or "",
        float(fee.agreed_amount) if fee.agreed_amount is not None else "",
        fee.get_status_display() or "",
    ]


# خريطة ترجمة الفئات إلى العربية
EXPENSE_CATEGORY_ARABIC = {
    "court_fees": "رسوم محكمة",
    "expert_fee": "أمانة الخبير",
    "announcements": "الإعلانات القضائية",
    "enforcement": "تنفيذ الأحكام",
    "printing": "طباعة مستندات",
    "transport": "انتقالات",
    "other": "أخرى",
    "documents": "مستندات",  # فئة قديمة
    "utilities": "خدمات",  # فئة قديمة
}


def _get_expense_category_arabic(exp):
    """الحصول على اسم الفئة بالعربية"""
    # محاولة get_category_display أولاً
    display = exp.get_category_display()
    if (
        display and display != exp.category
    ):  # إذا كانت القيمة مختلفة، فهذا يعني أنها موجودة في choices
        return display
    # إذا لم تُرجع get_category_display القيمة الصحيحة (فئة قديمة)
    return EXPENSE_CATEGORY_ARABIC.get(exp.category, exp.category)


def _map_expense_row(exp, is_pdf=False):
    category_ar = _get_expense_category_arabic(exp)

    if is_pdf:
        return [
            exp.description or "—",
            category_ar or "—",
            float(exp.amount) if exp.amount is not None else 0,
            exp.date.strftime("%Y-%m-%d") if exp.date else "—",
            exp.notes or "—",
        ]
    return [
        exp.date.strftime("%Y-%m-%d") if exp.date else "",
        exp.description or "",
        category_ar or "",
        float(exp.amount) if exp.amount is not None else "",
        exp.case.case_number if exp.case else "مكتب",
    ]


def _map_case_expense_row(exp, is_pdf=False):
    """Mapping function for case expenses with receipt number"""
    category_ar = _get_expense_category_arabic(exp)

    if is_pdf:
        return [
            exp.description or "—",
            category_ar or "—",
            exp.case.case_number if exp.case else "—",
            float(exp.amount) if exp.amount is not None else 0,
            exp.date.strftime("%Y-%m-%d") if exp.date else "—",
            exp.receipt_number or "—",
        ]
    return [
        exp.date.strftime("%Y-%m-%d") if exp.date else "",
        exp.description or "",
        category_ar or "",
        float(exp.amount) if exp.amount is not None else "",
        exp.case.case_number if exp.case else "",
        exp.receipt_number or "",
    ]


def _map_invoice_row(inv, is_pdf=False):
    if is_pdf:
        return [
            float(inv.total) if inv.total is not None else 0,
            float(inv.tax_amount) if inv.tax_amount is not None else 0,
            float(inv.subtotal) if inv.subtotal is not None else 0,
            inv.date.strftime("%Y-%m-%d") if inv.date else "—",
            inv.client.full_name if inv.client else "—",
            inv.invoice_number or "—",
        ]
    return [
        inv.invoice_number or "",
        inv.client.full_name if inv.client else "",
        inv.date.strftime("%Y-%m-%d") if inv.date else "",
        float(inv.subtotal) if inv.subtotal is not None else "",
        float(inv.tax_amount) if inv.tax_amount is not None else "",
        float(inv.total) if inv.total is not None else "",
        inv.get_status_display() or "",
    ]


FEES_EXPORT_CONFIG = ExportConfig(
    model_name="الأتعاب",
    queryset_fn=lambda req: Fee.objects.select_related("case", "case__client").all()[
        :MAX_EXPORT_ROWS
    ],
    excel_headers=[
        "رقم القضية",
        "العميل",
        "نوع الأتعاب",
        "المبلغ المتفق عليه",
        "الحالة",
    ],
    pdf_headers=["الحالة", "المبلغ", "النوع", "العميل", "رقم القضية"],
    row_mapper=_map_fee_row,
    pdf_col_widths=[25 * mm, 25 * mm, 30 * mm, 40 * mm, 30 * mm],
    theme_color="4F46E5",
    filename_prefix="fees",
)

EXPENSES_EXPORT_CONFIG = ExportConfig(
    model_name="مصروفات القضايا",
    queryset_fn=lambda req: Expense.objects.select_related("case").filter(
        expense_type="case"
    )[:MAX_EXPORT_ROWS],
    excel_headers=["التاريخ", "البيان", "الفئة", "المبلغ", "القضية", "رقم الإيصال"],
    pdf_headers=["البيان", "الفئة", "القضية", "المبلغ", "التاريخ", "رقم الإيصال"],
    row_mapper=_map_case_expense_row,
    pdf_col_widths=[35 * mm, 25 * mm, 30 * mm, 20 * mm, 20 * mm, 25 * mm],
    theme_color="EF4444",
    filename_prefix="case_expenses",
)

OFFICE_EXPENSES_EXPORT_CONFIG = ExportConfig(
    model_name="مصروفات المكتب",
    queryset_fn=lambda req: Expense.objects.filter(
        expense_type="office"
    )[:MAX_EXPORT_ROWS],
    excel_headers=["التاريخ", "البيان", "الفئة", "المبلغ"],
    pdf_headers=["البيان", "الفئة", "المبلغ", "التاريخ", "ملاحظات"],
    row_mapper=_map_expense_row,
    pdf_col_widths=[40 * mm, 30 * mm, 25 * mm, 25 * mm, 30 * mm],
    theme_color="EF4444",
    filename_prefix="office_expenses",
)

INVOICES_EXPORT_CONFIG = ExportConfig(
    model_name="الفواتير",
    queryset_fn=lambda req: Invoice.objects.select_related("client").all()[
        :MAX_EXPORT_ROWS
    ],
    excel_headers=[
        "رقم الفاتورة",
        "العميل",
        "التاريخ",
        "المبلغ الفرعي",
        "الضريبة",
        "الإجمالي",
        "الحالة",
    ],
    pdf_headers=[
        "الإجمالي",
        "الضريبة",
        "المبلغ الفرعي",
        "التاريخ",
        "العميل",
        "رقم الفاتورة",
    ],
    row_mapper=_map_invoice_row,
    pdf_col_widths=[20 * mm, 15 * mm, 15 * mm, 20 * mm, 40 * mm, 20 * mm],
    theme_color="10B981",
    filename_prefix="invoices",
)
