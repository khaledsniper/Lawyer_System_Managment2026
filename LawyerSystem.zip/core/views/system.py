from django.shortcuts import redirect, get_object_or_404
from django.views.generic import (
    TemplateView,
    CreateView,
    UpdateView,
    DeleteView,
)
from django.urls import reverse_lazy
from django.contrib.auth.mixins import LoginRequiredMixin
from django.contrib.auth import logout
from django.contrib import messages
from django.http import JsonResponse
from django.conf import settings
from django.db import connections
from django.utils import timezone
from django.views.decorators.http import require_http_methods
from django.views.decorators.csrf import ensure_csrf_cookie
from pathlib import Path
import sqlite3
import json
import logging

from core.permissions import RoleRequiredMixin, ROLE_ADMIN
from core.models import User, OfficeProfile, Case, Client, Invoice, Task


def _get_desktop_backup_dir():
    """Get backup directory.

    All backups stay in project media_files/backups during development.
    This can be changed later for production packaging.
    """
    return Path(settings.BASE_DIR) / "media_files" / "backups"


def _backup_sqlite_db(db_file, backup_file):
    connections.close_all()
    src = sqlite3.connect(str(db_file))
    try:
        dest = sqlite3.connect(str(backup_file))
        try:
            src.backup(dest)
        finally:
            dest.close()
    finally:
        src.close()


def _restore_sqlite_db(backup_file, db_file):
    connections.close_all()
    src = sqlite3.connect(str(backup_file))
    try:
        dest = sqlite3.connect(str(db_file))
        try:
            src.backup(dest)
        finally:
            dest.close()
    finally:
        src.close()


class SettingsView(RoleRequiredMixin, LoginRequiredMixin, TemplateView):
    role_required = [ROLE_ADMIN]
    template_name = "core/settings.html"

    def dispatch(self, request, *args, **kwargs):
        response = super().dispatch(request, *args, **kwargs)
        return response

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        backup_dir = _get_desktop_backup_dir()
        default_path = backup_dir
        context.update(
            {
                "backup_default_path": default_path,
                "office_profile": OfficeProfile.objects.first(),
                "total_users": User.objects.count(),
                "total_cases": Case.objects.count(),
                "total_clients": Client.objects.count(),
                "total_invoices": Invoice.objects.count(),
                "total_tasks": Task.objects.count(),
                "users_list": User.objects.all().order_by(
                    "-is_superuser", "-is_staff", "-date_joined"
                ),
            }
        )
        return context

    def post(self, request, *args, **kwargs):
        if not request.user.is_superuser:
            messages.error(
                request, "❌ ليس لديك صلاحية تنفيذ هذه العملية. يجب أن تكون مديرًا أعلى."
            )
            return redirect("core:dashboard")

        action = request.POST.get("action")
        target_dir = _get_desktop_backup_dir()
        target_dir.mkdir(parents=True, exist_ok=True)

        # Database path — always in project root during development
        db_file = Path(settings.BASE_DIR) / "db.sqlite3"

        if action == "backup":
            if not db_file.exists():
                messages.error(request, "قاعدة البيانات غير موجودة")
                return redirect("core:settings")

            timestamp = timezone.now().strftime("%Y%m%d_%H%M%S")
            backup_file = target_dir / f"backup_{timestamp}.sqlite3"
            try:
                _backup_sqlite_db(db_file, backup_file)
                messages.success(
                    request, f"✅ تم إنشاء النسخة الاحتياطية باسم: {backup_file.name}"
                )
            except Exception:
                logging.exception("Backup failed")
                messages.error(request, "❌ تعذر إنشاء النسخة الاحتياطية")

        elif action == "restore":
            upload = request.FILES.get("backup_file")
            if not upload:
                messages.error(request, "❌ يرجى اختيار ملف نسخة احتياطية للاستعادة.")
                return redirect("core:settings")

            filename = upload.name
            if not filename.lower().endswith(".sqlite3"):
                messages.error(
                    request, "❌ صيغة الملف غير مدعومة. يرجى رفع ملف بامتداد .sqlite3"
                )
                return redirect("core:settings")

            max_size = 200 * 1024 * 1024
            try:
                size = upload.size
            except Exception:
                size = None
            if size and size > max_size:
                messages.error(request, "❌ حجم الملف كبير جداً. الحد الأقصى 200MB")
                return redirect("core:settings")

            restore_temp = (
                target_dir
                / f"restore_{timezone.now().strftime('%Y%m%d_%H%M%S')}.sqlite3"
            )
            try:
                with open(restore_temp, "wb+") as dest:
                    for chunk in upload.chunks():
                        dest.write(chunk)

                SQLITE_MAGIC = b"SQLite format 3\x00"
                with open(restore_temp, "rb") as f:
                    magic = f.read(16)
                if magic != SQLITE_MAGIC:
                    restore_temp.unlink(missing_ok=True)
                    messages.error(
                        request, "❌ الملف المرفوع ليس قاعدة بيانات SQLite صحيحة"
                    )
                    return redirect("core:settings")

                _restore_sqlite_db(restore_temp, db_file)
                messages.warning(
                    request,
                    f"⚠️ تم استعادة قاعدة البيانات من: {restore_temp.name}. يجب إعادة تشغيل الخادم لتطبيق التغييرات.",
                )
            except Exception:
                logging.exception("Restore failed")
                messages.error(request, "❌ تعذر الاستعادة")
            if restore_temp.exists():
                restore_temp.unlink(missing_ok=True)

        return redirect("core:settings")


class UserCreateView(RoleRequiredMixin, LoginRequiredMixin, CreateView):
    model = User
    fields = ["username", "first_name", "last_name", "role", "password"]
    template_name = "core/user_form.html"
    success_url = reverse_lazy("core:settings")
    role_required = [ROLE_ADMIN]

    def form_valid(self, form):
        user = form.save(commit=False)
        user.set_password(form.cleaned_data["password"])
        user.save()
        messages.success(self.request, f"✅ تم إنشاء المستخدم {user.username} بنجاح")

        if self.request.headers.get("X-Requested-With") == "XMLHttpRequest":
            return JsonResponse(
                {"status": "success", "message": "تم إنشاء المستخدم بنجاح"}
            )
        return redirect("core:settings")

    def form_invalid(self, form):
        if self.request.headers.get("X-Requested-With") == "XMLHttpRequest":
            return JsonResponse({"status": "error", "errors": form.errors}, status=400)
        messages.error(self.request, "❌ هناك أخطاء في النموذج")
        return super().form_invalid(form)


class UserUpdateView(RoleRequiredMixin, LoginRequiredMixin, UpdateView):
    model = User
    fields = ["username", "first_name", "last_name", "role", "is_active"]
    template_name = "core/user_form.html"
    success_url = reverse_lazy("core:settings")
    role_required = [ROLE_ADMIN]

    def get_object(self, queryset=None):
        if self.request.method == "POST":
            user_id = self.request.POST.get("user_id")
            if user_id:
                return get_object_or_404(User, pk=user_id)
        return super().get_object(queryset)

    def form_valid(self, form):
        # PROTECT SUPERUSER
        if self.object.is_superuser and not self.request.user.is_superuser:
            if self.request.headers.get("X-Requested-With") == "XMLHttpRequest":
                return JsonResponse(
                    {
                        "status": "error",
                        "errors": {
                            "__all__": ["لا تملك صلاحية تعديل بيانات المدير الأعلى"]
                        },
                    },
                    status=403,
                )
            messages.error(self.request, "❌ لا تملك صلاحية تعديل بيانات المدير الأعلى")
            return redirect("core:settings")

        password = self.request.POST.get("password")
        if password:
            user = form.save(commit=False)
            user.set_password(password)
            user.save()
            messages.success(
                self.request, "✅ تم تعديل بيانات المستخدم وكلمة المرور بنجاح"
            )
        else:
            messages.success(
                self.request,
                f"✅ تم تعديل بيانات المستخدم {form.instance.username} بنجاح",
            )
            form.save()

        if self.request.headers.get("X-Requested-With") == "XMLHttpRequest":
            return JsonResponse(
                {"status": "success", "message": "تم تعديل المستخدم بنجاح"}
            )

        return redirect("core:settings")

    def form_invalid(self, form):
        if self.request.headers.get("X-Requested-With") == "XMLHttpRequest":
            return JsonResponse({"status": "error", "errors": form.errors}, status=400)
        messages.error(self.request, "❌ هناك أخطاء في النموذج")
        return super().form_invalid(form)


class UserDeleteView(RoleRequiredMixin, LoginRequiredMixin, DeleteView):
    model = User
    template_name = "core/user_confirm_delete.html"
    success_url = reverse_lazy("core:settings")
    role_required = [ROLE_ADMIN]

    def delete(self, request, *args, **kwargs):
        obj = self.get_object()
        if obj.is_superuser:
            messages.error(request, "❌ لا يمكن حذف المدير الأعلى")
            return redirect("core:settings")

        username = obj.username
        messages.success(request, f"✅ تم حذف المستخدم {username} بنجاح")
        return super().delete(request, *args, **kwargs)


def logout_view(request):
    logout(request)

    # Check if it's a desktop mode request
    if request.headers.get("X-Desktop-Mode") or request.GET.get("desktop"):
        # For desktop mode, redirect to login page
        # The login page will detect no session and stay on login
        return redirect("core:login")

    return redirect("core:login")


@ensure_csrf_cookie
@require_http_methods(["GET", "POST"])
def theme_preference(request):
    """Save/load theme preference via user profile in database.

    GET  → returns current theme from user profile (or session fallback)
    POST → saves theme to user profile (or session if not logged in)
    """
    if request.method == "GET":
        if request.user.is_authenticated:
            theme = request.user.theme_preference or "light"
        else:
            theme = request.session.get("theme", "light")
        return JsonResponse({"theme": theme})

    if request.method == "POST":
        try:
            data = json.loads(request.body)
            theme = data.get("theme", "light")
            if theme not in ("light", "dark"):
                theme = "light"

            if request.user.is_authenticated:
                request.user.theme_preference = theme
                request.user.save(update_fields=["theme_preference"])
            else:
                request.session["theme"] = theme

            return JsonResponse({"theme": theme, "status": "ok"})
        except (json.JSONDecodeError, Exception):
            return JsonResponse({"status": "error"}, status=400)


@require_http_methods(["POST"])
def close_desktop_app(request):
    """Endpoint called by desktop app to close itself.

    Writes a sentinel file that the desktop app's watcher thread detects,
    which then destroys the pywebview window.
    """
    if not getattr(settings, "DESKTOP_MODE", False):
        return JsonResponse(
            {"status": "error", "message": "Not running in desktop mode"}, status=400
        )

    # Write sentinel file — desktop_app.py's watcher thread will pick it up
    sentinel = Path(settings.BASE_DIR) / ".desktop_close"
    try:
        sentinel.touch()
    except Exception as exc:
        logging.exception("Failed to write close sentinel")
        return JsonResponse({"status": "error", "message": str(exc)}, status=500)

    return JsonResponse({"status": "ok"})
