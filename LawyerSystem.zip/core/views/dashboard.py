from django.views.generic import ListView
from django.contrib.auth.mixins import LoginRequiredMixin
from django.utils import timezone

from core.forms import AppointmentForm, CaseForm, SessionForm, TaskForm
from core.models import Case, Client, Session, Appointment, Task, Opponent
from core.services.dashboard_stats import (
    get_cases_stats,
    get_client_stats,
    get_finance_stats,
    get_task_stats,
)

class DashboardView(LoginRequiredMixin, ListView):
    model = Case
    template_name = 'core/dashboard.html'
    context_object_name = 'recent_cases'

    def get_queryset(self):
        # عرض آخر 3 قضايا في لوحة التحكم
        return Case.objects.all().select_related('client').only(
            'id', 'case_number', 'subject', 'client__full_name', 'created_at'
        ).order_by('-created_at')[:3]

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)

        case_stats = get_cases_stats()
        context.update({
            'total_cases': case_stats['total'],
            'active_cases': case_stats['active'],
            'pending_cases': case_stats['pending'],
            'won_cases': case_stats['won'],
            'closed_cases': case_stats['closed'],
        })

        client_stats = get_client_stats()
        context['total_clients'] = client_stats['total']
        context['total_opponents'] = Opponent.objects.count()

        today = timezone.now().date()
        
        # تحسين: استخدام count() للعد - avoids loading all records
        todays_sessions = Session.objects.filter(date=today).select_related('case', 'case__client').order_by('time', 'date')
        context['todays_sessions'] = todays_sessions[:50]  # Limit to 50 for display
        context['todays_sessions_count'] = Session.objects.filter(date=today).count()
        
        # تحسين: استعلام واحد للمواعيد واستخدام count()
        todays_appointments = Appointment.objects.filter(datetime__date=today).select_related('client', 'case').order_by('datetime')
        context['todays_appointments'] = todays_appointments[:50]
        context['todays_appointments_count'] = Appointment.objects.filter(datetime__date=today).count()

        # مهام اليوم
        context['todays_tasks'] = Task.objects.filter(due_date=today).select_related('case', 'assigned_to').order_by('priority', 'due_date')

        task_stats = get_task_stats()
        context['pending_tasks_count'] = task_stats['new'] + task_stats['in_progress']
        context['pending_tasks'] = Task.objects.filter(status__in=['new', 'in_progress']).select_related('assigned_to', 'case').order_by('-due_date')[:5]

        finance_stats = get_finance_stats()
        context['total_fees'] = finance_stats['total_fees']
        context['total_expenses'] = finance_stats['total_expenses']
        context['net_profit'] = finance_stats['net_profit']

        # سجل النشاطات: استخدام القوائم التي تم جلبها بالفعل
        context['recent_cases'] = self.object_list
        
        # آخر 3 عملاء
        context['recent_clients'] = Client.objects.all().only('id', 'full_name', 'updated_at').order_by('-updated_at')[:3]
        
        # آخر 3 خصوم
        context['recent_opponents'] = Opponent.objects.all().only('id', 'name', 'updated_at').order_by('-updated_at')[:3]

        context['clients'] = Client.objects.all().only('id', 'full_name').order_by('full_name')
        context['opponents'] = Opponent.objects.filter(is_active=True).only('id', 'name').order_by('name')
        context['current_year'] = timezone.now().year
        context['years_range'] = range(2000, 2100)
        context['session_form'] = SessionForm()
        context['appointment_form'] = AppointmentForm()
        context['task_form'] = TaskForm()
        context['form'] = CaseForm()

        return context
