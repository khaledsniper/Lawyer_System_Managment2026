from django.shortcuts import render, redirect
from django.views.generic import (
    ListView,
    DetailView,
    CreateView,
    UpdateView,
    DeleteView,
)
from django.urls import reverse_lazy
from django.contrib.auth.mixins import LoginRequiredMixin
from django.contrib.auth.decorators import login_required
from django.db.models import Q, Count
from django.db.models.functions import Lower
from django.contrib import messages
from django.http import JsonResponse
from django.template.loader import render_to_string
import logging
from django.utils import timezone

from core.services.export_helpers import UnifiedExportService, ExportConfig

logger = logging.getLogger(__name__)

from core.permissions import (
    PermissionRequiredMixin,
    RoleRequiredMixin,
    ROLE_ADMIN,
    permission_required,
)
from core.models import Client, Opponent, Case, Contract, Invoice

# Maximum rows for export to prevent memory issues
MAX_EXPORT_ROWS = 10000

# For PDF column widths
from reportlab.lib.units import mm
from core.forms import ClientForm
from core.services.duplicates import (
    check_client_duplicate as check_client_duplicate_service,
)

from .mixins import FilteredListViewMixin


class ClientListView(
    PermissionRequiredMixin, LoginRequiredMixin, FilteredListViewMixin, ListView
):
    model = Client
    template_name = "core/clients.html"
    context_object_name = "clients"
    search_fields = ["full_name", "phone", "client_id", "national_id"]
    page_size_options = (25, 50, 75, 100)
    permission_module = "clients"
    permission_action = "view"

    def get(self, request, *args, **kwargs):
        # Handle AJAX requests for filtering
        if request.headers.get("X-Requested-With") == "XMLHttpRequest":
            try:
                self.object_list = self.get_queryset()
                context = self.get_context_data()
                from django.template.loader import render_to_string
                from django.http import JsonResponse

                # Render only the table container
                html = render_to_string(
                    "core/includes/client_table_partial.html", context, request=request
                )

                # Return both HTML and count
                return JsonResponse({"html": html, "count": self.object_list.count()})
            except Exception as e:
                logger.error(f"AJAX error: {str(e)}", exc_info=True)
                from django.http import JsonResponse

                return JsonResponse({"error": str(e)}, status=500)

        return super().get(request, *args, **kwargs)

    def get_queryset(self):
        queryset = (
            Client.objects.all()
            .prefetch_related("cases", "invoices")
            .annotate(case_count=Count("cases"), lower_name=Lower("full_name"))
        )

        # تطبيق الفلاتر الخاصة
        client_type = self.request.GET.get("type")
        if client_type:
            queryset = queryset.filter(type=client_type)
        status = self.request.GET.get("status")
        if status:
            queryset = queryset.filter(status=status)

        # تطبيق البحث العام عبر الـ Mixin
        queryset = self.apply_search(queryset)

        return queryset.order_by("-id")

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        # إحصائيات سريعة
        stats = Client.objects.get_statistics()
        context.update(
            {
                "total_clients": stats["total"],
                "individual_clients": stats["individual"],
                "company_clients": stats["company"],
                "active_clients": stats["active"],
                "page_size_options": self.page_size_options,
            }
        )
        return context


@login_required
def check_client_duplicate(request):
    full_name = request.GET.get("full_name", "").strip()
    phone = request.GET.get("phone", "").strip()
    national_id = request.GET.get("national_id", "").strip()
    pk = request.GET.get("pk", "").strip()
    result = check_client_duplicate_service(
        full_name=full_name,
        phone=phone,
        national_id=national_id,
        pk=pk,
    )
    return JsonResponse(result)


@login_required
def check_opponent_duplicate(request):
    """Check if opponent name or phone already exists."""
    name = request.GET.get("name", "").strip()
    phone = request.GET.get("phone", "").strip()
    pk = request.GET.get("pk", "").strip()

    result = {"duplicate": False, "message": ""}

    if name:
        qs = Opponent.objects.filter(name__iexact=name)
        if pk:
            qs = qs.exclude(pk=pk)
        if qs.exists():
            result["duplicate"] = True
            result["message"] = f"⚠️ يوجد خصم بنفس الاسم بالفعل: {name}"
            return JsonResponse(result)

    if phone:
        qs = Opponent.objects.filter(phone=phone)
        if pk:
            qs = qs.exclude(pk=pk)
        if qs.exists():
            result["duplicate"] = True
            result["message"] = "⚠️ رقم الهاتف هذا مسجل بالفعل لخصم آخر"
            return JsonResponse(result)

    return JsonResponse(result)


class ClientCreateView(PermissionRequiredMixin, LoginRequiredMixin, CreateView):
    model = Client
    form_class = ClientForm
    template_name = "core/client_form.html"
    success_url = reverse_lazy("core:clients")
    permission_module = "clients"
    permission_action = "add"

    def get(self, request, *args, **kwargs):
        if request.headers.get("X-Requested-With") == "XMLHttpRequest":
            return super().get(request, *args, **kwargs)
        return redirect("core:clients")

    def form_valid(self, form):
        self.object = form.save()
        if self.request.headers.get("X-Requested-With") == "XMLHttpRequest":
            return JsonResponse({"status": "success", "client_id": self.object.pk})
        messages.success(self.request, "✅ تم إضافة العميل بنجاح")
        return redirect(self.get_success_url())

    def form_invalid(self, form):
        if self.request.headers.get("X-Requested-With") == "XMLHttpRequest":
            return JsonResponse(
                {"success": False, "errors": form.errors.get_json_data()}, status=400
            )
        return super().form_invalid(form)


class ClientDetailView(PermissionRequiredMixin, LoginRequiredMixin, DetailView):
    model = Client
    template_name = "core/client_detail_modal.html"
    context_object_name = "client"
    permission_module = "clients"
    permission_action = "view"

    def get(self, request, *args, **kwargs):
        self.object = self.get_object()
        context = self.get_context_data()

        # فحص وضع الطباعة أولاً قبل AJAX لتجنب إرجاع JSON بدلاً من HTML
        if request.GET.get("print"):
            context["print_mode"] = True
            return render(request, "core/client_detail_modal.html", context)

        if request.headers.get("X-Requested-With") == "XMLHttpRequest":
            html = render_to_string(
                "core/client_detail_modal.html", context, request=request
            )
            return JsonResponse({"html": html, "client_id": self.object.id})

        return render(request, "core/client_detail_modal.html", context)

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context["now"] = timezone.now()
        client = self.object  # تجنب استعلام إضافي - استخدام الكائن المحمّل مسبقاً
        context["cases"] = Case.objects.filter(client=client).select_related("client")
        context["contracts"] = Contract.objects.filter(client=client)
        context["invoices"] = Invoice.objects.filter(client=client)
        return context


class ClientUpdateView(PermissionRequiredMixin, LoginRequiredMixin, UpdateView):
    model = Client
    form_class = ClientForm
    template_name = "core/client_form.html"
    success_url = reverse_lazy("core:clients")
    permission_module = "clients"
    permission_action = "change"

    def get(self, request, *args, **kwargs):
        self.object = self.get_object()
        if request.headers.get("X-Requested-With") == "XMLHttpRequest":
            context = self.get_context_data()
            context["client"] = self.object
            html = render_to_string(
                "core/includes/client_update_modal.html",
                context,
                request=request,
            )
            return JsonResponse({"html": html})
        return redirect("core:clients")

    def form_valid(self, form):
        self.object = form.save()
        if self.request.headers.get("X-Requested-With") == "XMLHttpRequest":
            logger.info(
                f"Client updated successfully via AJAX: {self.object.full_name}"
            )
            return JsonResponse(
                {
                    "status": "success",
                    "message": f"✅ تم تحديث بيانات العميل {self.object.full_name} بنجاح",
                    "client_id": self.object.id,
                }
            )
        messages.success(self.request, "✅ تم تحديث بيانات العميل بنجاح")
        return redirect(self.get_success_url())

    def form_invalid(self, form):
        logger.warning(f"Client form invalid via AJAX. Errors: {form.errors}")
        if self.request.headers.get("X-Requested-With") == "XMLHttpRequest":
            return JsonResponse(
                {"status": "error", "errors": form.errors.get_json_data()}, status=400
            )
        messages.error(self.request, "❌ هناك أخطاء في النموذج")
        return super().form_invalid(form)


class ClientDeleteView(RoleRequiredMixin, LoginRequiredMixin, DeleteView):
    role_required = [ROLE_ADMIN]
    model = Client
    template_name = "core/client_confirm_delete.html"
    success_url = reverse_lazy("core:clients")

    def get(self, request, *args, **kwargs):
        self.object = self.get_object()
        if request.headers.get("X-Requested-With") == "XMLHttpRequest":
            html = render_to_string("core/includes/generic_delete_modal_content.html", {"object": self.object}, request=request)
            return JsonResponse({"html": html})
        return super().get(request, *args, **kwargs)

    def delete(self, request, *args, **kwargs):
        obj = self.get_object()
        client_name = obj.full_name
        success_url = self.get_success_url()
        obj.delete()
        if request.headers.get("X-Requested-With") == "XMLHttpRequest":
            return JsonResponse({"status": "success", "message": f'تم حذف العميل "{client_name}" بنجاح'})
        messages.success(request, f'✅ تم حذف العميل "{client_name}" بنجاح')
        return redirect(success_url)


class OpponentListView(PermissionRequiredMixin, LoginRequiredMixin, ListView):
    model = Opponent
    template_name = "core/opponents.html"
    context_object_name = "opponents"
    paginate_by = 50
    page_size_options = (25, 50, 75, 100)
    permission_module = "opponents"
    permission_action = "view"

    def get_queryset(self):
        queryset = Opponent.objects.all().annotate(case_count=Count("cases"))
        opponent_type = self.request.GET.get("type")
        if opponent_type:
            queryset = queryset.filter(type=opponent_type)
        search = self.request.GET.get("search")
        if search:
            queryset = queryset.filter(
                Q(name__icontains=search)
                | Q(phone__icontains=search)
                | Q(opponent_lawyer__icontains=search)
            )
        order = self.request.GET.get("order", "name_asc")
        if order == "name_asc":
            queryset = queryset.order_by("name")
        elif order == "name_desc":
            queryset = queryset.order_by("-name")
        elif order == "newest":
            queryset = queryset.order_by("-created_at")
        elif order == "oldest":
            queryset = queryset.order_by("created_at")
        else:
            queryset = queryset.order_by("name")
        return queryset

    def render_to_response(self, context, **response_kwargs):
        """دعم AJAX للتحديث الجزئي."""
        if self.request.headers.get("X-Requested-With") == "XMLHttpRequest":
            from django.template.loader import render_to_string

            # عرض الـ partial template الكامل (يشمل الجدول والترقيم)
            html = render_to_string(
                "core/includes/opponent_table_partial.html",
                context,
                request=self.request,
            )

            return JsonResponse(
                {
                    "html": html,
                    "count": context["opponents"].paginator.count
                    if context.get("is_paginated")
                    else context["opponents"].count(),
                    "stats": {
                        "total": Opponent.objects.count(),
                        "individual": Opponent.objects.filter(
                            type="individual"
                        ).count(),
                        "company": Opponent.objects.filter(type="company").count(),
                        "government": Opponent.objects.filter(
                            type="government"
                        ).count(),
                        "entity": Opponent.objects.filter(type="entity").count(),
                    },
                }
            )

        return super().render_to_response(context, **response_kwargs)

    def get_paginate_by(self, queryset):
        page_size = self.request.GET.get("page_size")
        try:
            page_size = int(page_size)
        except (TypeError, ValueError):
            return self.paginate_by
        return page_size if page_size in self.page_size_options else self.paginate_by

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context["total_opponents"] = Opponent.objects.count()
        context["individual_opponents"] = Opponent.objects.filter(
            type="individual"
        ).count()
        context["company_opponents"] = Opponent.objects.filter(type="company").count()
        context["government_opponents"] = Opponent.objects.filter(
            type="government"
        ).count()
        context["entity_opponents"] = Opponent.objects.filter(type="entity").count()
        context["page_size_options"] = self.page_size_options
        context["current_page_size"] = self.get_paginate_by(self.object_list)
        pagination_params = self.request.GET.copy()
        pagination_params.pop("page", None)
        context["pagination_querystring"] = pagination_params.urlencode()
        return context


class OpponentCreateView(PermissionRequiredMixin, LoginRequiredMixin, CreateView):
    model = Opponent
    fields = [
        "name",
        "type",
        "phone",
        "job",
        "business_activity",
        "opponent_lawyer",
        "address",
        "notes",
    ]
    template_name = "core/opponent_form.html"
    success_url = reverse_lazy("core:opponents")
    permission_module = "opponents"
    permission_action = "add"

    def get(self, request, *args, **kwargs):
        if request.headers.get("X-Requested-With") == "XMLHttpRequest":
            return super().get(request, *args, **kwargs)
        return redirect("core:opponents")

    def form_valid(self, form):
        self.object = form.save()
        if self.request.headers.get("X-Requested-With") == "XMLHttpRequest":
            return JsonResponse({"status": "success", "opponent_id": self.object.pk})
        messages.success(self.request, "✅ تم إضافة الخصم بنجاح")
        return redirect(self.get_success_url())

    def form_invalid(self, form):
        if self.request.headers.get("X-Requested-With") == "XMLHttpRequest":
            return JsonResponse(
                {"status": "error", "errors": form.errors.get_json_data()}, status=400
            )
        return super().form_invalid(form)


class OpponentDetailView(PermissionRequiredMixin, LoginRequiredMixin, DetailView):
    model = Opponent
    template_name = "core/opponent_detail_modal.html"
    context_object_name = "opponent"
    permission_module = "opponents"
    permission_action = "view"

    def get(self, request, *args, **kwargs):
        self.object = self.get_object()
        context = self.get_context_data()
        if request.headers.get("X-Requested-With") == "XMLHttpRequest":
            html = render_to_string(
                "core/opponent_detail_modal.html", context, request=request
            )
            return JsonResponse({"html": html})
        return render(request, "core/opponent_detail_modal.html", context)

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        opponent = self.get_object()
        context["cases"] = Case.objects.filter(opponents=opponent).select_related(
            "client"
        )
        context["now"] = timezone.now()
        return context


class OpponentUpdateView(PermissionRequiredMixin, LoginRequiredMixin, UpdateView):
    model = Opponent
    fields = [
        "name",
        "type",
        "phone",
        "job",
        "business_activity",
        "opponent_lawyer",
        "address",
        "notes",
    ]
    template_name = "core/opponent_form.html"
    success_url = reverse_lazy("core:opponents")
    permission_module = "opponents"
    permission_action = "change"

    def get(self, request, *args, **kwargs):
        self.object = self.get_object()
        if request.headers.get("X-Requested-With") == "XMLHttpRequest":
            context = self.get_context_data()
            context["opponent"] = self.object
            html = render_to_string(
                "core/includes/opponent_update_modal.html", context, request=request
            )
            return JsonResponse({"html": html})
        return redirect("core:opponents")

    def form_valid(self, form):
        self.object = form.save()
        if self.request.headers.get("X-Requested-With") == "XMLHttpRequest":
            return JsonResponse(
                {
                    "status": "success",
                    "message": f"✅ تم تحديث بيانات الخصم {self.object.name} بنجاح",
                    "opponent_id": self.object.id,
                }
            )
        messages.success(self.request, "✅ تم تحديث بيانات الخصم بنجاح")
        return redirect(self.get_success_url())

    def form_invalid(self, form):
        if self.request.headers.get("X-Requested-With") == "XMLHttpRequest":
            return JsonResponse({"status": "error", "errors": form.errors}, status=400)
        messages.error(self.request, "❌ هناك أخطاء في النموذج")
        return super().form_invalid(form)


class OpponentDeleteView(RoleRequiredMixin, LoginRequiredMixin, DeleteView):
    role_required = [ROLE_ADMIN]
    model = Opponent
    template_name = "core/opponent_confirm_delete.html"
    success_url = reverse_lazy("core:opponents")

    def get(self, request, *args, **kwargs):
        self.object = self.get_object()
        if request.headers.get("X-Requested-With") == "XMLHttpRequest":
            html = render_to_string("core/includes/generic_delete_modal_content.html", {"object": self.object}, request=request)
            return JsonResponse({"html": html})
        return super().get(request, *args, **kwargs)

    def delete(self, request, *args, **kwargs):
        obj = self.get_object()
        opponent_name = obj.name
        success_url = self.get_success_url()
        obj.delete()
        if request.headers.get("X-Requested-With") == "XMLHttpRequest":
            return JsonResponse({"status": "success", "message": f'تم حذف الخصم "{opponent_name}" بنجاح'})
        messages.success(request, f'✅ تم حذف الخصم "{opponent_name}" بنجاح')
        return redirect(success_url)


# ========================================
# Client Export Functions
# ========================================


def _get_filtered_clients_queryset(request):
    """Get filtered clients queryset matching the list view filters."""
    queryset = (
        Client.objects.all()
        .prefetch_related("cases", "invoices")
        .annotate(case_count=Count("cases"), lower_name=Lower("full_name"))
    )

    client_type = request.GET.get("type")
    if client_type:
        queryset = queryset.filter(type=client_type)

    status = request.GET.get("status")
    if status:
        queryset = queryset.filter(status=status)

    search = request.GET.get("search")
    if search:
        queryset = queryset.filter(
            Q(full_name__icontains=search)
            | Q(phone__icontains=search)
            | Q(client_id__icontains=search)
        )

    return queryset.order_by("-id")


def _get_filtered_opponents_queryset(request):
    """Get filtered opponents queryset matching the list view filters."""
    queryset = Opponent.objects.all().annotate(case_count=Count("cases"))
    opponent_type = request.GET.get("type")
    if opponent_type:
        queryset = queryset.filter(type=opponent_type)
    search = request.GET.get("search")
    if search:
        queryset = queryset.filter(
            Q(name__icontains=search)
            | Q(phone__icontains=search)
            | Q(opponent_lawyer__icontains=search)
        )
    order = request.GET.get("order", "name_asc")
    if order == "name_asc":
        queryset = queryset.order_by("name")
    elif order == "name_desc":
        queryset = queryset.order_by("-name")
    elif order == "newest":
        queryset = queryset.order_by("-created_at")
    elif order == "oldest":
        queryset = queryset.order_by("created_at")
    else:
        queryset = queryset.order_by("name")
    return queryset


@login_required
@permission_required("clients", "view")
def export_clients_excel(request):
    """Export clients to Excel (unified export)."""
    service = UnifiedExportService(request)
    return service.export(CLIENT_EXPORT_CONFIG, format="excel")


@login_required
@permission_required("clients", "view")
def export_clients_pdf(request):
    """Export clients to PDF (unified export)."""
    service = UnifiedExportService(request)
    return service.export(CLIENT_EXPORT_CONFIG, format="pdf")


@login_required
@permission_required("opponents", "view")
def export_opponents_excel(request):
    """Export opponents to Excel (unified export)."""
    service = UnifiedExportService(request)
    return service.export(OPPONENT_EXPORT_CONFIG, format="excel")


@login_required
@permission_required("opponents", "view")
def export_opponents_pdf(request):
    """Export opponents to PDF (unified export)."""
    service = UnifiedExportService(request)
    return service.export(OPPONENT_EXPORT_CONFIG, format="pdf")


# ============================================
# Unified Export: Row Mappers & Configs
# ============================================


def _map_client_row(client, is_pdf=False):
    if is_pdf:
        return [
            str(client.case_count or 0),
            client.get_status_display() or "—",
            client.phone or "—",
            client.get_type_display() or "—",
            client.full_name or "—",
            client.client_id or "—",
        ]
    return [
        client.client_id or "",
        client.full_name or "",
        client.get_type_display() or "",
        client.national_id or "",
        client.phone or "",
        client.job or "",
        client.address or "",
        client.get_status_display() or "",
        client.case_count or 0,
        client.created_at.strftime("%Y-%m-%d %H:%M") if client.created_at else "",
    ]


def _map_opponent_row(opponent, is_pdf=False):
    if is_pdf:
        return [
            str(opponent.case_count or 0),
            opponent.phone or "—",
            opponent.get_type_display() or "—",
            opponent.opponent_lawyer or "—",
            # عرض الوظيفة للأفراد أو النشاط التجاري للشركات
            (opponent.job or "—")
            if opponent.type == "individual"
            else (opponent.business_activity or "—"),
            opponent.name or "—",
        ]
    return [
        opponent.name or "",
        opponent.get_type_display() or "",
        opponent.phone or "",
        opponent.opponent_lawyer or "",
        # عرض الوظيفة للأفراد أو النشاط التجاري للشركات
        (opponent.job or "")
        if opponent.type == "individual"
        else (opponent.business_activity or ""),
        opponent.address or "",
        opponent.case_count or 0,
    ]


CLIENT_EXPORT_CONFIG = ExportConfig(
    model_name="العملاء",
    queryset_fn=lambda req: _get_filtered_clients_queryset(req),
    excel_headers=[
        "رقم العميل",
        "الاسم الكامل",
        "النوع",
        "الرقم القومي",
        "الهاتف",
        "الوظيفة",
        "العنوان",
        "الحالة",
        "عدد القضايا",
        "تاريخ الإضافة",
    ],
    pdf_headers=[
        "عدد القضايا",
        "الحالة",
        "الهاتف",
        "النوع",
        "الاسم الكامل",
        "رقم العميل",
    ],
    row_mapper=_map_client_row,
    right_align_cols=[1, 4, 5, 10],
    pdf_col_widths=[24 * mm, 24 * mm, 30 * mm, 24 * mm, 45 * mm, 28 * mm],
    theme_color="4F46E5",
    filename_prefix="clients",
)

OPPONENT_EXPORT_CONFIG = ExportConfig(
    model_name="الخصوم",
    queryset_fn=lambda req: _get_filtered_opponents_queryset(req),
    excel_headers=[
        "اسم الخصم",
        "النوع",
        "الهاتف",
        "محامي الخصم",
        "الوظيفة/النشاط",
        "العنوان",
        "عدد القضايا",
    ],
    pdf_headers=[
        "عدد القضايا",
        "الهاتف",
        "النوع",
        "محامي الخصم",
        "الوظيفة/النشاط",
        "اسم الخصم",
    ],
    row_mapper=_map_opponent_row,
    pdf_col_widths=[20 * mm, 26 * mm, 26 * mm, 30 * mm, 34 * mm, 40 * mm],
    theme_color="DC2626",
    filename_prefix="opponents",
)
