from django import template
from core.permissions import ROLE_PERMISSIONS, ROLE_ADMIN

register = template.Library()

@register.simple_tag
def has_permission(user, module, permission):
    """
    Template tag to check permissions for a specific module and action.
    
    Usage:
        {% has_permission user 'cases' 'add' as can_add %}
    """
    if not user.is_authenticated:
        return False
    
    user_role = getattr(user, 'role', None)
    
    if not user_role:
        return False
    
    # Admin has all permissions
    if user_role == ROLE_ADMIN:
        return True
    
    role_perms = ROLE_PERMISSIONS.get(user_role, {})
    module_perms = role_perms.get(module, [])
    
    return permission in module_perms


@register.simple_tag
def user_can(user, module, action=None):
    """
    Simplified check for whether a user can access a module or perform an action.
    """
    if not user.is_authenticated:
        return False
    
    user_role = getattr(user, 'role', None)
    
    if not user_role:
        return False
    
    # Admin has all permissions
    if user_role == ROLE_ADMIN:
        return True
    
    role_perms = ROLE_PERMISSIONS.get(user_role, {})
    module_perms = role_perms.get(module, [])
    
    if action:
        return action in module_perms
    
    return len(module_perms) > 0
