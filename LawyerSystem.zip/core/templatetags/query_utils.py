from django import template

register = template.Library()

@register.simple_tag(takes_context=True)
def query_transform(context, *args, **kwargs):
    """
    Returns the URL-encoded querystring for the current page,
    updating the params with the key/value pairs passed to the tag.
    
    Example:
    {% query_transform page=2 status='paid' %}
    {% query_transform request page=2 status='paid' %}
    """
    request = context.get('request')
    if not request:
        return ''
    
    query = request.GET.copy()
    
    for key, value in kwargs.items():
        if value is not None and value != '':
            query[key] = value
        else:
            if key in query:
                del query[key]
    
    return query.urlencode()