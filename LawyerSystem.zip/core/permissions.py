"""
نظام الصلاحيات حسب الأدوار
Admin, Lawyer, Secretary, Accountant
"""
from functools import wraps
from django.core.exceptions import PermissionDenied
from django.shortcuts import redirect
from django.contrib import messages
from django.http import JsonResponse


def _wants_json(request) -> bool:
    accept = (request.headers.get("Accept") or "").lower()
    return (
        request.headers.get("X-Requested-With") == "XMLHttpRequest"
        or "application/json" in accept
    )


def _deny(request, message: str = "❌ ليس لديك صلاحية للوصول إلى هذه الصفحة"):
    if _wants_json(request):
        return JsonResponse({"error": message}, status=403)
    messages.error(request, message)
    raise PermissionDenied


# ========================================
# Role Constants
# ========================================

ROLE_ADMIN = 'admin'
ROLE_LAWYER = 'lawyer'
ROLE_SECRETARY = 'secretary'
ROLE_ACCOUNTANT = 'accountant'

ROLE_CHOICES = [
    (ROLE_ADMIN, 'مدير النظام'),
    (ROLE_LAWYER, 'محامي'),
    (ROLE_SECRETARY, 'سكرتير'),
    (ROLE_ACCOUNTANT, 'محاسب'),
]


# ========================================
# Permission Matrices
# ========================================

# الصلاحيات الكاملة لكل دور
ROLE_PERMISSIONS = {
    ROLE_ADMIN: {
        'cases': ['view', 'add', 'change', 'delete'],
        'clients': ['view', 'add', 'change', 'delete'],
        'opponents': ['view', 'add', 'change', 'delete'],
        'sessions': ['view', 'add', 'change', 'delete'],
        'documents': ['view', 'add', 'change', 'delete'],
        'fees': ['view', 'add', 'change', 'delete'],
        'expenses': ['view', 'add', 'change', 'delete'],
        'invoices': ['view', 'add', 'change', 'delete'],
        'tasks': ['view', 'add', 'change', 'delete'],
        'appointments': ['view', 'add', 'change', 'delete'],
        'contracts': ['view', 'add', 'change', 'delete'],
        'power_of_attorney': ['view', 'add', 'change', 'delete'],
        'consultations': ['view', 'add', 'change', 'delete'],
        'declarations': ['view', 'add', 'change', 'delete'],
        'reports': ['view', 'export'],
        'settings': ['view', 'change'],
        'users': ['view', 'add', 'change', 'delete'],
    },
    ROLE_LAWYER: {
        'cases': ['view', 'add', 'change'],
        'clients': ['view', 'add', 'change'],
        'opponents': ['view', 'add', 'change'],
        'sessions': ['view', 'add', 'change'],
        'documents': ['view', 'add'],
        'fees': ['view'],
        'expenses': ['view', 'add'],
        'invoices': ['view'],
        'tasks': ['view', 'add', 'change'],  # Can manage own tasks
        'appointments': ['view', 'add', 'change'],
        'contracts': ['view', 'add'],
        'power_of_attorney': ['view', 'add'],
        'consultations': ['view', 'add', 'change'],
        'declarations': ['view', 'add'],
        'reports': ['view'],
        'settings': [],
        'users': [],
    },
    ROLE_SECRETARY: {
        'cases': ['view'],
        'clients': ['view', 'add', 'change'],
        'opponents': ['view', 'add', 'change'],
        'sessions': ['view', 'add', 'change'],
        'documents': ['view'],
        'fees': [],
        'expenses': [],
        'invoices': [],
        'tasks': ['view', 'add'],
        'appointments': ['view', 'add', 'change'],
        'contracts': ['view'],
        'power_of_attorney': ['view'],
        'consultations': ['view', 'add'],
        'declarations': ['view', 'add'],
        'reports': ['view'],
        'settings': [],
        'users': [],
    },
    ROLE_ACCOUNTANT: {
        'cases': ['view'],
        'clients': ['view'],
        'opponents': [],
        'sessions': [],
        'documents': [],
        'fees': ['view', 'add', 'change'],
        'expenses': ['view', 'add', 'change'],
        'invoices': ['view', 'add', 'change'],
        'tasks': [],
        'appointments': [],
        'contracts': ['view'],
        'power_of_attorney': [],
        'consultations': ['view', 'add', 'change'],
        'declarations': [],
        'reports': ['view', 'export'],
        'settings': [],
        'users': [],
    },
}


# ========================================
# Decorators
# ========================================

def role_required(allowed_roles):
    """
    Decorator to restrict view access to specific roles
    
    Usage:
        @role_required([ROLE_ADMIN, ROLE_LAWYER])
        def my_view(request):
            ...
    """
    def decorator(view_func):
        @wraps(view_func)
        def _wrapped_view(request, *args, **kwargs):
            if not request.user.is_authenticated:
                return redirect('core:login')
            
            user_role = getattr(request.user, 'role', None)
            
            if not user_role or user_role not in allowed_roles:
                return _deny(request)
            
            return view_func(request, *args, **kwargs)
        return _wrapped_view
    return decorator


def permission_required(module, permission):
    """
    Decorator to check specific module permission
    
    Usage:
        @permission_required('cases', 'add')
        def create_case(request):
            ...
    """
    def decorator(view_func):
        @wraps(view_func)
        def _wrapped_view(request, *args, **kwargs):
            if not request.user.is_authenticated:
                return redirect('core:login')
            
            user_role = getattr(request.user, 'role', None)
            
            if not user_role:
                return _deny(request)
            
            # Admin has all permissions
            if user_role == ROLE_ADMIN:
                return view_func(request, *args, **kwargs)
            
            # Check permission
            role_perms = ROLE_PERMISSIONS.get(user_role, {})
            module_perms = role_perms.get(module, [])
            
            if permission not in module_perms:
                return _deny(request, f'❌ ليس لديك صلاحية {permission} في {module}')
            
            return view_func(request, *args, **kwargs)
        return _wrapped_view
    return decorator


# ========================================
# Mixins for Class-Based Views
# ========================================


from django.contrib.auth.mixins import UserPassesTestMixin

class RoleRequiredMixin(UserPassesTestMixin):
    """
    Mixin to restrict access based on user role
    
    Usage:
        class CaseCreateView(RoleRequiredMixin, CreateView):
            role_required = [ROLE_ADMIN, ROLE_LAWYER]
    """
    role_required = None
    
    def test_func(self):
        if not self.request.user.is_authenticated:
            return False
        
        user_role = getattr(self.request.user, 'role', None)
        
        if not user_role:
            return False
        
        # Admin can access everything
        if user_role == ROLE_ADMIN:
            return True
        
        if self.role_required is None:
            return True
        
        return user_role in self.role_required
    
    def handle_no_permission(self):
        response = _deny(self.request)
        if isinstance(response, JsonResponse):
            return response
        return redirect('core:dashboard')


class PermissionRequiredMixin(UserPassesTestMixin):
    """
    Mixin to check specific module permission
    
    Usage:
        class CaseCreateView(PermissionRequiredMixin, CreateView):
            permission_module = 'cases'
            permission_action = 'add'
    """
    permission_module = None
    permission_action = None
    
    def test_func(self):
        if not self.request.user.is_authenticated:
            return False
        
        user_role = getattr(self.request.user, 'role', None)
        
        if not user_role:
            return False
        
        # Admin can access everything
        if user_role == ROLE_ADMIN:
            return True
        
        if not self.permission_module:
            return True
        
        role_perms = ROLE_PERMISSIONS.get(user_role, {})
        module_perms = role_perms.get(self.permission_module, [])
        
        if self.permission_action:
            return self.permission_action in module_perms
        
        return len(module_perms) > 0
    
    def handle_no_permission(self):
        response = _deny(self.request)
        if isinstance(response, JsonResponse):
            return response
        return redirect('core:dashboard')
