from django.db import migrations

def migrate_company_national_ids(apps, schema_editor):
    """
    ينقل البيانات القديمة المسجلة في حقل national_id 
    إلى الحقل الجديد commercial_register لعملاء نوع "شركة"
    """
    Client = apps.get_model('core', 'Client')
    companies = Client.objects.filter(type='company').exclude(national_id='')
    
    for company in companies:
        company.commercial_register = company.national_id
        company.national_id = ''
        company.save(update_fields=['commercial_register', 'national_id'])

def reverse_migration(apps, schema_editor):
    """
    عكس العملية في حالة الحاجة للرجوع (نقل البيانات من السجل التجاري إلى الرقم القومي)
    """
    Client = apps.get_model('core', 'Client')
    companies = Client.objects.filter(type='company').exclude(commercial_register='')
    
    for company in companies:
        company.national_id = company.commercial_register
        company.commercial_register = ''
        company.save(update_fields=['national_id', 'commercial_register'])

class Migration(migrations.Migration):

    dependencies = [
        ('core', '0020_client_commercial_register_client_tax_card'),
    ]

    operations = [
        migrations.RunPython(migrate_company_national_ids, reverse_migration),
    ]
