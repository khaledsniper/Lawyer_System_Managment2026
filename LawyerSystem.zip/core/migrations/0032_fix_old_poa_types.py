"""
Data migration to fix old PowerOfAttorney type values to match the new choices
"""

from django.db import migrations

def fix_old_poa_types(apps, schema_editor):
    PowerOfAttorney = apps.get_model("core", "PowerOfAttorney")
    
    # Fix the 'general' value to 'general_official' which is the correct new value
    PowerOfAttorney.objects.filter(type='general').update(type='general_official')

def reverse_fix_old_poa_types(apps, schema_editor):
    # Reverse the change if needed
    PowerOfAttorney = apps.get_model("core", "PowerOfAttorney")
    PowerOfAttorney.objects.filter(type='general_official').update(type='general')

class Migration(migrations.Migration):
    dependencies = [
        ('core', '0031_powerofattorney_poa_images'),
    ]

    operations = [
        migrations.RunPython(fix_old_poa_types, reverse_fix_old_poa_types),
    ]