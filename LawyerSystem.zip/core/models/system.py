from django.db import models
from django.conf import settings

class NotificationType(models.TextChoices):
    SESSION = 'session', 'جلسة'
    PAYMENT = 'payment', 'دفعة'
    TASK = 'task', 'مهمة'
    CASE = 'case', 'قضية'
    CONTRACT = 'contract', 'عقد'

class Notification(models.Model):
    """إشعار"""
    message = models.TextField(
        verbose_name='الرسالة'
    )
    notification_type = models.CharField(
        max_length=20,
        choices=NotificationType.choices,
        default=NotificationType.CASE,
        verbose_name='نوع الإشعار'
    )
    is_read = models.BooleanField(
        default=False,
        verbose_name='تمت القراءة'
    )
    target_user = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name='notifications',
        verbose_name='المستخدم المستهدف'
    )
    created_at = models.DateTimeField(
        auto_now_add=True,
        verbose_name='تاريخ الإنشاء'
    )

    class Meta:
        app_label = 'core'
        verbose_name = 'إشعار'
        verbose_name_plural = 'الإشعارات'
        indexes = [
            models.Index(fields=['target_user']),
            models.Index(fields=['is_read']),
            models.Index(fields=['created_at']),
        ]

    def __str__(self):
        return self.message[:50] + '...' if len(self.message) > 50 else self.message

class Court(models.Model):
    """المحكمة"""
    name = models.CharField(
        max_length=200,
        unique=True,
        verbose_name='اسم المحكمة'
    )
    city = models.CharField(
        max_length=100,
        blank=True,
        verbose_name='المدينة'
    )
    is_active = models.BooleanField(
        default=True,
        verbose_name='نشطة'
    )

    class Meta:
        app_label = 'core'
        verbose_name = 'محكمة'
        verbose_name_plural = 'المحاكم'
        ordering = ['name']

    def __str__(self):
        return self.name

class LookupCategory(models.TextChoices):
    COURTS = 'courts', 'المحاكم'
    CASE_TYPES = 'case_types', 'أنواع القضايا'
    EXPENSE_CATEGORIES = 'expense_categories', 'فئات المصروفات'

class LookupData(models.Model):
    """بيانات مرجعية (محاكم، أنواع قضايا، فئات مصروفات)"""
    category = models.CharField(
        max_length=30,
        choices=LookupCategory.choices,
        verbose_name='الفئة'
    )
    name = models.CharField(
        max_length=200,
        verbose_name='الاسم'
    )
    is_active = models.BooleanField(
        default=True,
        verbose_name='نشط'
    )

    class Meta:
        app_label = 'core'
        verbose_name = 'بيانات مرجعية'
        verbose_name_plural = 'البيانات المرجعية'
        indexes = [
            models.Index(fields=['category']),
            models.Index(fields=['is_active']),
        ]
        unique_together = [['category', 'name']]

    def __str__(self):
        return f"{self.get_category_display()} - {self.name}"
