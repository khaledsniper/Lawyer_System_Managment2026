from decimal import Decimal
from django.db import models
from .clients import Client
from .base import validate_file_size, create_file_validator, contract_upload_path, poa_upload_path, declaration_upload_path

class ContractStatus(models.TextChoices):
    DRAFT = 'draft', 'مسودة'
    PENDING_SIGNATURE = 'pending_signature', 'بانتظار التوقيع'
    ACTIVE = 'active', 'نشط'
    EXPIRED = 'expired', 'منتهي'

class ContractType(models.TextChoices):
    FEES = 'fees', 'أتعاب محاماة'
    OWNERSHIP_TRANSFER = 'ownership_transfer', 'نقل ملكية'
    BENEFICIARY = 'beneficiary', 'الانتفاع (المنفعة)'
    SERVICES = 'services', 'العمل والخدمات'
    GUARANTEES = 'guarantees', 'الضمانات والغرر'

class PowerOfAttorneyType(models.TextChoices):
    GENERAL_OFFICIAL = 'general_official', 'رسمي عام'
    GENERAL_CASES = 'general_cases', 'رسمي عام قضايا'
    GENERAL_BANKS = 'general_banks', 'عام بالبنوك'
    SPECIAL = 'special', 'توكيل خاص'
    COMMERCIAL = 'commercial', 'توكيل تجاري'
    REAL_ESTATE = 'real_estate', 'توكيل عقاري'

class Contract(models.Model):
    """عقد"""
    contract_number = models.CharField(
        max_length=50,
        unique=True,
        verbose_name='رقم العقد'
    )
    type = models.CharField(
        max_length=50,
        choices=ContractType.choices,
        default=ContractType.FEES,
        verbose_name='نوع العقد'
    )
    client = models.ForeignKey(
        Client,
        on_delete=models.CASCADE,
        related_name='contracts',
        verbose_name='العميل'
    )
    value = models.DecimalField(
        max_digits=12,
        decimal_places=2,
        default=Decimal('0'),
        verbose_name='القيمة'
    )
    start_date = models.DateField(
        verbose_name='تاريخ البدء'
    )
    end_date = models.DateField(
        verbose_name='تاريخ الانتهاء'
    )
    status = models.CharField(
        max_length=30,
        choices=ContractStatus.choices,
        default=ContractStatus.DRAFT,
        verbose_name='الحالة'
    )
    file = models.FileField(
        upload_to=contract_upload_path,
        blank=True,
        null=True,
        validators=[validate_file_size, create_file_validator()],
        verbose_name='الملف'
    )

    notes = models.TextField(
        blank=True,
        verbose_name='ملاحظات'
    )
    


    contract_images = models.ImageField(
        upload_to=contract_upload_path,
        blank=True,
        null=True,
        validators=[validate_file_size, create_file_validator(allowed_extensions=['jpg', 'jpeg', 'png', 'gif', 'webp'])],
        verbose_name='صور العقد'
    )

    class Meta:
        app_label = 'core'
        verbose_name = 'عقد'
        verbose_name_plural = 'العقود'
        indexes = [
            models.Index(fields=['contract_number']),
            models.Index(fields=['client']),
            models.Index(fields=['status']),
            models.Index(fields=['end_date']),
        ]

    def __str__(self):
        return f"{self.contract_number} - {self.client.full_name}"

    @property
    def is_expiring_soon(self):
        from django.utils import timezone
        if not self.end_date:
            return False
        days_left = (self.end_date - timezone.now().date()).days
        return 0 <= days_left <= 30 and self.status == 'active'

class PowerOfAttorneyStatus(models.TextChoices):
    ACTIVE = 'active', 'نشط'
    EXPIRING_SOON = 'expiring_soon', 'قارب على الانتهاء'
    EXPIRED = 'expired', 'منتهي'

class PowerOfAttorney(models.Model):
    """وكالة"""
    client = models.ForeignKey(
        Client,
        on_delete=models.CASCADE,
        related_name='powers_of_attorney',
        verbose_name='العميل'
    )
    type = models.CharField(
        max_length=30,
        choices=PowerOfAttorneyType.choices,
        default=PowerOfAttorneyType.GENERAL_OFFICIAL,
        verbose_name='نوع الوكالة'
    )
    issue_date = models.DateField(
        verbose_name='تاريخ الإصدار'
    )
    expiry_date = models.DateField(
        verbose_name='تاريخ الانتهاء'
    )
    issuer = models.CharField(
        max_length=200,
        blank=True,
        verbose_name='الجهة المصدرة'
    )
    file = models.FileField(
        upload_to=poa_upload_path,
        blank=True,
        null=True,
        validators=[validate_file_size, create_file_validator()],
        verbose_name='الملف'
    )
    status = models.CharField(
        max_length=20,
        choices=PowerOfAttorneyStatus.choices,
        default=PowerOfAttorneyStatus.ACTIVE,
        verbose_name='الحالة'
    )
    poa_images = models.ImageField(
        upload_to=poa_upload_path,
        blank=True,
        null=True,
        validators=[validate_file_size, create_file_validator(allowed_extensions=['jpg', 'jpeg', 'png', 'gif', 'webp'])],
        verbose_name='صور التوكيل'
    )
    notes = models.TextField(
        blank=True,
        verbose_name='ملاحظات'
    )

    class Meta:
        app_label = 'core'
        verbose_name = 'وكالة'
        verbose_name_plural = 'التوكيلات'
        indexes = [
            models.Index(fields=['client']),
            models.Index(fields=['expiry_date']),
            models.Index(fields=['status']),
        ]

    def __str__(self):
        return f"{self.get_type_display()} - {self.client.full_name}"

    @property
    def is_expiring_soon(self):
        from django.utils import timezone
        if not self.expiry_date or self.status == 'expired':
            return False
        days_until_expiry = (self.expiry_date - timezone.now().date()).days
        return 0 < days_until_expiry <= 30

class DeclarationStatus(models.TextChoices):
    DRAFT = 'draft', 'مسودة'
    FINAL = 'final', 'نهائي'
    SIGNED = 'signed', 'موقع'

class Declaration(models.Model):
    """إقرار"""
    declaration_number = models.CharField(
        max_length=50,
        unique=True,
        verbose_name='رقم الإقرار'
    )
    type = models.CharField(
        max_length=200,
        verbose_name='نوع الإقرار'
    )
    client = models.ForeignKey(
        Client,
        on_delete=models.CASCADE,
        related_name='declarations',
        verbose_name='العميل'
    )
    date = models.DateField(
        verbose_name='التاريخ'
    )
    status = models.CharField(
        max_length=20,
        choices=DeclarationStatus.choices,
        default=DeclarationStatus.DRAFT,
        verbose_name='الحالة'
    )
    file = models.FileField(
        upload_to=declaration_upload_path,
        blank=True,
        null=True,
        validators=[validate_file_size, create_file_validator()],
        verbose_name='الملف'
    )

    class Meta:
        app_label = 'core'
        verbose_name = 'إقرار'
        verbose_name_plural = 'الإقرارات'
        indexes = [
            models.Index(fields=['declaration_number']),
            models.Index(fields=['client']),
            models.Index(fields=['date']),
        ]

    def __str__(self):
        return f"{self.declaration_number} - {self.type}"
