from decimal import Decimal
from django.db import models
from django.utils import timezone
from .clients import Client
from .cases import Case
from .users import OfficeProfile
from .base import SequenceCounter, validate_file_size, create_file_validator, expense_receipt_upload_path

class FeeType(models.TextChoices):
    FIXED = 'fixed', 'مبلغ ثابت'
    HOURLY = 'hourly', 'بالساعة'

class FeeStatus(models.TextChoices):
    PENDING = 'pending', 'معلق'
    PAID = 'paid', 'مدفوع'
    PARTIAL = 'partial', 'مدفوع جزئياً'

class FeeManager(models.Manager):
    def get_financial_summary(self):
        from django.db.models import Sum
        total_fees = self.aggregate(total=Sum('agreed_amount'))['total'] or 0
        total_collected = Payment.objects.aggregate(total=Sum('amount'))['total'] or 0
        total_expenses = Expense.objects.aggregate(total=Sum('amount'))['total'] or 0
        return {
            'total_fees': total_fees,
            'total_collected': total_collected,
            'total_expenses': total_expenses,
            'net_profit': total_collected - total_expenses
        }

class Fee(models.Model):
    """أتعاب القضية"""
    objects: FeeManager = FeeManager()
    case = models.ForeignKey(
        Case,
        on_delete=models.CASCADE,
        related_name='fees',
        verbose_name='القضية'
    )
    fee_type = models.CharField(
        max_length=20,
        choices=FeeType.choices,
        default=FeeType.FIXED,
        verbose_name='نوع الأتعاب'
    )
    agreed_amount = models.DecimalField(
        max_digits=12,
        decimal_places=2,
        default=Decimal('0'),
        verbose_name='المبلغ المتفق عليه'
    )
    status = models.CharField(
        max_length=20,
        choices=FeeStatus.choices,
        default=FeeStatus.PENDING,
        verbose_name='الحالة'
    )

    class Meta:
        app_label = 'core'
        verbose_name = 'أتعاب'
        verbose_name_plural = 'الأتعاب'
        indexes = [
            models.Index(fields=['case']),
            models.Index(fields=['status']),
        ]

    def __str__(self):
        return f"{self.case.case_number} - {self.agreed_amount} {self.get_status_display()}"

class PaymentMethod(models.TextChoices):
    CASH = 'cash', 'نقدي'
    TRANSFER = 'transfer', 'تحويل'
    CHECK = 'check', 'شيك'

class Payment(models.Model):
    """دفعة مقابل أتعاب"""
    amount = models.DecimalField(
        max_digits=12,
        decimal_places=2,
        verbose_name='المبلغ'
    )
    date = models.DateField(
        verbose_name='التاريخ'
    )
    payment_method = models.CharField(
        max_length=20,
        choices=PaymentMethod.choices,
        default=PaymentMethod.CASH,
        verbose_name='طريقة الدفع'
    )
    fee = models.ForeignKey(
        Fee,
        on_delete=models.CASCADE,
        related_name='payments',
        verbose_name='الأتعاب'
    )
    notes = models.TextField(
        blank=True,
        verbose_name='ملاحظات'
    )

    class Meta:
        app_label = 'core'
        verbose_name = 'دفعة'
        verbose_name_plural = 'الدفعات'
        indexes = [
            models.Index(fields=['fee']),
            models.Index(fields=['date']),
        ]

    def __str__(self):
        return f"{self.amount} - {self.date}"

class InvoiceStatus(models.TextChoices):
    PAID = 'paid', 'مدفوع'
    PENDING = 'pending', 'معلق'
    CANCELLED = 'cancelled', 'ملغي'

class Invoice(models.Model):
    """فاتورة"""
    invoice_number = models.CharField(
        max_length=30,
        unique=True,
        editable=False,
        verbose_name='رقم الفاتورة'
    )
    client = models.ForeignKey(
        Client,
        on_delete=models.CASCADE,
        related_name='invoices',
        verbose_name='العميل'
    )
    subtotal = models.DecimalField(
        max_digits=12,
        decimal_places=2,
        default=Decimal('0'),
        verbose_name='المجموع الفرعي'
    )
    tax_rate = models.DecimalField(
        max_digits=5,
        decimal_places=2,
        default=Decimal('14'),
        verbose_name='نسبة الضريبة %'
    )
    tax_amount = models.DecimalField(
        max_digits=12,
        decimal_places=2,
        default=Decimal('0'),
        editable=False,
        verbose_name='مبلغ الضريبة'
    )
    total = models.DecimalField(
        max_digits=12,
        decimal_places=2,
        default=Decimal('0'),
        editable=False,
        verbose_name='الإجمالي'
    )
    status = models.CharField(
        max_length=20,
        choices=InvoiceStatus.choices,
        default=InvoiceStatus.PENDING,
        verbose_name='الحالة'
    )
    date = models.DateField(
        verbose_name='التاريخ'
    )
    due_date = models.DateField(
        null=True,
        blank=True,
        verbose_name='تاريخ الاستحقاق'
    )
    notes = models.TextField(
        blank=True,
        verbose_name='ملاحظات'
    )
    created_at = models.DateTimeField(
        default=timezone.now,
        verbose_name='تاريخ الإنشاء'
    )
    updated_at = models.DateTimeField(
        auto_now=True,
        verbose_name='تاريخ التحديث'
    )

    class Meta:
        app_label = 'core'
        verbose_name = 'فاتورة'
        verbose_name_plural = 'الفواتير'
        indexes = [
            models.Index(fields=['invoice_number']),
            models.Index(fields=['client']),
            models.Index(fields=['status']),
            models.Index(fields=['date']),
        ]

    def save(self, *args, **kwargs):
        if not self.pk and self.tax_rate == Decimal('14'):
            profile = OfficeProfile.objects.first()
            if profile:
                self.tax_rate = profile.default_tax_rate
        self.tax_amount = (self.subtotal * self.tax_rate / Decimal('100')).quantize(Decimal('0.01'))
        self.total = self.subtotal + self.tax_amount
        if not self.invoice_number:
            year = timezone.now().year
            sequence_value = SequenceCounter.get_next_formatted(
                name='invoice_number',
                prefix=f'INV-{year}',
                digits=6
            )
            self.invoice_number = sequence_value
        super().save(*args, **kwargs)

    def __str__(self):
        return f"{self.invoice_number} - {self.client.full_name}"

class ExpenseType(models.TextChoices):
    CASE = 'case', 'مصروف قضية'
    OFFICE = 'office', 'مصروف مكتب'

class ExpenseCategory(models.TextChoices):
    # فئات مصروفات القضايا
    COURT_FEES = 'court_fees', 'رسوم محكمة'
    DOCUMENTATION = 'documentation', 'رسوم توثيق'
    EXPERT_FEE = 'expert_fee', 'أمانة الخبير'
    ANNOUNCEMENTS = 'announcements', 'الإعلانات القضائية'
    ENFORCEMENT = 'enforcement', 'تنفيذ الأحكام'
    PRINTING = 'printing', 'طباعة مستندات'
    TRANSPORT = 'transport', 'انتقالات'
    
    # فئات مصروفات المكتب
    RENT = 'rent', 'الإيجار الشهري'
    SALARIES = 'salaries', 'رواتب وعمالة'
    INVOICES = 'invoices', 'فواتير'
    MAINTENANCE = 'maintenance', 'صيانة'
    OFFICE_SUPPLIES = 'office_supplies', 'مستلزمات مكتبية'
    HOSPITALITY = 'hospitality', 'ضيافة ومشروبات'
    CLEANING = 'cleaning', 'أدوات نظافة'
    
    OTHER = 'other', 'أخرى'

class Expense(models.Model):
    """مصروف"""
    expense_type = models.CharField(
        max_length=20,
        choices=ExpenseType.choices,
        default=ExpenseType.CASE,
        verbose_name='نوع المصروف'
    )
    description = models.CharField(
        max_length=500,
        verbose_name='البيان'
    )
    category = models.CharField(
        max_length=30,
        choices=ExpenseCategory.choices,
        default=ExpenseCategory.OTHER,
        verbose_name='الفئة'
    )
    amount = models.DecimalField(
        max_digits=12,
        decimal_places=0,
        verbose_name='المبلغ'
    )
    case = models.ForeignKey(
        Case,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='expenses',
        verbose_name='القضية'
    )
    receipt = models.FileField(
        upload_to=expense_receipt_upload_path,
        blank=True,
        null=True,
        validators=[validate_file_size, create_file_validator()],
        verbose_name='إيصال'
    )
    receipt_number = models.CharField(
        max_length=100,
        blank=True,
        null=True,
        verbose_name='رقم الإيصال'
    )
    payment_method = models.CharField(
        max_length=20,
        choices=[
            ('cash', 'نقدي'),
            ('bank_transfer', 'تحويل بنكي'),
            ('wallet', 'محفظة كاش'),
        ],
        blank=True,
        null=True,
        verbose_name='طريقة الدفع'
    )
    date = models.DateField(
        verbose_name='التاريخ'
    )
    notes = models.TextField(
        blank=True,
        null=True,
        verbose_name='ملاحظات'
    )
    created_at = models.DateTimeField(
        default=timezone.now,
        verbose_name='تاريخ الإنشاء'
    )
    updated_at = models.DateTimeField(
        auto_now=True,
        verbose_name='تاريخ التحديث'
    )

    class Meta:
        app_label = 'core'
        verbose_name = 'مصروف'
        verbose_name_plural = 'المصروفات'
        indexes = [
            models.Index(fields=['case']),
            models.Index(fields=['category']),
            models.Index(fields=['date']),
        ]

    def __str__(self):
        return f"{self.description} - {self.amount}"

class ConsultationStatus(models.TextChoices):
    NEW = 'new', 'جديد'
    COMPLETED = 'completed', 'منتهي'

class Consultation(models.Model):
    """استشارة"""
    title = models.CharField(
        max_length=200,
        verbose_name='العنوان'
    )
    client = models.ForeignKey(
        Client,
        on_delete=models.CASCADE,
        related_name='consultations',
        verbose_name='العميل'
    )
    date = models.DateField(
        verbose_name='التاريخ'
    )
    notes = models.TextField(
        blank=True,
        verbose_name='ملاحظات/توثيق الكلام'
    )
    amount_collected = models.DecimalField(
        max_digits=12,
        decimal_places=2,
        default=Decimal('0'),
        verbose_name='المبلغ المحصل'
    )
    status = models.CharField(
        max_length=20,
        choices=ConsultationStatus.choices,
        default=ConsultationStatus.NEW,
        verbose_name='الحالة'
    )

    class Meta:
        app_label = 'core'
        verbose_name = 'استشارة'
        verbose_name_plural = 'الاستشارات'
        indexes = [
            models.Index(fields=['client']),
            models.Index(fields=['date']),
            models.Index(fields=['status']),
        ]

    def __str__(self):
        return f"{self.title} - {self.client.full_name}"
