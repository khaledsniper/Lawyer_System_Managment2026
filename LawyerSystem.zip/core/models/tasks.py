from django.db import models
from django.conf import settings
from .clients import Client
from .cases import Case

class TaskStatus(models.TextChoices):
    NEW = 'new', 'جديد'
    IN_PROGRESS = 'in_progress', 'قيد التنفيذ'
    REVIEW = 'review', 'مراجعة'
    DONE = 'done', 'منتهي'

class TaskPriority(models.TextChoices):
    URGENT = 'urgent', 'عاجل'
    HIGH = 'high', 'عالي'
    NORMAL = 'normal', 'عادي'
    LOW = 'low', 'منخفض'

class Task(models.Model):
    """مهمة"""
    title = models.CharField(
        max_length=200,
        verbose_name='العنوان'
    )
    description = models.TextField(
        blank=True,
        verbose_name='الوصف'
    )
    status = models.CharField(
        max_length=20,
        choices=TaskStatus.choices,
        default=TaskStatus.NEW,
        verbose_name='الحالة'
    )
    priority = models.CharField(
        max_length=20,
        choices=TaskPriority.choices,
        default=TaskPriority.NORMAL,
        verbose_name='الأولوية'
    )
    assigned_to = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='assigned_tasks',
        verbose_name='المكلف'
    )
    due_date = models.DateField(
        null=True,
        blank=True,
        verbose_name='تاريخ الاستحقاق'
    )
    case = models.ForeignKey(
        Case,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='tasks',
        verbose_name='القضية'
    )

    class Meta:
        app_label = 'core'
        verbose_name = 'مهمة'
        verbose_name_plural = 'المهام'
        indexes = [
            models.Index(fields=['assigned_to']),
            models.Index(fields=['status']),
            models.Index(fields=['due_date']),
            models.Index(fields=['case']),
        ]

    def __str__(self):
        return self.title

class AppointmentType(models.TextChoices):
    MEETING = 'meeting', 'اجتماع'
    CALL = 'call', 'مكالمة'
    CONSULTATION = 'consultation', 'استشارة'
    COURT_VISIT = 'court_visit', 'زيارة محكمة'
    SIGNING = 'signing', 'توقيع'

class AppointmentStatus(models.TextChoices):
    SCHEDULED = 'scheduled', 'مجدول'
    COMPLETED = 'completed', 'منتهي'
    CANCELLED = 'cancelled', 'ملغي'

class Appointment(models.Model):
    """موعد"""
    type = models.CharField(
        max_length=30,
        choices=AppointmentType.choices,
        default=AppointmentType.MEETING,
        verbose_name='النوع'
    )
    client = models.ForeignKey(
        Client,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='appointments',
        verbose_name='العميل'
    )
    location = models.CharField(
        max_length=300,
        blank=True,
        verbose_name='المكان'
    )
    datetime = models.DateTimeField(
        verbose_name='التاريخ والوقت'
    )
    status = models.CharField(
        max_length=20,
        choices=AppointmentStatus.choices,
        default=AppointmentStatus.SCHEDULED,
        verbose_name='الحالة'
    )
    case = models.ForeignKey(
        'Case',
        on_delete=models.CASCADE,
        null=True,
        blank=True,
        related_name='appointments',
        verbose_name="القضية"
    )
    class Meta:
        app_label = 'core'
        verbose_name = 'موعد'
        verbose_name_plural = 'المواعيد'
        indexes = [
            models.Index(fields=['client']),
            models.Index(fields=['datetime']),
            models.Index(fields=['status']),
        ]

    def __str__(self):
        return f"{self.get_type_display()} - {self.datetime}"
