# core/models/__init__.py
# ملاحظة: جميع الأسماء يجب أن تبقى مُصدَّرة هنا لأن ملفات Migration تشير إليها
# عبر core.models.<name> مباشرةً — لا تحذف أياً منها

from .base import (
    SequenceCounter,
    validate_file_size,
    validate_file_extension,
    create_file_validator,
    create_image_validator,
    document_upload_path,
    session_attachment_upload_path,
    contract_upload_path,
    poa_upload_path,
    declaration_upload_path,
    expense_receipt_upload_path,
    logo_upload_path,
    profile_picture_upload_path,
)
from .users import User, OfficeProfile, UserRole
from .clients import (
    Client, ClientAttachment, Opponent,
    ClientType, ClientStatus, OpponentType,
    ClientManager,
    client_attachment_path,   # مطلوب من Migration 0008
)
from .cases import (
    Case, Session, Document,
    CaseStatus, CasePriority, SessionStatus,
    DocumentType, SecurityLevel,
    CaseManager,
)
from .finance import (
    Fee, Payment, Invoice, Expense, Consultation,
    FeeType, FeeStatus, PaymentMethod,
    InvoiceStatus, ExpenseCategory, ConsultationStatus,
    FeeManager,
)
from .tasks import (
    Task, Appointment,
    TaskStatus, TaskPriority,
    AppointmentType, AppointmentStatus,
)
from .legal import (
    Contract, PowerOfAttorney, Declaration,
    ContractStatus, PowerOfAttorneyType,
    PowerOfAttorneyStatus, DeclarationStatus,
)
from .system import (
    Notification, LookupData, Court,
    NotificationType, LookupCategory,
)
