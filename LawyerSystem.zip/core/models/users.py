from django.db import models
from django.contrib.auth.models import AbstractUser
from decimal import Decimal
from .base import validate_file_size, create_image_validator, profile_picture_upload_path, logo_upload_path

class UserRole(models.TextChoices):
    ADMIN = 'admin', 'مدير النظام'
    LAWYER = 'lawyer', 'محامي'
    SECRETARY = 'secretary', 'سكرتير'
    ACCOUNTANT = 'accountant', 'محاسب'

class User(AbstractUser):
    """مستخدم النظام (مدير، محامي، سكرتير، محاسب)"""
    role = models.CharField(
        max_length=20,
        choices=UserRole.choices,
        default=UserRole.LAWYER,
        verbose_name='الدور'
    )
    bar_number = models.CharField(
        max_length=50,
        blank=True,
        verbose_name='رقم القيد'
    )
    specialization = models.CharField(
        max_length=200,
        blank=True,
        verbose_name='التخصص'
    )
    profile_picture = models.ImageField(
        upload_to=profile_picture_upload_path,
        blank=True,
        null=True,
        validators=[validate_file_size, create_image_validator()],
        verbose_name='صورة الملف الشخصي'
    )
    theme_preference = models.CharField(
        max_length=10,
        default='light',
        choices=[('light', 'فاتح'), ('dark', 'داكن')],
        verbose_name='تفضيل المظهر',
    )

    class Meta:
        app_label = 'core'
        verbose_name = 'مستخدم'
        verbose_name_plural = 'المستخدمون'
        indexes = [
            models.Index(fields=['role']),
            models.Index(fields=['is_active']),
        ]

    def __str__(self):
        return self.get_full_name() or self.username

class OfficeProfile(models.Model):
    """ملف المكتب (الشعار، البيانات الضريبية، الاتصال)"""
    logo = models.ImageField(
        upload_to=logo_upload_path,
        blank=True,
        null=True,
        validators=[validate_file_size, create_image_validator()],
        verbose_name='شعار المكتب'
    )
    name = models.CharField(
        max_length=200,
        blank=True,
        verbose_name='اسم المكتب'
    )
    tax_id = models.CharField(
        max_length=50,
        blank=True,
        verbose_name='الرقم الضريبي'
    )
    phone = models.CharField(
        max_length=30,
        blank=True,
        verbose_name='الهاتف'
    )
    address = models.TextField(
        blank=True,
        verbose_name='العنوان'
    )
    currency = models.CharField(
        max_length=10,
        default='EGP',
        verbose_name='العملة'
    )
    commercial_registration = models.CharField(
        max_length=100,
        blank=True,
        verbose_name='السجل التجاري'
    )
    license_number = models.CharField(
        max_length=100,
        blank=True,
        verbose_name='رقم الترخيص'
    )
    default_tax_rate = models.DecimalField(
        max_digits=5,
        decimal_places=2,
        default=Decimal('14'),
        verbose_name='نسبة الضريبة الافتراضية %'
    )

    class Meta:
        app_label = 'core'
        verbose_name = 'ملف المكتب'
        verbose_name_plural = 'ملف المكتب'

    def __str__(self):
        return self.name or 'ملف المكتب'
