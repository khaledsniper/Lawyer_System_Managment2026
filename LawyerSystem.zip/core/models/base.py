from django.db import models, transaction
from django.template.defaultfilters import filesizeformat
from django.core.exceptions import ValidationError
from django.utils import timezone

# ==================== FILE VALIDATORS ====================

def validate_file_size(value):
    """
    التحقق من حجم الملف (حد أقصى 10 ميجابايت)
    """
    max_size = 10 * 1024 * 1024  # 10 MB
    if value.size > max_size:
        raise ValidationError(f'حجم الملف كبير جداً. الحد الأقصى: {filesizeformat(max_size)}')


def validate_file_extension(value, allowed_extensions=None):
    """
    التحقق من امتداد الملف
    الأنواع المسموحة: pdf, doc, docx, jpg, jpeg, png, gif, txt
    """
    if allowed_extensions is None:
        allowed_extensions = ['pdf', 'doc', 'docx', 'jpg', 'jpeg', 'png', 'gif', 'txt']
    
    ext = value.name.split('.')[-1].lower()
    if ext not in allowed_extensions:
        raise ValidationError(
            f'نوع الملف غير مسموح. الأنواع المسموحة: {", ".join(allowed_extensions)}'
        )


def create_file_validator(allowed_extensions=None):
    """
    إنشاء validator مخصص للملفات
    """
    from django.core.validators import FileExtensionValidator
    return FileExtensionValidator(allowed_extensions=allowed_extensions or ['pdf', 'doc', 'docx', 'jpg', 'jpeg', 'png', 'gif', 'txt'])


def create_image_validator():
    """
    إنشاء validator مخصص للصور
    """
    from django.core.validators import FileExtensionValidator
    return FileExtensionValidator(allowed_extensions=['jpg', 'jpeg', 'png', 'gif', 'bmp', 'webp'])


# ==================== SEQUENCE COUNTER ====================

class SequenceCounter(models.Model):
    """
    جدول لتوليد أرقام تسلسلية بأمان ومنع حالات التسابق (Race Conditions)
    يُستخدم لتوليد client_id و invoice_number وغيرها من الأرقام التسلسلية
    """
    name = models.CharField(
        max_length=50, 
        unique=True, 
        verbose_name='الاسم',
        help_text='اسم العداد (مثال: client_id, invoice_number)'
    )
    value = models.PositiveIntegerField(
        default=0, 
        verbose_name='القيمة',
        help_text='آخر قيمة مستخدمة'
    )
    updated_at = models.DateTimeField(
        auto_now=True, 
        verbose_name='آخر تحديث'
    )
    
    class Meta:
        # app_label is important when moving models to subpackages
        app_label = 'core'
        verbose_name = 'عداد تسلسلي'
        verbose_name_plural = 'عدادات تسلسلية'
        ordering = ['name']
    
    def __str__(self):
        return f'{self.name}: {self.value}'
    
    @classmethod
    @transaction.atomic
    def get_next_value(cls, name):
        counter, created = cls.objects.select_for_update().get_or_create(
            name=name,
            defaults={'value': 0}
        )
        counter.value += 1
        counter.save(update_fields=['value', 'updated_at'])
        return counter.value
    
    @classmethod
    @transaction.atomic
    def get_next_formatted(cls, name, prefix='', suffix='', year_prefix=False, digits=5):
        value = cls.get_next_value(name)
        parts = []
        if prefix: parts.append(prefix)
        if year_prefix:
            parts.append(str(timezone.now().year))
        parts.append(f'{value:0{digits}d}')
        if suffix: parts.append(suffix)
        return '-'.join(parts)


# ==================== UPLOAD PATH HELPERS ====================

def document_upload_path(instance, filename):
    case_id = getattr(instance, 'case_id', None) or (instance.case.id if instance.case else None)
    if case_id:
        return f"documents/case_{case_id}/{filename}"
    return f"documents/{filename}"


def session_attachment_upload_path(instance, filename):
    case_id = getattr(instance, 'case_id', None) or (instance.case.id if instance.case else None)
    if case_id:
        return f"documents/sessions/case_{case_id}/{filename}"
    return f"documents/sessions/{filename}"


def contract_upload_path(instance, filename):
    return f"contracts/{filename}"


def poa_upload_path(instance, filename):
    return f"poa/{filename}"


def declaration_upload_path(instance, filename):
    return f"documents/declarations/{filename}"


def expense_receipt_upload_path(instance, filename):
    return f"documents/receipts/{filename}"


def logo_upload_path(instance, filename):
    return f"logos/{filename}"


def profile_picture_upload_path(instance, filename):
    return f"logos/profiles/{filename}"


# ==================== ABSTRACT BASE MODELS ====================

class PersonBase(models.Model):
    """
    نموذج أساسي مشترك للعملاء والخصوم وأي شخص آخر في النظام
    يوحد الحقول المتكررة ويضمن ثبات الخصائص
    """
    phone = models.CharField(
        max_length=30, 
        blank=True, 
        verbose_name='الهاتف'
    )
    job = models.CharField(
        max_length=200, 
        blank=True, 
        verbose_name='الوظيفة'
    )
    address = models.TextField(
        blank=True, 
        verbose_name='العنوان'
    )
    notes = models.TextField(
        blank=True, 
        verbose_name='ملاحظات'
    )
    created_at = models.DateTimeField(
        auto_now_add=True, 
        verbose_name='تاريخ الإضافة'
    )
    updated_at = models.DateTimeField(
        auto_now=True, 
        verbose_name='تاريخ التحديث'
    )

    class Meta:
        abstract = True
        app_label = 'core'
