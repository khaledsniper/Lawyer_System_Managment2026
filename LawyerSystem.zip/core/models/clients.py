from django.db import models
from .base import SequenceCounter, PersonBase

class ClientType(models.TextChoices):
    INDIVIDUAL = 'individual', 'فرد'
    COMPANY = 'company', 'شركة'

class ClientStatus(models.TextChoices):
    ACTIVE = 'active', 'نشط'
    INACTIVE = 'inactive', 'غير نشط'

class ClientManager(models.Manager):
    def get_statistics(self):
        return self.aggregate(
            total=models.Count('id'),
            individual=models.Count('id', filter=models.Q(type='individual')),
            company=models.Count('id', filter=models.Q(type='company')),
            active=models.Count('id', filter=models.Q(status='active')),
        )

class Client(PersonBase):
    """العميل"""
    objects: ClientManager = ClientManager()
    
    # حقل الاسم يظل كما هو للتوافق مع التمبلتس والـ Views الحالية
    full_name = models.CharField(
        max_length=200,
        verbose_name='الاسم الكامل'
    )
    client_id = models.CharField(
        max_length=20,
        unique=True,
        editable=False,
        verbose_name='رقم العميل'
    )
    type = models.CharField(
        max_length=20,
        choices=ClientType.choices,
        default=ClientType.INDIVIDUAL,
        verbose_name='نوع العميل'
    )
    additional_phone = models.CharField(
        max_length=30,
        blank=True,
        verbose_name='رقم إضافي'
    )
    national_id = models.CharField(
        max_length=14,
        blank=True,
        verbose_name='الرقم القومي'
    )
    # حقول خاصة بالشركات
    commercial_register = models.CharField(
        max_length=100,
        blank=True,
        verbose_name='السجل التجاري'
    )
    tax_card = models.CharField(
        max_length=100,
        blank=True,
        verbose_name='البطاقة الضريبية'
    )
    status = models.CharField(
        max_length=20,
        choices=ClientStatus.choices,
        default=ClientStatus.ACTIVE,
        verbose_name='الحالة'
    )

    class Meta:
        app_label = 'core'
        verbose_name = 'عميل'
        verbose_name_plural = 'العملاء'
        indexes = [
            models.Index(fields=['client_id']),
            models.Index(fields=['status']),
            models.Index(fields=['national_id']),
            models.Index(fields=['type']),
        ]

    def save(self, *args, **kwargs):
        if not self.client_id:
            self.client_id = SequenceCounter.get_next_formatted(
                name='client_id',
                prefix='CLT',
                digits=5
            )
        super().save(*args, **kwargs)

    def __str__(self):
        return f"{self.client_id} - {self.full_name}"

def client_attachment_path(instance, filename):
    return f'clients/{instance.client.client_id}/attachments/{filename}'

class ClientAttachment(models.Model):
    """مرفقات العميل"""
    client = models.ForeignKey(
        Client,
        on_delete=models.CASCADE,
        related_name='attachments',
        verbose_name='العميل'
    )
    file = models.FileField(
        upload_to=client_attachment_path,
        verbose_name='الملف'
    )
    uploaded_at = models.DateTimeField(
        auto_now_add=True,
        verbose_name='تاريخ الرفع'
    )

    class Meta:
        app_label = 'core'
        verbose_name = 'مرفق عميل'
        verbose_name_plural = 'مرفقات العميل'

    def __str__(self):
        return f"مرفق - {self.client.full_name}"

class OpponentType(models.TextChoices):
    INDIVIDUAL = 'individual', 'فرد'
    COMPANY = 'company', 'شركة'
    GOVERNMENT = 'government', 'جهة حكومية'
    ENTITY = 'entity', 'جهة أخرى'

class Opponent(PersonBase):
    """الخصم"""
    name = models.CharField(
        max_length=200,
        verbose_name='الاسم'
    )
    type = models.CharField(
        max_length=20,
        choices=OpponentType.choices,
        default=OpponentType.INDIVIDUAL,
        verbose_name='نوع الخصم'
    )
    opponent_lawyer = models.CharField(
        max_length=200,
        blank=True,
        verbose_name='محامي الخصم'
    )
    business_activity = models.CharField(
        max_length=200,
        blank=True,
        verbose_name='النشاط التجاري'
    )
    is_active = models.BooleanField(
        default=True,
        verbose_name='نشط'
    )

    class Meta:
        app_label = 'core'
        verbose_name = 'خصم'
        verbose_name_plural = 'الخصوم'
        indexes = [models.Index(fields=['type'])]

    def __str__(self):
        return self.name
