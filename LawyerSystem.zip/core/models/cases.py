from django.db import models
from .clients import Client, Opponent
from .base import validate_file_size, create_file_validator, document_upload_path, session_attachment_upload_path

class CaseStatus(models.TextChoices):
    ACTIVE = 'active', 'نشطة'
    PENDING = 'pending', 'معلقة'
    WON = 'won', 'مكسوبة'
    LOST = 'lost', 'خسارة'
    CLOSED = 'closed', 'مغلقة'

class CasePriority(models.TextChoices):
    HIGH = 'high', 'عاجل'
    NORMAL = 'normal', 'عادي'
    LOW = 'low', 'منخفض'

OFFICE_POSITION_CHOICES = [
    ('plaintiff', 'مدعي'),
    ('defendant', 'مدعى عليه'),
]

CASE_TYPE_CHOICES = [
    ('مدني', 'مدني'),
    ('جنائي', 'جنائي'),
    ('تجاري', 'تجاري'),
    ('عمالي', 'عمالي'),
    ('أحوال شخصية', 'أحوال شخصية'),
    ('تنفيذ', 'تنفيذ'),
    ('أسرة', 'أسرة'),
]

class CaseManager(models.Manager):
    def get_statistics(self):
        return self.aggregate(
            total=models.Count('id'),
            active=models.Count('id', filter=models.Q(status='active')),
            pending=models.Count('id', filter=models.Q(status='pending')),
            won=models.Count('id', filter=models.Q(status='won')),
            lost=models.Count('id', filter=models.Q(status='lost')),
            closed=models.Count('id', filter=models.Q(status='closed')),
        )

class Case(models.Model):
    """القضية"""
    objects: CaseManager = CaseManager()
    case_number = models.CharField(
        max_length=50,
        unique=True,
        verbose_name='رقم القضية'
    )
    subject = models.CharField(
        max_length=500,
        verbose_name='موضوع القضية'
    )
    client = models.ForeignKey(
        Client,
        on_delete=models.CASCADE,
        related_name='cases',
        verbose_name='العميل'
    )
    opponents = models.ManyToManyField(
        Opponent,
        blank=True,
        related_name='cases',
        verbose_name='الخصوم'
    )
    court = models.ForeignKey(
        'core.Court',
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='cases',
        verbose_name='المحكمة'
    )
    case_type = models.CharField(
        max_length=100,
        choices=CASE_TYPE_CHOICES,
        blank=True,
        verbose_name='نوع القضية'
    )
    status = models.CharField(
        max_length=20,
        choices=CaseStatus.choices,
        default=CaseStatus.ACTIVE,
        verbose_name="حالة القضية"
    )
    priority = models.CharField(
        max_length=20,
        choices=CasePriority.choices,
        default=CasePriority.NORMAL,
        verbose_name="الأولوية"
    )
    position = models.CharField(
        max_length=20,
        choices=OFFICE_POSITION_CHOICES,
        blank=True,
        verbose_name="موقف المكتب"
    )
    next_session_date = models.DateField(
        null=True,
        blank=True,
        verbose_name='تاريخ الجلسة القادمة'
    )
    case_year = models.IntegerField(
        null=True,
        blank=True,
        verbose_name='سنة القضية'
    )
    notes = models.TextField(
        blank=True,
        verbose_name='ملاحظات'
    )
    created_at = models.DateTimeField(
        auto_now_add=True,
        verbose_name='تاريخ الإنشاء'
    )

    class Meta:
        app_label = 'core'
        verbose_name = 'قضية'
        verbose_name_plural = 'القضايا'
        indexes = [
            models.Index(fields=['case_number']),
            models.Index(fields=['status']),
            models.Index(fields=['next_session_date']),
            models.Index(fields=['created_at']),
        ]

    def __str__(self):
        return f"{self.case_number} - {self.subject}"

class SessionStatus(models.TextChoices):
    SCHEDULED = 'scheduled', 'مجدولة'
    COMPLETED = 'completed', 'منتهية'
    POSTPONED = 'postponed', 'مؤجلة'

class Session(models.Model):
    """جلسة قضائية"""
    case = models.ForeignKey(
        Case,
        on_delete=models.CASCADE,
        related_name='sessions',
        verbose_name='القضية'
    )
    date = models.DateField(
        verbose_name='التاريخ'
    )
    time = models.TimeField(
        null=True,
        blank=True,
        verbose_name='الوقت'
    )
    court = models.ForeignKey(
        'core.Court',
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='sessions',
        verbose_name='المحكمة'
    )
    court_legacy = models.CharField(
        max_length=200,
        blank=True,
        null=True,
        verbose_name='المحكمة (قديم)'
    )
    session_type = models.CharField(
        max_length=100,
        blank=True,
        verbose_name='نوع الجلسة',
        choices=[
            ('ordinary', 'عادية'),
            ('urgent', 'عاجلة'),
            ('initial', 'ابتدائية'),
            ('appeal', 'استئنافية'),
        ]
    )
    minutes = models.TextField(
        blank=True,
        verbose_name='محضر الجلسة'
    )
    attachments = models.FileField(
        upload_to=session_attachment_upload_path,
        blank=True,
        null=True,
        validators=[validate_file_size, create_file_validator()],
        verbose_name='مرفقات'
    )
    status = models.CharField(
        max_length=20,
        choices=SessionStatus.choices,
        default=SessionStatus.SCHEDULED,
        verbose_name='الحالة'
    )

    class Meta:
        app_label = 'core'
        verbose_name = 'جلسة'
        verbose_name_plural = 'الجلسات'
        indexes = [
            models.Index(fields=['case']),
            models.Index(fields=['date']),
            models.Index(fields=['status']),
        ]

    def __str__(self):
        return f"{self.case.case_number} - {self.date}"

class DocumentType(models.TextChoices):
    CONTRACT = 'contract', 'عقد'
    COURT_DOC = 'court_doc', 'مستند محكمة'
    EVIDENCE = 'evidence', 'دليل'
    CORRESPONDENCE = 'correspondence', 'مراسلات'
    ID = 'id', 'هوية/وثيقة'
    OTHER = 'other', 'أخرى'

class SecurityLevel(models.TextChoices):
    NORMAL = 'normal', 'عادي'
    CONFIDENTIAL = 'confidential', 'سري'

class Document(models.Model):
    """مستند مرتبط بقضية"""
    file = models.FileField(
        upload_to=document_upload_path,
        validators=[validate_file_size, create_file_validator()],
        verbose_name='الملف'
    )
    doc_type = models.CharField(
        max_length=20,
        choices=DocumentType.choices,
        default=DocumentType.OTHER,
        verbose_name='نوع المستند'
    )
    case = models.ForeignKey(
        Case,
        on_delete=models.CASCADE,
        related_name='documents',
        verbose_name='القضية'
    )
    security_level = models.CharField(
        max_length=20,
        choices=SecurityLevel.choices,
        default=SecurityLevel.NORMAL,
        verbose_name='مستوى السرية'
    )
    uploaded_at = models.DateTimeField(
        auto_now_add=True,
        verbose_name='تاريخ الرفع'
    )

    class Meta:
        app_label = 'core'
        verbose_name = 'مستند'
        verbose_name_plural = 'المستندات'
        indexes = [
            models.Index(fields=['case']),
            models.Index(fields=['doc_type']),
            models.Index(fields=['uploaded_at']),
        ]

    def __str__(self):
        return f"{self.get_doc_type_display()} - {self.case.case_number}"
