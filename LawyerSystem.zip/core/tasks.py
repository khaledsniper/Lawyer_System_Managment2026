from celery import shared_task
from django.utils import timezone
from core.models import Contract, PowerOfAttorney, Notification, User

@shared_task
def check_daily_expirations():
    """
    مهمة يومية للتحقق من العقود والتوكيلات التي قاربت على الانتهاء أو انتهت بالفعل.
    """
    today = timezone.now().date()
    
    # 1. تحديث حالة العقود المنتهية
    expired_contracts = Contract.objects.filter(
        status='active', 
        end_date__lt=today
    )
    for contract in expired_contracts:
        contract.status = 'expired'
        contract.save(update_fields=['status'])
        
    # 2. تنبيهات العقود التي ستنتهي قريباً (30 يوماً)
    expiring_soon = Contract.objects.filter(
        status='active',
        end_date__range=[today, today + timezone.timedelta(days=30)]
    )
    
    admins = User.objects.filter(role='admin', is_active=True)
    
    for contract in expiring_soon:
        days_left = (contract.end_date - today).days
        message = f"⚠️ العقد {contract.contract_number} للعميل {contract.client.full_name} سينتهي خلال {days_left} يوم."
        
        for admin in admins:
            # تجنب تكرار الإشعار في نفس اليوم
            if not Notification.objects.filter(target_user=admin, message=message, created_at__date=today).exists():
                Notification.objects.create(
                    message=message,
                    notification_type='contract',
                    target_user=admin
                )

    # 3. تحديث حالة التوكيلات (POA)
    expired_poas = PowerOfAttorney.objects.filter(
        status__in=['active', 'expiring_soon'],
        expiry_date__lt=today
    )
    for poa in expired_poas:
        poa.status = 'expired'
        poa.save(update_fields=['status'])

    return f"Processed {expired_contracts.count()} expired contracts and {expired_poas.count()} expired POAs."
