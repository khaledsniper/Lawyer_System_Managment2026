from reportlab.lib.pagesizes import A4, landscape
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import mm
from reportlab.platypus import (
    SimpleDocTemplate,
    Table,
    TableStyle,
    Paragraph,
    Spacer,
    Image,
)
from reportlab.lib import colors
from reportlab.lib.enums import TA_RIGHT, TA_CENTER
from io import BytesIO
import os
import base64
import logging
from django.conf import settings
from django.http import HttpResponse, JsonResponse
from django.utils import timezone
from core.utils import pdf_helpers

logger = logging.getLogger(__name__)


class PDFExporter:
    """خدمة موحدة لتصدير تقارير PDF بتنسيق عربي احترافي"""

    def __init__(self, request, title, orientation="portrait"):
        self.request = request
        self.title = title
        self.buffer = BytesIO()
        pagesize = A4 if orientation == "portrait" else landscape(A4)
        self.doc = SimpleDocTemplate(
            self.buffer,
            pagesize=pagesize,
            rightMargin=15 * mm,
            leftMargin=15 * mm,
            topMargin=15 * mm,
            bottomMargin=15 * mm,
        )
        self.story = []
        self.office_name, self.office_logo = pdf_helpers.get_office_info(
            settings.BASE_DIR
        )
        self.font_name = pdf_helpers.register_arabic_font(settings.BASE_DIR)
        self.styles = getSampleStyleSheet()
        self._setup_styles()

    def _setup_styles(self):
        self.title_style = ParagraphStyle(
            "Title",
            parent=self.styles["Heading1"],
            fontSize=16,
            alignment=TA_CENTER,
            fontName=self.font_name,
            spaceAfter=2 * mm,
        )
        self.normal_style = ParagraphStyle(
            "Normal",
            parent=self.styles["Normal"],
            fontSize=10,
            fontName=self.font_name,
            alignment=TA_RIGHT,
            spaceAfter=2 * mm,
        )
        self.header_style = ParagraphStyle(
            "Header",
            parent=self.normal_style,
            fontSize=9,
            textColor=colors.white,
            alignment=TA_CENTER,
        )
        self.cell_style = ParagraphStyle(
            "Cell",
            parent=self.normal_style,
            fontSize=8,
            alignment=TA_RIGHT,
            leading=10, # Line height
        )
        self.office_style = ParagraphStyle(
            "Office",
            parent=self.styles["Heading2"],
            fontSize=13,
            alignment=TA_CENTER,
            fontName=self.font_name,
            spaceAfter=1 * mm,
        )

    def add_header(self):
        if self.office_logo and os.path.exists(self.office_logo):
            try:
                img = Image(self.office_logo, width=22 * mm, height=22 * mm)
                img.hAlign = TA_CENTER
                self.story.append(img)
                self.story.append(Spacer(1, 2 * mm))
            except (FileNotFoundError, IOError, OSError) as e:
                logger.warning(
                    f"Failed to load office logo from {self.office_logo}: {e}. Using default placeholder."
                )
                # Add a placeholder text instead of image
                placeholder = Paragraph("(شعار المؤسسة)", self.normal_style)
                self.story.append(placeholder)
                self.story.append(Spacer(1, 2 * mm))
            except Exception as e:
                logger.error(f"Unexpected error loading logo: {e}")
                # Still continue without crashing
        self.story.append(
            Paragraph(pdf_helpers.format_arabic(self.office_name), self.office_style)
        )
        self.story.append(Spacer(1, 1 * mm))
        self.story.append(
            Paragraph(
                "_" * 60,
                ParagraphStyle(
                    "Line", fontSize=6, alignment=TA_CENTER, fontName=self.font_name
                ),
            )
        )
        self.story.append(Spacer(1, 2 * mm))
        self.story.append(
            Paragraph(pdf_helpers.format_arabic(self.title), self.title_style)
        )
        self.story.append(Spacer(1, 4 * mm))

    def add_title(self, title):
        """إضافة عنوان فرعي"""
        self.story.append(Paragraph(pdf_helpers.format_arabic(title), self.title_style))
        self.story.append(Spacer(1, 2 * mm))

    def add_table(self, headers, data, col_widths, theme_color="#4F46E5"):
        """إضافة جدول بيانات (توقع البيانات مرتبة من اليمين لليسار)"""
        # عكس الترتيب لجعل الجدول من اليمين لليسار (RTL)
        headers_rtl = list(reversed(headers))
        col_widths_rtl = list(reversed(col_widths)) if col_widths else col_widths
        
        # استخدام Paragraph للعناوين لتمكين التنسيق
        table_data = [[Paragraph(pdf_helpers.format_arabic(h), self.header_style) for h in headers_rtl]]
        
        for row in data:
            # عكس ترتيب البيانات في كل صف
            row_rtl = list(reversed(row))
            row_data = []
            for cell in row_rtl:
                text = str(cell) if cell else "—"
                # تنظيف النص وتنسيقه للعربية
                formatted_text = pdf_helpers.format_arabic(text)
                row_data.append(Paragraph(formatted_text, self.cell_style))
            table_data.append(row_data)
        # Normalize theme_color to a valid hex string for reportlab
        if isinstance(theme_color, str):
            if not theme_color.startswith("#"):
                theme_color = f"#{theme_color}"
        try:
            bg_color = colors.HexColor(theme_color)
        except Exception as e:
            logger.warning(
                f"Invalid theme_color '{theme_color}': {e}. Falling back to default."
            )
            bg_color = colors.HexColor("#4F46E5")

        table = Table(table_data, colWidths=col_widths_rtl)
        table.setStyle(
            TableStyle(
                [
                    ("BACKGROUND", (0, 0), (-1, 0), bg_color),
                    ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
                    ("ALIGN", (0, 0), (-1, -1), "RIGHT"),  # تغيير من CENTER إلى RIGHT للغة العربية
                    ("FONTNAME", (0, 0), (-1, -1), self.font_name),
                    ("FONTSIZE", (0, 0), (-1, 0), 9),
                    ("FONTSIZE", (0, 1), (-1, -1), 8),
                    ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
                    (
                        "ROWBACKGROUNDS",
                        (0, 1),
                        (-1, -1),
                        [colors.white, colors.Color(0.97, 0.97, 0.97)],
                    ),
                    ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
                    ("BOTTOMPADDING", (0, 0), (-1, 0), 8),
                    ("TOPPADDING", (0, 0), (-1, 0), 8),
                    ("BOTTOMPADDING", (0, 1), (-1, -1), 6),
                    ("TOPPADDING", (0, 1), (-1, -1), 6),
                    ("LEFTPADDING", (0, 0), (-1, -1), 8),
                    ("RIGHTPADDING", (0, 0), (-1, -1), 8),
                ]
            )
        )
        self.story.append(table)

    def generate_response(self, filename_prefix):
        # Footer
        self.story.append(Spacer(1, 10 * mm))
        footer_text = pdf_helpers.format_arabic(
            f"تم إنشاء التقرير في: {timezone.now().strftime('%Y-%m-%d %H:%M')}"
        )
        self.story.append(
            Paragraph(
                footer_text,
                ParagraphStyle(
                    "Footer",
                    parent=self.normal_style,
                    fontSize=8,
                    alignment=TA_CENTER,
                    textColor=colors.grey,
                ),
            )
        )

        self.doc.build(self.story)
        pdf_file = self.buffer.getvalue()
        filename = f"{filename_prefix}_{timezone.now().strftime('%Y%m%d_%H%M%S')}.pdf"

        # إغلاق المكان المؤقت في الذاكرة لمنع تسرب الذاكرة
        self.buffer.close()

        is_desktop = self.request.headers.get("X-Desktop-Mode") or self.request.GET.get(
            "desktop"
        )
        if is_desktop:
            return JsonResponse(
                {
                    "success": True,
                    "filename": filename,
                    "content": base64.b64encode(pdf_file).decode("utf-8"),
                    "content_type": "application/pdf",
                }
            )
        response = HttpResponse(pdf_file, content_type="application/pdf")
        response["Content-Disposition"] = f'attachment; filename="{filename}"'
        return response
