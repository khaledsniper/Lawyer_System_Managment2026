from datetime import date
from typing import Any

from django.db.models import Sum

from core.models import Case, Document, Expense, Fee, Payment, Session, Task


def get_case_with_related(case_id):
    return Case.objects.select_related('client').prefetch_related('opponents').get(pk=case_id)


def _get_opponents_list(case):
    if case.opponents.exists():
        return '، '.join([opp.name for opp in case.opponents.all()])
    return ''

def _display(obj: Any, method_name: str, fallback: str = '—') -> str:
    method = getattr(obj, method_name, None)
    if callable(method):
        result = method()
        if isinstance(result, str) and result:
            return result
        if result is None or result == '':
            return fallback
        return str(result)
    return fallback


def build_case_detail_context(case):
    sessions = (
        Session.objects.filter(case=case)
        .select_related('case', 'case__client')
        .order_by('-date')
    )
    documents = Document.objects.filter(case=case).order_by('-uploaded_at')
    tasks = Task.objects.filter(case=case).select_related('assigned_to').order_by('-due_date')
    fees = Fee.objects.filter(case=case).select_related('case').order_by('-id')
    expenses = Expense.objects.filter(case=case).order_by('-date')
    total_fees = fees.aggregate(total=Sum('agreed_amount'))['total'] or 0
    total_payments = Payment.objects.filter(fee__case=case).aggregate(total=Sum('amount'))['total'] or 0

    return {
        'case': case,
        'opponents_list': _get_opponents_list(case),
        'sessions': sessions,
        'documents': documents,
        'tasks': tasks,
        'fees': fees,
        'total_fees': total_fees,
        'total_payments': total_payments,
        'expenses': expenses,
        'today': date.today(),
    }


def build_case_api_payload(case):
    # تحسين: حساب الإحصائيات المالية بدقة لكل قضية
    total_fees = case.fees.aggregate(total=Sum('agreed_amount'))['total'] or 0
    total_payments = Payment.objects.filter(fee__case=case).aggregate(total=Sum('amount'))['total'] or 0
    total_expenses = case.expenses.aggregate(total=Sum('amount'))['total'] or 0
    
    net_profit = total_payments - total_expenses

    data = {
        'case_number': case.case_number,
        'case_year': case.case_year,
        'subject': case.subject,
        'status': case.status,
        'status_display': case.get_status_display(),
        'priority': case.priority,
        'priority_display': case.get_priority_display(),
        'case_type': case.case_type,
        'court': case.court.id if case.court else '',
        'court_name': case.court.name if case.court else '—',
        'client_name': case.client.full_name,
        'client_phone': case.client.phone or '—',
        'client_national_id': case.client.national_id or '—',
        'client_address': case.client.address or '—',
        'opponents': [],
        'total_fees': float(total_fees) if total_fees is not None else 0,
        'total_payments': float(total_payments) if total_payments is not None else 0,
        'total_expenses': float(total_expenses) if total_expenses is not None else 0,
        'net_profit': float(net_profit) if net_profit is not None else 0,
        'sessions': [],
        'documents': [],
        'tasks': [],
    }

    for opponent in case.opponents.all():
        data['opponents'].append({
            'name': opponent.name,
            'type': opponent.type,
            'type_display': opponent.get_type_display(),
        })

    for session in Session.objects.filter(case=case).order_by('-date')[:10]:
        data['sessions'].append({
            'date': session.date.strftime('%Y-%m-%d') if session.date else '—',
            'time': str(session.time) if session.time else '—',
            'court': session.court.name if session.court else '—',
            'session_type': session.session_type or '—',
            'status_display': _display(session, 'get_status_display'),
        })

    for doc in Document.objects.filter(case=case).order_by('-uploaded_at')[:10]:
        data['documents'].append({
            'doc_type_display': _display(doc, 'get_doc_type_display'),
            'security_level_display': _display(doc, 'get_security_level_display'),
            'uploaded_at': doc.uploaded_at.strftime('%Y-%m-%d %H:%M') if doc.uploaded_at else '—',
        })

    for task in Task.objects.filter(case=case).order_by('-due_date')[:10]:
        data['tasks'].append({
            'title': task.title or '—',
            'assigned_to': task.assigned_to.get_full_name() if task.assigned_to else '—',
            'due_date': task.due_date.strftime('%Y-%m-%d') if task.due_date else '—',
            'status_display': _display(task, 'get_status_display'),
        })

    return data
