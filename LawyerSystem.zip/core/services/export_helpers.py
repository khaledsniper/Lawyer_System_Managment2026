"""
Unified Export System - Core Framework
توحيد دوال التصدير عبر جميع النماذج
"""

from typing import List, Callable, Any, Optional
from dataclasses import dataclass, field
from django.db.models import QuerySet
from django.http import HttpResponse
import logging

from core.services.excel_export import ExcelExporter
from core.services.pdf_export import PDFExporter

logger = logging.getLogger(__name__)


# ============================================
# Configuration
# ============================================

@dataclass
class ExportConfig:
    """
    Configuration for exporting a single model.
    """

    model_name: str  # Display name (Arabic)
    queryset_fn: Callable[[Any], QuerySet]  # Function(request) -> QuerySet
    excel_headers: List[str]  # Column headers for Excel
    row_mapper: Callable[[Any, bool], List[Any]]  # (instance, is_pdf) -> row data
    pdf_headers: Optional[List[str]] = None  # Optional different order for PDF
    right_align_cols: List[int] = field(default_factory=list)  # Excel right-align columns
    pdf_col_widths: Optional[List[float]] = None  # PDF column widths in mm
    theme_color: str = "3B82F6"  # Theme color (hex without #)
    filename_prefix: str = ""  # Download filename prefix


# ============================================
# Service
# ============================================

class UnifiedExportService:
    """
    Core service handling all export operations.
    يستبدل دوال التصدير المكررة بخدمة واحدة مركزية
    """

    MAX_ROWS = 10000

    def __init__(self, request):
        self.request = request

    def export(self, config: ExportConfig, format: str = 'excel') -> HttpResponse:
        """
        Unified export entry point.

        Args:
            config: ExportConfig for the model
            format: 'excel' or 'pdf'

        Returns:
            HttpResponse with file
        """
        # Get filtered queryset
        queryset = config.queryset_fn(self.request)[:self.MAX_ROWS]

        if format == 'excel':
            return self._export_excel(config, queryset)
        elif format == 'pdf':
            return self._export_pdf(config, queryset)
        else:
            raise ValueError(f"Unsupported format: {format}")

    def _export_excel(self, config: ExportConfig, queryset: QuerySet) -> HttpResponse:
        """Export to Excel."""
        exporter = ExcelExporter(
            title=config.model_name,
            headers=config.excel_headers,
            fill_color=config.theme_color
        )
        exporter.apply_headers()

        for row_num, obj in enumerate(queryset, 2):
            data = config.row_mapper(obj, is_pdf=False)
            exporter.write_row(row_num, data, right_align_cols=config.right_align_cols)

        filename = f"{config.filename_prefix or self._slugify(config.model_name)}_{self._timestamp()}.xlsx"
        return exporter.generate_response(self.request, filename)

    def _export_pdf(self, config: ExportConfig, queryset: QuerySet) -> HttpResponse:
        """Export to PDF."""
        # Convert to list for PDF processing
        if not isinstance(queryset, list):
            queryset = list(queryset)

        exporter = PDFExporter(self.request, title=f"تقرير {config.model_name}")
        exporter.add_header()

        headers = config.pdf_headers or config.excel_headers
        data = [config.row_mapper(obj, is_pdf=True) for obj in queryset]

        col_widths = config.pdf_col_widths or self._equal_col_widths(len(headers))
        exporter.add_table(headers, data, col_widths, theme_color=config.theme_color)

        # Pass a filename prefix (without timestamp or extension) to PDFExporter
        filename_prefix = config.filename_prefix or self._slugify(config.model_name)
        return exporter.generate_response(filename_prefix)

    def _timestamp(self) -> str:
        """Generate timestamp for filename."""
        from django.utils import timezone
        return timezone.now().strftime('%Y%m%d_%H%M%S')

    def _slugify(self, text: str) -> str:
        """Simple slugify for filenames."""
        return text.replace(' ', '_').replace('،', '_')

    def _equal_col_widths(self, columns_count: int) -> List[float]:
        """Calculate equal column widths for PDF."""
        from reportlab.lib.units import mm
        equal_width = 190 / columns_count  # A4 width ~190mm
        return [equal_width * mm] * columns_count


# ============================================
# Helper Functions
# ============================================

def excel_value(value, empty=""):
    """Return value or empty for Excel."""
    return value if value is not None and value != "" else empty


def pdf_value(value, empty="—"):
    """Return value or em-dash for PDF."""
    return value if value is not None and value != "" else empty


# Note: Model-specific row mappers moved to view files to avoid circular imports
# Each view will define its own mappers matching its model
