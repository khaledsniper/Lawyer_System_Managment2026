from datetime import timedelta
from typing import cast

from django.core.cache import cache
from django.db.models import Count, Q, Sum
from django.utils import timezone

from core.models import (
    Appointment,
    Case,
    CaseManager,
    Client,
    ClientManager,
    Contract,
    Expense,
    Fee,
    FeeManager,
    Invoice,
    Task,
)


DEFAULT_STATS_CACHE_SECONDS = 60


def _cache_get_or_set(key: str, fn, timeout: int = DEFAULT_STATS_CACHE_SECONDS):
    cached = cache.get(key)
    if cached is not None:
        return cached
    value = fn()
    cache.set(key, value, timeout=timeout)
    return value


def get_cases_stats():
    return _cache_get_or_set(
        "stats:cases",
        lambda: cast(CaseManager, Case.objects).get_statistics(),
    )


def get_finance_stats():
    return _cache_get_or_set(
        "stats:finance",
        lambda: cast(FeeManager, Fee.objects).get_financial_summary(),
    )


def get_client_stats():
    return _cache_get_or_set(
        "stats:clients",
        lambda: cast(ClientManager, Client.objects).get_statistics(),
    )


def get_invoice_stats():
    def _compute():
        stats = Invoice.objects.aggregate(
            invoice_count=Count("id"),
            paid=Count("id", filter=Q(status="paid")),
            pending=Count("id", filter=Q(status="pending")),
            cancelled=Count("id", filter=Q(status="cancelled")),
            total_paid_amount=Sum("total", filter=Q(status="paid")),
            total_pending_amount=Sum("total", filter=Q(status="pending")),
        )
        # Avoid alias conflict with model field name 'total'.
        stats["total"] = stats.get("invoice_count", 0)
        stats["total_invoices"] = stats["total"]
        return stats

    return _cache_get_or_set("stats:invoices", _compute)


def get_task_stats():
    today = timezone.now().date()
    cache_key = f"stats:tasks:{today.isoformat()}"

    return _cache_get_or_set(
        cache_key,
        lambda: Task.objects.aggregate(
            total=Count("id"),
            new=Count("id", filter=Q(status="new")),
            in_progress=Count("id", filter=Q(status="in_progress")),
            done=Count("id", filter=Q(status="done")),
            overdue=Count(
                "id",
                filter=Q(status__in=["new", "in_progress"], due_date__lt=today),
            ),
        ),
    )


def get_appointment_stats():
    now = timezone.now()
    bucket = now.strftime("%Y%m%d%H%M")
    cache_key = f"stats:appointments:{bucket}"

    return _cache_get_or_set(
        cache_key,
        lambda: Appointment.objects.aggregate(
            total=Count("id"),
            completed=Count("id", filter=Q(status="completed")),
            upcoming=Count("id", filter=Q(datetime__gt=now, status="scheduled")),
        ),
    )


def get_contract_stats():
    expiring_by = timezone.now().date() + timedelta(days=30)
    cache_key = f"stats:contracts:{expiring_by.isoformat()}"

    return _cache_get_or_set(
        cache_key,
        lambda: Contract.objects.aggregate(
            total_invoices=Count("id"),
            total=Count("id"),
            active=Count("id", filter=Q(status="active")),
            expiring=Count("id", filter=Q(status="active", end_date__lte=expiring_by)),
        ),
    )


def get_reports_stats():
    now = timezone.now()
    cache_key = f"stats:reports:{now.strftime('%Y%m%d%H%M')}"

    def _compute():
        return {
            "case_stats": get_cases_stats(),
            "client_stats": get_client_stats(),
            "finance_stats": get_finance_stats(),
            "invoice_stats": get_invoice_stats(),
            "task_stats": get_task_stats(),
            "appointment_stats": get_appointment_stats(),
            "contract_stats": get_contract_stats(),
            "cases_by_type": list(
                Case.objects.values("case_type")
                .annotate(count=Count("id"))
                .order_by("-count")[:5]
            ),
            "expenses_by_category": list(
                Expense.objects.values("category")
                .annotate(total=Sum("amount"))
                .order_by("-total")[:5]
            ),
        }

    return _cache_get_or_set(cache_key, _compute, timeout=DEFAULT_STATS_CACHE_SECONDS)
