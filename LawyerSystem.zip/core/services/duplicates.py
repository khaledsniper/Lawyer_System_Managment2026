from core.models import Case, Client


def check_case_duplicate(case_number, client_id, pk=None):
    result = {'duplicate': False, 'info': False, 'message': ''}

    if case_number:
        qs = Case.objects.filter(case_number=case_number)
        if pk:
            qs = qs.exclude(pk=pk)
        existing = qs.first()
        if existing is not None:
            result['duplicate'] = True
            result['field'] = 'case_number'
            result['message'] = f'⚠️ رقم القضية "{case_number}" مستخدم بالفعل للعميل: {existing.client.full_name}'
            return result

    if client_id:
        try:
            client = Client.objects.get(pk=client_id)
            existing_cases = Case.objects.filter(client=client)
            if pk:
                existing_cases = existing_cases.exclude(pk=pk)
            if existing_cases.exists():
                count = existing_cases.count()
                result['info'] = True
                result['client_cases_count'] = count
                result['message'] = f'ℹ️ هذا العميل لديه {count} قضية مسجلة بالفعل'
        except Client.DoesNotExist:
            pass

    return result


def check_client_duplicate(full_name, phone, national_id, pk=None):
    result = {'duplicate': False, 'message': ''}

    if full_name:
        qs = Client.objects.filter(full_name__iexact=full_name)
        if pk:
            qs = qs.exclude(pk=pk)
        existing = qs.first()
        if existing is not None:
            result['duplicate'] = True
            result['field'] = 'full_name'
            result['message'] = (
                f'⚠️ يوجد عميل بنفس الاسم: {existing.full_name} '
                f'(الهاتف: {existing.phone or "غير محدد"})'
            )
            return result

    if phone:
        qs = Client.objects.filter(phone=phone)
        if pk:
            qs = qs.exclude(pk=pk)
        existing = qs.first()
        if existing is not None:
            result['duplicate'] = True
            result['field'] = 'phone'
            result['message'] = f'⚠️ رقم الهاتف مسجل بالفعل للعميل: {existing.full_name}'
            return result

    if national_id:
        qs = Client.objects.filter(national_id=national_id)
        if pk:
            qs = qs.exclude(pk=pk)
        existing = qs.first()
        if existing is not None:
            result['duplicate'] = True
            result['field'] = 'national_id'
            result['message'] = f'⚠️ الرقم القومي مسجل بالفعل للعميل: {existing.full_name}'
            return result

    return result
