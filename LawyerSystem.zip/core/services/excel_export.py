import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment
from openpyxl.utils import get_column_letter
import io
import base64
from django.http import HttpResponse, JsonResponse
from django.utils import timezone

class ExcelExporter:
    """خدمة موحدة لتصدير ملفات Excel بنظام RTL ومحاذاة عربية"""
    
    def __init__(self, title, headers, fill_color="4F46E5"):
        self.wb = openpyxl.Workbook()
        self.ws = self.wb.active
        self.ws.title = title
        self.ws.sheet_view.rightToLeft = True
        self.headers = headers
        
        # تنسيقات افتراضية
        self.header_font = Font(bold=True, color="FFFFFF")
        self.header_fill = PatternFill(start_color=fill_color, end_color=fill_color, fill_type="solid")
        self.center_alignment = Alignment(horizontal="center", vertical="center", readingOrder=2)
        self.right_alignment = Alignment(horizontal="right", vertical="center", readingOrder=2)

    def add_sheet(self, title, headers, fill_color="4F46E5"):
        """إضافة ورقة عمل جديدة وتعيينها كنشطة"""
        self.ws = self.wb.create_sheet(title)
        self.ws.sheet_view.rightToLeft = True
        self.headers = headers
        self.header_fill = PatternFill(start_color=fill_color, end_color=fill_color, fill_type="solid")
        self.apply_headers()
        return self.ws

    def apply_headers(self):
        for col_num, header in enumerate(self.headers, 1):
            cell = self.ws.cell(row=1, column=col_num)
            cell.value = header
            cell.font = self.header_font
            cell.fill = self.header_fill
            cell.alignment = self.center_alignment
            self.ws.column_dimensions[get_column_letter(col_num)].width = 20

    def write_row(self, row_num, data, right_align_cols=None):
        """كتابة صف مع تحديد الأعمدة التي تحتاج محاذاة لليمين (مثل الأرقام)"""
        for col_num, value in enumerate(data, 1):
            cell = self.ws.cell(row=row_num, column=col_num)
            cell.value = value
            
            if right_align_cols and col_num in right_align_cols:
                cell.alignment = self.right_alignment
            else:
                cell.alignment = self.center_alignment

    def generate_response(self, request, filename_prefix):
        buffer = io.BytesIO()
        self.wb.save(buffer)
        buffer.seek(0)
        
        timestamp = timezone.now().strftime("%Y%m%d_%H%M%S")
        filename = f"{filename_prefix}_{timestamp}.xlsx"
        
        is_desktop = request.headers.get("X-Desktop-Mode") or request.GET.get("desktop")
        
        if is_desktop:
            content_base64 = base64.b64encode(buffer.getvalue()).decode("utf-8")
            return JsonResponse({
                "success": True,
                "filename": filename,
                "content": content_base64,
                "content_type": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            })
            
        response = HttpResponse(
            buffer.getvalue(),
            content_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        )
        response["Content-Disposition"] = f"attachment; filename={filename}"
        return response