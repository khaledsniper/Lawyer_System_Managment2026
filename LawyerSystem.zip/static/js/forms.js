/**
 * Mizan Al-Adala - Forms JavaScript
 * Handle form submissions, AJAX, and validation
 */

document.addEventListener('DOMContentLoaded', function() {
    initAJAXForms();
    initFormValidation();
    initDynamicFormsets();
    initFileUploads();
    initDatePickers();
});

/**
 * Initialize AJAX form submissions
 */
function initAJAXForms() {
    document.querySelectorAll('form[data-ajax="true"]').forEach(function(form) {
        form.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const formData = new FormData(form);
            const submitBtn = form.querySelector('button[type="submit"]');
            const originalText = submitBtn ? submitBtn.innerHTML : '';
            const successUrl = form.getAttribute('data-success-url');
            const modalId = form.closest('.modal')?.id;
            
            // Show loading state
            if (submitBtn) {
                submitBtn.disabled = true;
                submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> جاري الحفظ...';
            }
            
            fetch(form.action, {
                method: 'POST',
                body: formData,
                headers: {
                    'X-Requested-With': 'XMLHttpRequest'
                }
            })
            .then(response => response.json())
            .then(data => {
                if (data.status === 'success') {
                    // Show success message
                    if (data.message) {
                        showMessage('success', data.message);
                    }
                    
                    // Close modal if exists
                    if (modalId) {
                        const modal = bootstrap.Modal.getInstance(document.getElementById(modalId));
                        if (modal) modal.hide();
                    }
                    
                    // Redirect or reload
                    if (successUrl) {
                        window.location.href = successUrl;
                    } else if (data.redirect) {
                        window.location.href = data.redirect;
                    } else {
                        window.location.reload();
                    }
                } else if (data.status === 'error') {
                    // Show errors
                    let errorMsg = '⚠️ يرجى تصحيح الأخطاء:\n';
                    for (let field in data.errors) {
                        data.errors[field].forEach(err => {
                            errorMsg += `• ${field}: ${err}\n`;
                        });
                    }
                    alert(errorMsg);
                    
                    // Re-enable submit button
                    if (submitBtn) {
                        submitBtn.disabled = false;
                        submitBtn.innerHTML = originalText;
                    }
                } else {
                    alert('❌ حدث خطأ غير متوقع. يرجى المحاولة مرة أخرى.');
                    if (submitBtn) {
                        submitBtn.disabled = false;
                        submitBtn.innerHTML = originalText;
                    }
                }
            })
            .catch(err => {
                console.error('Error:', err);
                alert('❌ حدث خطأ غير متوقع. يرجى المحاولة مرة أخرى.');
                if (submitBtn) {
                    submitBtn.disabled = false;
                    submitBtn.innerHTML = originalText;
                }
            });
        });
    });
}

/**
 * Initialize form validation
 */
function initFormValidation() {
    // National ID validation (14 digits)
    document.querySelectorAll('input[name="national_id"]').forEach(function(input) {
        input.addEventListener('blur', function() {
            const value = this.value.replace(/\D/g, '');
            if (value && value.length !== 14) {
                showError(this, 'الرقم القومي يجب أن يكون 14 رقماً');
            } else {
                clearError(this);
            }
        });
    });
    
    // Phone number validation
    document.querySelectorAll('input[name="phone"], input[name="additional_phone"]').forEach(function(input) {
        input.addEventListener('blur', function() {
            const value = this.value;
            if (value && !/^[\d\s\+\-()]+$/.test(value)) {
                showError(this, 'رقم الهاتف غير صحيح');
            } else {
                clearError(this);
            }
        });
    });
    

    // Required fields
    document.querySelectorAll('input[required], select[required], textarea[required]').forEach(function(input) {
        input.addEventListener('blur', function() {
            if (!this.value) {
                showError(this, 'هذا الحقل مطلوب');
            } else {
                clearError(this);
            }
        });
    });
}

/**
 * Show error message for form field
 */
function showError(field, message) {
    field.classList.add('is-invalid');
    
    let feedback = field.parentElement.querySelector('.invalid-feedback');
    if (!feedback) {
        feedback = document.createElement('div');
        feedback.className = 'invalid-feedback';
        field.parentElement.appendChild(feedback);
    }
    
    feedback.textContent = message;
}

/**
 * Clear error message for form field
 */
function clearError(field) {
    field.classList.remove('is-invalid');
    
    const feedback = field.parentElement.querySelector('.invalid-feedback');
    if (feedback) {
        feedback.remove();
    }
}

/**
 * Initialize dynamic formsets (for attachments, etc.)
 */
function initDynamicFormsets() {
    // Add attachment button
    const addAttachmentBtn = document.getElementById('add-attachment');
    if (addAttachmentBtn) {
        addAttachmentBtn.addEventListener('click', function() {
            const container = document.getElementById('attachments-container');
            if (!container) return;
            
            const currentCount = container.querySelectorAll('.attachment-row').length;
            if (currentCount >= 5) {
                alert('الحد الأقصى هو 5 ملفات');
                return;
            }
            
            const newRow = document.createElement('div');
            newRow.className = 'attachment-row mb-2';
            newRow.innerHTML = `
                <div class="d-flex align-items-center gap-2">
                    <div class="attachment-wrapper flex-grow-1 mb-0">
                        <button type="button" class="browse-btn" onclick="this.nextElementSibling.nextElementSibling.click()">تصفّح...</button>
                        <span class="file-status text-truncate">لم تُحدد أي ملّفات.</span>
                        <input type="file" name="attachments" class="d-none" onchange="updateFileStatus(this)">
                    </div>
                    <button type="button" class="trash-btn remove-attachment" title="حذف">
                        <i class="fas fa-trash-alt"></i>
                    </button>
                </div>
            `;
            
            container.appendChild(newRow);
            
            // Add remove functionality
            newRow.querySelector('.remove-attachment').addEventListener('click', function() {
                newRow.remove();
            });
        });
    }
}

/**
 * Update file status display
 */
function updateFileStatus(input) {
    const wrapper = input.closest('.attachment-wrapper');
    if (!wrapper) return;
    
    const statusSpan = wrapper.querySelector('.file-status');
    if (input.files.length > 0) {
        statusSpan.textContent = input.files[0].name;
        statusSpan.classList.add('text-primary', 'fw-bold');
    } else {
        statusSpan.textContent = 'لم تُحدد أي ملّفات.';
        statusSpan.classList.remove('text-primary', 'fw-bold');
    }
}

// Make it global for inline onclick handlers
window.updateFileStatus = updateFileStatus;

/**
 * Initialize file uploads with preview
 */
function initFileUploads() {
    document.querySelectorAll('input[type="file"][data-preview]').forEach(function(input) {
        input.addEventListener('change', function() {
            const file = this.files[0];
            const previewId = this.getAttribute('data-preview');
            const preview = document.getElementById(previewId);
            
            if (file && preview) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    preview.src = e.target.result;
                    preview.style.display = 'block';
                };
                reader.readAsDataURL(file);
            }
        });
    });
}

/**
 * Initialize date pickers
 */
function initDatePickers(root=document) {
    // Initialize flatpickr for inputs marked with data-datepicker="true" within optional root
    const scope = root || document;
    const dateEls = Array.from(scope.querySelectorAll('input[data-datepicker="true"]'));
    if (dateEls.length === 0) return;

    function bindEscape(modal) {
        if (!modal || modal.dataset.genericDatepickerEscapeBound === 'true') return;

        modal.dataset.genericDatepickerEscapeBound = 'true';
        modal.addEventListener('keydown', function(event) {
            if (event.key !== 'Escape') return;

            modal.querySelectorAll('input[data-datepicker="true"]').forEach(function(input) {
                if (input._flatpickr) {
                    input._flatpickr.close();
                }
            });
        }, true);
    }

    function attachToElements() {
        dateEls.forEach(function(input) {
            if (input._flatpickr) return; // already attached
            try {
                bindEscape(input.closest('.modal'));
                flatpickr(input, {
                    dateFormat: 'd/m/Y',
                    allowInput: false, // منع الكتابة اليدوية كما طلب المستخدم
                    defaultDate: input.value || null,
                    minDate: input.hasAttribute('data-no-past') ? 'today' : null,
                    static: true,
                    monthSelectorType: 'dropdown', // تظهر الشهور كقائمة منسدلة
                    yearSelectorType: 'dropdown',  // تظهر السنوات كقائمة منسدلة
                    locale: 'ar',                  // التأكد من اللغة العربية
                });
            } catch (e) {
                console.warn('flatpickr attach failed:', e);
            }
        });
    }

    if (typeof flatpickr === 'undefined') {
        // load flatpickr dynamically then attach
        const css = document.createElement('link');
        css.rel = 'stylesheet';
        css.href = 'https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css';
        document.head.appendChild(css);

        const script = document.createElement('script');
        script.src = 'https://cdn.jsdelivr.net/npm/flatpickr';
        script.onload = () => {
            // تحميل ملف اللغة العربية بعد تحميل المكتبة الرئيسية
            const localeScript = document.createElement('script');
            localeScript.src = 'https://cdn.jsdelivr.net/npm/flatpickr/dist/l10n/ar.js';
            localeScript.onload = attachToElements;
            document.body.appendChild(localeScript);
        };
        document.body.appendChild(script);
    } else {
        attachToElements();
    }

    // إضافة دعم لمختار الوقت أيضاً
    function attachTimePickers() {
        const timeEls = Array.from(scope.querySelectorAll('input[data-timepicker="true"]'));
        timeEls.forEach(function(input) {
            if (input._flatpickr) return;
            flatpickr(input, {
                enableTime: true,
                noCalendar: true,
                dateFormat: "H:i",
                time_24hr: true,
                static: true,
                locale: 'ar'
            });
        });
    }
    
    if (typeof flatpickr !== 'undefined') {
        attachTimePickers();
    }
}

// تهيئة تلقائية عند فتح أي نافذة Modal
document.addEventListener('shown.bs.modal', function (event) {
    if (typeof window.initDatePickers === 'function') {
        window.initDatePickers(event.target);
    }
});

/**
 * Show message (success/error)
 */
function showMessage(type, message) {
    const alertClass = type === 'success' ? 'alert-success' : 'alert-danger';
    const icon = type === 'success' ? 'fa-check-circle' : 'fa-exclamation-circle';
    
    const alertHtml = `
        <div class="alert ${alertClass} alert-dismissible fade show" role="alert">
            <i class="fas ${icon}"></i> ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    `;
    
    const mainContent = document.querySelector('.main-content');
    if (mainContent) {
        const alertDiv = document.createElement('div');
        alertDiv.innerHTML = alertHtml;
        mainContent.insertBefore(alertDiv, mainContent.firstChild);
        
        // Auto-dismiss after 5 seconds
        setTimeout(function() {
            alertDiv.remove();
        }, 5000);
    }
}

/**
 * Load form via AJAX (for edit modals)
 */
function loadFormModal(url, modalId) {
    fetch(url, {
        headers: {
            'X-Requested-With': 'XMLHttpRequest'
        }
    })
    .then(response => response.json())
    .then(data => {
        const modal = document.getElementById(modalId);
        if (modal && data.html) {
            const contentDiv = modal.querySelector('.modal-body') || modal.querySelector('#editModalContent');
            if (contentDiv) {
                contentDiv.innerHTML = data.html;
                
                // Re-initialize form handlers
                initFormValidation();
                initFileUploads();
                initDatePickers(contentDiv);
                
                // Show modal
                const bsModal = new bootstrap.Modal(modal);
                bsModal.show();
            }
        }
    })
    .catch(err => {
        console.error('Error loading form:', err);
        alert('❌ فشل تحميل نموذج التعديل');
    });
}

// Make it global
window.loadFormModal = loadFormModal;
window.initDatePickers = initDatePickers;
