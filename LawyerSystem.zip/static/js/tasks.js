/**
 * Mizan Al-Adala - Tasks Management JavaScript
 * Handles AJAX modals and updates for Tasks
 */

document.addEventListener('DOMContentLoaded', function () {
    initTaskModals();
});

function initTaskModals() {
    // 1. Add Task (Standard Modal in Template)
    const addTaskForm = document.getElementById('addTaskForm');
    if (addTaskForm) {
        addTaskForm.addEventListener('submit', function (e) {
            e.preventDefault();
            submitTaskForm(this, 'addTaskModal');
        });
    }

    // 2. Edit Task Modal
    document.addEventListener('click', function (e) {
        const editBtn = e.target.closest('.btn-edit-task');
        if (!editBtn) return;

        e.preventDefault();
        const url = editBtn.dataset.url || editBtn.href;
        const modalEl = document.getElementById('taskModal');
        const contentArea = document.getElementById('taskModalContent');

        if (modalEl && contentArea) {
            contentArea.innerHTML = '<div class="text-center py-5"><div class="spinner-border text-primary" role="status"></div><p class="mt-2">جاري التحميل...</p></div>';
            const modal = bootstrap.Modal.getOrCreateInstance(modalEl);
            modal.show();

            fetch(url, { headers: { 'X-Requested-With': 'XMLHttpRequest' } })
                .then(res => res.json())
                .then(data => {
                    if (data.html) {
                        contentArea.innerHTML = data.html;
                        const form = modalEl.querySelector('form');
                        if (form) {
                            form.addEventListener('submit', function (ev) {
                                ev.preventDefault();
                                submitTaskForm(this, 'taskModal');
                            });
                        }
                    } else {
                        contentArea.innerHTML = '<div class="alert alert-danger">❌ فشل تحميل المحتوى</div>';
                    }
                })
                .catch(err => {
                    console.error('Fetch error:', err);
                    contentArea.innerHTML = '<div class="alert alert-danger">❌ فشل تحميل البيانات.</div>';
                });
        }
    });

    // 3. Delete Task Confirmation
    document.addEventListener('click', function (e) {
        const deleteBtn = e.target.closest('.btn-delete-task');
        if (deleteBtn) {
            const url = deleteBtn.getAttribute('data-url');
            const title = deleteBtn.getAttribute('data-title');

            const modalEl = document.getElementById('deleteTaskModal');
            const infoArea = document.getElementById('deleteTaskTitle');
            const form = document.getElementById('deleteTaskForm');

            if (modalEl && infoArea && form) {
                infoArea.textContent = title;
                form.setAttribute('action', url);
                bootstrap.Modal.getOrCreateInstance(modalEl).show();
            }
        }
    });

    // 4. Delete Task Submission
    const deleteTaskForm = document.getElementById('deleteTaskForm');
    if (deleteTaskForm) {
        deleteTaskForm.addEventListener('submit', function (e) {
            e.preventDefault();
            const url = this.getAttribute('action');
            const formData = new FormData(this);

            fetch(url, {
                method: 'POST',
                body: formData,
                headers: { 'X-Requested-With': 'XMLHttpRequest' }
            })
                .then(res => res.json())
                .then(data => {
                    if (data.status === 'success') {
                        bootstrap.Modal.getInstance(document.getElementById('deleteTaskModal')).hide();
                        window.location.reload();
                    } else {
                        alert('❌ فشل الحذف');
                    }
                });
        });
    }
}

function submitTaskForm(form, modalId) {
    const submitBtn = form.querySelector('button[type="submit"]');
    const originalText = submitBtn.innerHTML;

    submitBtn.disabled = true;
    submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin me-1"></i> جاري الحفظ...';

    const formData = new FormData(form);

    fetch(form.getAttribute('action') || window.location.href, {
        method: 'POST',
        body: formData,
        headers: { 'X-Requested-With': 'XMLHttpRequest' }
    })
        .then(res => res.json())
        .then(data => {
            if (data.status === 'success') {
                bootstrap.Modal.getInstance(document.getElementById(modalId)).hide();
                window.location.reload();
            } else if (data.errors) {
                // Handle form errors (simple alert for now or find error container)
                alert('❌ يرجى تصحيح الأخطاء في النموذج');
                console.log(data.errors);
            } else {
                alert('❌ حدث خطأ أثناء الحفظ');
            }
        })
        .catch(err => {
            console.error('Submit error:', err);
            alert('❌ حدث خطأ في الاتصال');
        })
        .finally(() => {
            submitBtn.disabled = false;
            submitBtn.innerHTML = originalText;
        });
}
