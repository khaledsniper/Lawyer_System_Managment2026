/**
 * Mizan Al-Adala - Main JavaScript
 * Common functionality for all pages
 */

function initializeApp() {
    // Config HTMX before initialization
    if (typeof htmx !== 'undefined') {
        htmx.config.boostTransition = true;
    }

    initTheme(); // Re-initialize theme logic
    initTooltips();
    initSidebarToggle();
    initAlerts();
    initConfirmationModals();
    initDesktopMinimize(); // Initialize desktop minimize button
    initClientDetailModal();
    initOpponentDetailModal();
    initGenericDetailModals();
    initDynamicDetailModals();
    initHtmxFormErrors(); // Handle server-side errors for HTMX forms
    if (typeof initSelectAll === 'function') initSelectAll();
    updateSidebarActive();
}

function updateSidebarActive() {
    const currentPath = window.location.pathname;
    document.querySelectorAll('.sidebar-nav .nav-link').forEach(link => {
        const hRef = link.getAttribute('href');
        // Simple path matching
        if (hRef && (hRef === currentPath || (currentPath.startsWith(hRef) && hRef !== '/'))) {
            link.classList.add('active');
            // If it's a submenu item, open the parent collapse
            const parentCollapseID = link.closest('.collapse')?.id;
            if (parentCollapseID) {
                const trigger = document.querySelector(`[href="#${parentCollapseID}"]`);
                if (trigger) trigger.classList.add('active');
                const collapseEl = document.getElementById(parentCollapseID);
                if (collapseEl && !collapseEl.classList.contains('show')) {
                    new bootstrap.Collapse(collapseEl, { toggle: true });
                }
            }
        } else {
            link.classList.remove('active');
        }
    });
}

/**
 * Global handler for HTMX form validation errors.
 */
function initHtmxFormErrors() {
    document.body.addEventListener('htmx:afterRequest', function(evt) {
        const form = evt.detail.elt; // The element that triggered the request (e.g., the form)
        if (!form) return;

        // On successful requests, clear any validation-related styles and messages
        if (!evt.detail.failed) {
            form.querySelectorAll('.is-invalid').forEach(el => el.classList.remove('is-invalid'));
            const successErrorContainer = form.querySelector('#form-submission-errors');
            if (successErrorContainer) {
                successErrorContainer.innerHTML = '';
            }
            return;
        }

        // Handle failed requests, specifically for form validation (status 400)
        if (evt.detail.failed && evt.detail.xhr.status === 400) {
            try {
                const response = JSON.parse(evt.detail.xhr.responseText);
                if (response.errors) {
                    const errorContainer = form.querySelector('#form-submission-errors');
                    if (!errorContainer) {
                         console.error("Form errors found, but no '#form-submission-errors' container to display them in.", response.errors);
                         return;
                    }

                    // Clear previous errors and remove old invalid states
                    errorContainer.innerHTML = '';
                    form.querySelectorAll('.is-invalid').forEach(el => el.classList.remove('is-invalid'));

                    // Display new errors
                    for (const [field, messages] of Object.entries(response.errors)) {
                        // Display non-field errors or general errors at the top
                        const isNonField = field === '__all__';
                        
                        messages.forEach(message => {
                            const alertDiv = document.createElement('div');
                            alertDiv.className = 'alert alert-danger d-flex align-items-center p-2 mb-2';
                            alertDiv.setAttribute('role', 'alert');
                            let fieldName = isNonField ? 'خطأ عام' : `حقل (${field})`;
                            alertDiv.innerHTML = `
                                <i class="fas fa-exclamation-triangle me-2"></i>
                                <div class="fs-sm">
                                    <strong>${fieldName}:</strong> ${message}
                                </div>
                            `;
                            errorContainer.appendChild(alertDiv);
                        });

                        // Highlight the specific field that has the error
                        if (!isNonField) {
                            const fieldElement = form.querySelector(`[name="${field}"]`);
                            if (fieldElement) {
                                fieldElement.classList.add('is-invalid');
                            }
                        }
                    }
                    // Scroll to the first error
                    if(errorContainer.firstChild) {
                        errorContainer.firstChild.scrollIntoView({ behavior: 'smooth', block: 'center' });
                    }
                }
            } catch (e) {
                console.error("Failed to parse form error response:", e);
                const errorContainer = form.querySelector('#form-submission-errors');
                if(errorContainer){
                    errorContainer.innerHTML = '<div class="alert alert-danger">حدث خطأ غير متوقع أثناء معالجة النموذج.</div>';
                }
            }
        }
    });
}

document.addEventListener('DOMContentLoaded', initializeApp);
document.addEventListener('htmx:afterOnLoad', function(evt) {
    initializeApp();
    if (window.innerWidth < 992) {
        const sidebar = document.getElementById('sidebar');
        const overlay = document.getElementById('sidebarOverlay');
        if (sidebar) sidebar.classList.remove('show');
        if (overlay) overlay.classList.remove('show');
    }
});

/**
 * Initialize Bootstrap tooltips
 */
function initTooltips() {
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
}

/**
 * Sidebar toggle for mobile
 */
function initSidebarToggle() {
    const sidebarToggle = document.getElementById('sidebarToggle');
    const sidebar = document.getElementById('sidebar');
    const sidebarOverlay = document.getElementById('sidebarOverlay');
    const sidebarClose = document.getElementById('sidebarClose');
    
    if (sidebarToggle) {
        sidebarToggle.addEventListener('click', function() {
            sidebar.classList.add('show');
            sidebarOverlay.classList.add('show');
            document.body.style.overflow = 'hidden';
        });
    }
    
    if (sidebarClose) {
        sidebarClose.addEventListener('click', closeSidebar);
    }
    
    if (sidebarOverlay) {
        sidebarOverlay.addEventListener('click', closeSidebar);
    }
    
    function closeSidebar() {
        sidebar.classList.remove('show');
        sidebarOverlay.classList.remove('show');
        document.body.style.overflow = '';
    }
}

/**
 * Auto-dismiss alerts after 5 seconds
 */
function initAlerts() {
    const alerts = document.querySelectorAll('.alert:not(.alert-permanent)');
    
    alerts.forEach(function(alert) {
        setTimeout(function() {
            const bsAlert = new bootstrap.Alert(alert);
            bsAlert.close();
        }, 5000);
    });
}

/**
 * Initialize confirmation modals for delete actions
 */
function initConfirmationModals() {
    // Generic delete confirmation
    document.querySelectorAll('[data-confirm-delete]').forEach(function(button) {
        button.addEventListener('click', function(e) {
            e.preventDefault();

            const message = this.getAttribute('data-confirm-message') || 'هل أنت متأكد من الحذف؟';
            const url = this.getAttribute('href') || this.getAttribute('data-url');

            if (confirm(message)) {
                // Create and submit form
                const form = document.createElement('form');
                form.method = 'POST';
                form.action = url;

                const csrfToken = document.querySelector('[name=csrfmiddlewaretoken]');
                if (csrfToken) {
                    const hiddenCsrf = document.createElement('input');
                    hiddenCsrf.type = 'hidden';
                    hiddenCsrf.name = 'csrfmiddlewaretoken';
                    hiddenCsrf.value = csrfToken.value;
                    form.appendChild(hiddenCsrf);
                }

                document.body.appendChild(form);
                form.submit();
            }
        });
    });
}

/**
 * Initialize desktop minimize button (pywebview)
 */
function initDesktopMinimize() {
    const minimizeBtn = document.getElementById('topMinimizeAppBtn');
    if (!minimizeBtn) return;

    // Don't hide the button - let it be visible and handle click gracefully
    minimizeBtn.addEventListener('click', function(e) {
        e.preventDefault();
        try {
            // Check if we're in desktop mode
            if (typeof pywebview !== 'undefined' && pywebview && pywebview.api) {
                if (typeof pywebview.api.minimizeWindow === 'function') {
                    pywebview.api.minimizeWindow();
                } else {
                    console.warn('minimizeWindow API not available');
                }
            }
        } catch (error) {
            console.error('Failed to minimize window:', error);
        }
    });
}

/**
 * Open client detail in modal via AJAX
 */
function initClientDetailModal() {
    document.addEventListener('click', function (e) {
        const trigger = e.target.closest('[data-client-detail-url]');
        if (!trigger) return;

        e.preventDefault();
        const url = trigger.getAttribute('data-client-detail-url');
        if (!url) return;

        fetch(url, {
            headers: {
                'X-Requested-With': 'XMLHttpRequest'
            }
        })
        .then(resp => resp.json())
        .then(data => {
            const modalDiv = document.createElement('div');
            modalDiv.innerHTML = data.html;
            document.body.appendChild(modalDiv);

            const modalEl = modalDiv.querySelector('.modal');
            if (modalEl) {
                const modal = new bootstrap.Modal(modalEl);
                modal.show();
                
                // Ensure Escape key works for dynamic modals
                modalEl.addEventListener('keydown', (ev) => {
                    if (ev.key === 'Escape') {
                        ev.stopPropagation();
                        modal.hide();
                    }
                });
                modalEl.addEventListener('shown.bs.modal', () => modalEl.focus());
                modalEl.addEventListener('hidden.bs.modal', () => modalDiv.remove());

                attachClientPrint(modalEl, data.client_id);
            }
        })
        .catch(err => {
            console.error('Error loading client detail:', err);
            alert('❌ فشل تحميل تفاصيل العميل');
        });
    });
}

/**
 * Open opponent detail in modal via AJAX
 */
function initOpponentDetailModal() {
    document.addEventListener('click', function (e) {
        const trigger = e.target.closest('[data-opponent-detail-url]');
        if (!trigger) return;

        e.preventDefault();
        const url = trigger.getAttribute('data-opponent-detail-url');
        if (!url) return;

        fetch(url, {
            headers: {
                'X-Requested-With': 'XMLHttpRequest'
            }
        })
        .then(resp => resp.json())
        .then(data => {
            const modalDiv = document.createElement('div');
            modalDiv.innerHTML = data.html;
            document.body.appendChild(modalDiv);

            const modalEl = modalDiv.querySelector('.modal');
            if (modalEl) {
                const modal = new bootstrap.Modal(modalEl);
                modal.show();
                
                // Ensure Escape key works for dynamic modals
                modalEl.addEventListener('keydown', (ev) => {
                    if (ev.key === 'Escape') {
                        ev.stopPropagation();
                        modal.hide();
                    }
                });
                modalEl.addEventListener('shown.bs.modal', () => modalEl.focus());
                modalEl.addEventListener('hidden.bs.modal', () => modalDiv.remove());
            }
        })
        .catch(err => {
            console.error('Error loading opponent detail:', err);
            alert('❌ فشل تحميل تفاصيل الخصم');
        });
    });
}

/**
 * Generic handler to open any detail in a modal via AJAX
 * Requirements:
 * - Trigger element has: data-detail-modal="true"
 * - Trigger element has: data-url="/api/path/to/detail/"
 * - Trigger element has: data-modal-id="targetModalId"
 */
function initGenericDetailModals() {
    document.addEventListener('click', function (e) {
        const trigger = e.target.closest('[data-detail-modal="true"]');
        if (!trigger) return;

        e.preventDefault();
        const url = trigger.getAttribute('data-url');
        const modalId = trigger.getAttribute('data-modal-id');
        if (!url || !modalId) return;

        const modalEl = document.getElementById(modalId);
        const contentEl = modalEl ? (modalEl.querySelector('.modal-content') || modalEl) : null;
        
        if (!modalEl || !contentEl) return;

        // Show loading
        contentEl.innerHTML = `
            <div class="modal-body text-center p-5">
                <div class="spinner-border text-primary" role="status"></div>
                <p class="mt-3 text-muted">جاري تحميل التفاصيل...</p>
            </div>
        `;
        
        const modal = bootstrap.Modal.getOrCreateInstance(modalEl);
        modal.show();

        fetch(url, {
            headers: {
                'X-Requested-With': 'XMLHttpRequest'
            }
        })
        .then(resp => {
             if (!resp.ok) throw new Error('Network response was not ok');
             return resp.json();
        })
        .then(data => {
            contentEl.innerHTML = data.html;
        })
        .catch(err => {
            console.error('Error loading detail:', err);
            contentEl.innerHTML = `
                <div class="modal-header border-0 pb-0">
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="إغلاق"></button>
                </div>
                <div class="modal-body text-center p-5">
                    <div class="text-danger mb-3"><i class="fas fa-exclamation-triangle fa-3x"></i></div>
                    <h5 class="text-danger">فشل تحميل البيانات</h5>
                    <p class="text-muted">حدث خطأ أثناء الاتصال بالسيرفر. يرجى المحاولة مرة أخرى.</p>
                </div>
            `;
        });
    });
}

/**
 * Dynamic modal handler - creates a floating modal on-the-fly via AJAX.
 * Use for links INSIDE existing modals to open nested/overlay modals.
 * Trigger element needs: data-dynamic-modal-url="/api/path/"
 */
function initDynamicDetailModals() {
    document.addEventListener('click', function (e) {
        const trigger = e.target.closest('[data-dynamic-modal-url]');
        if (!trigger) return;

        e.preventDefault();
        const url = trigger.getAttribute('data-dynamic-modal-url');
        if (!url) return;

        const host = document.createElement('div');
        host.innerHTML = `
            <div class="modal fade" tabindex="-1" aria-hidden="true">
                <div class="modal-dialog modal-xl modal-dialog-centered">
                    <div class="modal-content">
                        <div class="modal-body text-center p-5">
                            <div class="spinner-border text-primary" role="status"></div>
                            <p class="mt-3 text-muted">جاري تحميل التفاصيل...</p>
                        </div>
                    </div>
                </div>
            </div>
        `;
        document.body.appendChild(host);

        const modalEl = host.querySelector('.modal');
        const contentEl = host.querySelector('.modal-content');
        const modal = new bootstrap.Modal(modalEl, { backdrop: true });
        modal.show();

        // Ensure Escape key works for dynamic modals
        modalEl.addEventListener('keydown', (ev) => {
            if (ev.key === 'Escape') {
                ev.stopPropagation();
                modal.hide();
            }
        });
        modalEl.addEventListener('shown.bs.modal', () => modalEl.focus());
        modalEl.addEventListener('hidden.bs.modal', () => host.remove());

        fetch(url, { headers: { 'X-Requested-With': 'XMLHttpRequest' } })
            .then(resp => {
                if (!resp.ok) throw new Error('Network error');
                return resp.json();
            })
            .then(data => {
                contentEl.innerHTML = data.html;
            })
            .catch(err => {
                console.error('Dynamic modal error:', err);
                contentEl.innerHTML = `
                    <div class="modal-header border-0">
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body text-center p-5">
                        <div class="text-danger mb-3"><i class="fas fa-exclamation-triangle fa-3x"></i></div>
                        <h5 class="text-danger">فشل تحميل البيانات</h5>
                        <p class="text-muted">حدث خطأ أثناء الاتصال بالسيرفر.</p>
                    </div>
                `;
            });
    });
}

/**
 * Reusable print function with predefined styling
 * @param {string} htmlContent - The HTML content to print
 * @param {string} title - Optional page title for the print window
 */
function printContent(htmlContent, title = 'دِرْعٌ وَسَيْفٌ - طباعة') {
    const printArea = document.createElement('div');
    printArea.id = 'dynamicPrintArea';
    printArea.style.display = 'none';
    document.body.appendChild(printArea);

    const printStyle = document.createElement('style');
    printStyle.id = 'dynamicPrintStyle';
    printStyle.innerHTML = `
        @media print {
            body * { visibility: hidden; }
            #dynamicPrintArea, #dynamicPrintArea * { visibility: visible; }
            #dynamicPrintArea {
                position: absolute; left: 0; top: 0; width: 100%; padding: 40px;
                font-family: 'Cairo', sans-serif; background: white; direction: rtl;
            }
            .print-header { display: flex; flex-direction: row-reverse; justify-content: space-between; align-items: center; border-bottom: 3px solid #4f46e5; padding-bottom: 20px; margin-bottom: 30px; }
            .office-info h1 { margin: 0; color: #4f46e5; font-size: 24px; font-weight: 800; }
            .print-logo { width: 100px; height: 100px; object-fit: contain; }
            .report-title { text-align: center; margin-bottom: 30px; }
            .report-title h2 { display: inline-block; padding: 10px 30px; background: #f8fafc; border-radius: 50px; color: #1e293b; font-size: 20px; font-weight: 700; border: 1px solid #e2e8f0; }
            .print-section { margin-bottom: 25px; page-break-inside: avoid; }
            .section-title { color: #4f46e5; font-size: 16px; font-weight: 700; margin-bottom: 15px; border-bottom: 2px solid #eef2ff; }
            .info-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; }
            .info-item { display: flex; justify-content: space-between; padding: 8px 12px; background: #f8fafc; border-radius: 8px; }
            .print-table { width: 100%; border-collapse: collapse; margin-top: 10px; border: 1px solid #e2e8f0; }
            .print-table th { background: #f1f5f9; padding: 10px; text-align: right; color: #4f46e5; border-bottom: 2px solid #e2e8f0; }
            .print-table td { padding: 10px; border-bottom: 1px solid #f1f5f9; font-size: 13px; }
            .print-footer { margin-top: 50px; padding-top: 20px; border-top: 1px solid #e2e8f0; display: flex; justify-content: space-between; color: #94a3b8; font-size: 12px; }
            .no-print { display: none !important; }
        }
    `;
    document.head.appendChild(printStyle);
    printArea.innerHTML = htmlContent;

    // تغيير عنوان الصفحة مؤقتاً لتسمية الملف (مع إضافة تأخير بسيط للضمان)
    const originalTitle = document.title;
    document.title = title;

    setTimeout(() => {
        window.print();
        // استعادة العنوان الأصلي
        window.addEventListener('afterprint', () => {
            document.title = originalTitle;
        }, { once: true });
    }, 500); 

    // Cleanup
    setTimeout(() => {
        printArea.remove();
        printStyle.remove();
    }, 1000);
}


/**
 * Attach print handler for client detail modal
 */
/**
 * Attach print handler for client detail modal
 */
function attachClientPrint(modalEl, clientId) {
    const printBtn = modalEl.querySelector('#printClientBtn');
    if (!printBtn) return;

    printBtn.addEventListener('click', function() {
        if (typeof printClientDirectly === 'function') {
            printClientDirectly(clientId);
        } else {
            console.error('printClientDirectly is not defined');
        }
    });
}

function initFormLoadingState() {
    document.querySelectorAll('form[data-loading-text]').forEach(function(form) {
        form.addEventListener('submit', function(e) {
            const submitBtn = form.querySelector('button[type="submit"]');
            if (submitBtn) {
                const originalText = submitBtn.innerHTML;
                const loadingText = form.getAttribute('data-loading-text') || 'جاري الحفظ...';
                
                submitBtn.disabled = true;
                submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> ' + loadingText;
                
                // Re-enable after 30 seconds as fallback
                setTimeout(function() {
                    submitBtn.disabled = false;
                    submitBtn.innerHTML = originalText;
                }, 30000);
            }
        });
    });
}

/**
 * Format currency display
 */
function formatCurrency(amount, currency = 'ج.م') {
    return new Intl.NumberFormat('ar-EG', {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
    }).format(amount) + ' ' + currency;
}

/**
 * Format date display
 */
function formatDate(dateString, locale = 'ar-EG') {
    const date = new Date(dateString);
    return new Intl.DateTimeFormat(locale, {
        year: 'numeric',
        month: 'long',
        day: 'numeric'
    }).format(date);
}

/**
 * Debounce function for search inputs
 */
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

/**
 * Export table to CSV
 */
function exportTableToCSV(tableId, filename = 'export.csv') {
    const table = document.getElementById(tableId);
    if (!table) return;
    
    let csv = [];
    const rows = table.querySelectorAll('tr');
    
    rows.forEach(function(row) {
        const cols = row.querySelectorAll('td, th');
        const csvRow = [];
        
        cols.forEach(function(col) {
            csvRow.push('"' + col.textContent.trim() + '"');
        });
        
        csv.push(csvRow.join(','));
    });
    
    downloadCSV(csv.join('\n'), filename);
}

/**
 * Download CSV file
 */
function downloadCSV(csv, filename) {
    const blob = new Blob(['\uFEFF' + csv], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = filename;
    link.style.display = 'none';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
}

/**
 * Print specific element
 */
function printElement(elementId) {
    const element = document.getElementById(elementId);
    if (!element) return;
    
    const printWindow = window.open('', '', 'height=600,width=800');
    printWindow.document.write('<html><head><title>طباعة</title>');
    printWindow.document.write('</head><body dir="rtl">');
    printWindow.document.write(element.innerHTML);
    printWindow.document.write('</body></html>');
    printWindow.document.close();
    printWindow.print();
}

/**
 * Select all checkboxes in a table
 */
function initSelectAll() {
    const selectAllCheckbox = document.getElementById('select-all');
    if (!selectAllCheckbox) return;
    
    selectAllCheckbox.addEventListener('change', function() {
        const checkboxes = document.querySelectorAll('.select-item');
        checkboxes.forEach(function(checkbox) {
            checkbox.checked = selectAllCheckbox.checked;
        });
    });
}

/**
 * Initialize on page load
 */
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initializeApp);
} else {
    initializeApp();
}
