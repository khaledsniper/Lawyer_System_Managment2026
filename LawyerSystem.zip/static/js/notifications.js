document.addEventListener('DOMContentLoaded', function() {
    const notificationsDropdown = document.getElementById('notificationsDropdown');
    if (!notificationsDropdown) return;

    const notificationsList = document.getElementById('notificationsList');
    const notificationBadge = document.getElementById('notificationBadge');
    const markAllBtn = document.getElementById('markAllAsReadBtn');

    // جلب الروابط من سمات البيانات في العنصر الأب
    const listUrl = notificationsDropdown.dataset.listUrl;
    const markAllUrl = notificationsDropdown.dataset.markAllUrl;

    // تحميل الإشعارات عند فتح القائمة
    notificationsDropdown.addEventListener('show.bs.dropdown', function() {
        loadNotifications();
    });

    function loadNotifications() {
        if (!notificationsList || !listUrl) return;

        fetch(listUrl)
            .then(response => response.json())
            .then(data => {
                renderNotifications(data.notifications);
                updateBadgeCount(data.notifications.filter(n => !n.is_read).length);
            })
            .catch(err => {
                console.error('Error loading notifications:', err);
                notificationsList.innerHTML = `
                    <div class="text-center py-3 text-danger">
                        <i class="fas fa-exclamation-triangle"></i>
                        <p class="mb-0 small">فشل تحميل الإشعارات</p>
                    </div>
                `;
            });
    }

    function renderNotifications(notifications) {
        if (!notificationsList) return;

        if (notifications.length === 0) {
            notificationsList.innerHTML = `
                <div class="text-center py-4">
                    <i class="fas fa-bell-slash" style="font-size: 2rem; color: var(--text-muted);"></i>
                    <p class="text-muted mt-2 mb-0 small">لا توجد إشعارات</p>
                </div>
            `;
            return;
        }

        let html = '';
        notifications.forEach(n => {
            const bgStyle = `background: ${n.bg_color};`;
            const colorStyle = `color: ${n.color};`;
            const unreadClass = n.is_read ? '' : 'fw-bold';

            html += `
                <div class="dropdown-item px-3 py-2 border-bottom" style="cursor: pointer;">
                    <div class="d-flex align-items-start gap-2">
                        <div class="notification-icon" style="width: 36px; height: 36px; border-radius: 8px; display: flex; align-items: center; justify-content: center; flex-shrink: 0; ${bgStyle}">
                            <i class="fas ${n.icon}" style="${colorStyle}"></i>
                        </div>
                        <div class="flex-grow-1" style="min-width: 0;">
                            <p class="mb-0 small ${unreadClass}" style="line-height: 1.4; word-wrap: break-word;">${n.message}</p>
                            <small class="text-muted" style="font-size: 0.7rem;">${n.created_at}</small>
                        </div>
                        <div class="d-flex gap-1">
                            ${!n.is_read ? `
                            <button type="button" class="btn btn-sm btn-link text-decoration-none p-1 mark-read-btn" 
                                data-id="${n.id}" title="علّم كمقروء" style="color: ${n.color};">
                                <i class="fas fa-check"></i>
                            </button>
                            ` : ''}
                            <button type="button" class="btn btn-sm btn-link text-danger text-decoration-none p-1 delete-btn" 
                                data-id="${n.id}" title="حذف">
                                <i class="fas fa-trash"></i>
                            </button>
                        </div>
                    </div>
                </div>
            `;
        });

        notificationsList.innerHTML = html;

        document.querySelectorAll('.mark-read-btn').forEach(btn => {
            btn.addEventListener('click', e => { e.stopPropagation(); markAsRead(btn.dataset.id); });
        });

        document.querySelectorAll('.delete-btn').forEach(btn => {
            btn.addEventListener('click', e => { e.stopPropagation(); deleteNotification(btn.dataset.id, btn); });
        });
    }

    function updateBadgeCount(count) {
        if (notificationBadge) {
            notificationBadge.textContent = count;
            notificationBadge.style.display = count > 0 ? 'inline-block' : 'none';
            if (markAllBtn) markAllBtn.style.display = count > 0 ? 'block' : 'none';
        }
    }

    function markAsRead(id) {
        fetch(`/api/notifications/${id}/mark-as-read/`, {
            method: 'POST',
            headers: { 'X-CSRFToken': getCookie('csrftoken') }
        }).then(() => loadNotifications());
    }

    if (markAllBtn && markAllUrl) {
        markAllBtn.addEventListener('click', () => {
            fetch(markAllUrl, {
                method: 'POST',
                headers: { 'X-CSRFToken': getCookie('csrftoken') }
            }).then(() => loadNotifications());
        });
    }

    function deleteNotification(id, btnElement) {
        const notificationItem = btnElement.closest('.dropdown-item');
        notificationItem.style.display = 'none';

        const undoHtml = `
            <div class="dropdown-item px-3 py-2 border-bottom undo-container" style="background: var(--bg-hover);">
                <div class="d-flex align-items-center justify-content-between gap-2">
                    <small><i class="fas fa-trash-alt"></i> تم الحذف</small>
                    <button type="button" class="btn btn-sm btn-link text-decoration-none p-1 undo-btn"><i class="fas fa-undo"></i> تراجع</button>
                </div>
            </div>
        `;
        notificationItem.insertAdjacentHTML('afterend', undoHtml);

        let undoTimeout = setTimeout(() => {
            fetch(`/api/notifications/${id}/delete/`, {
                method: 'POST',
                headers: { 'X-CSRFToken': getCookie('csrftoken') }
            }).then(() => loadNotifications());
        }, 5000);

        notificationItem.nextElementSibling.querySelector('.undo-btn').onclick = () => {
            clearTimeout(undoTimeout);
            notificationItem.nextElementSibling.remove();
            notificationItem.style.display = 'block';
        };
    }

    function getCookie(name) {
        let cookieValue = null;
        if (document.cookie && document.cookie !== '') {
            const cookies = document.cookie.split(';');
            for (let i = 0; i < cookies.length; i++) {
                const cookie = cookies[i].trim();
                if (cookie.substring(0, name.length + 1) === (name + '=')) {
                    cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                    break;
                }
            }
        }
        return cookieValue;
    }
});