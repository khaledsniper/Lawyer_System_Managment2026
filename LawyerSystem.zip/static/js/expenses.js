/**
 * نظام المصروفات الموحد - دِرْعٌ وَسَيْفٌ
 * Expenses Unified System
 * 
 * يوفر عرض وتفاصيل واحترافية للمصروفات
 */

// ==========================================
// 1. View Expense Detail Modal
// ==========================================

// 1. View Expense Detail Modal logic removed to use generic system in main.js

// ==========================================
// 2. Print Expense
// ==========================================

document.addEventListener('click', function(e) {
    const printBtn = e.target.closest('.btn-print-expense');
    if (!printBtn) return;

    e.preventDefault();
    const expenseId = printBtn.dataset.expenseId;

    if (!expenseId) return;

    printBtn.disabled = true;

    fetch(`/api/expenses/${expenseId}/`, {
        headers: { 'X-Requested-With': 'XMLHttpRequest' }
    })
    .then(r => r.json())
    .then(data => {
        if (data.error) {
            alert(data.error);
            return;
        }

        // Build badges
        const badges = [
            `النوع: ${data.expense_type_display || '—'}`,
            `التاريخ: ${data.date_formatted || '—'}`,
            `الفئة: ${data.category_display || '—'}`
        ];

        // Build sections
        const sections = [];

        sections.push({
            title: 'بيانات المصروف',
            fields: [
                { label: 'الوصف', value: data.description || '—' },
                { label: 'المبلغ', value: `${data.amount_formatted || '—'} ج.م` }
            ]
        });

        if (data.case) {
            sections.push({
                title: 'القضية المرتبطة',
                fields: [
                    { label: 'رقم القضية', value: data.case.case_number || '—' },
                    { label: 'العميل', value: data.case.client_name || '—' },
                    { label: 'المحكمة', value: data.case.court_name || '—' }
                ]
            });
        }

        // Print using unified system
        if (typeof printUnified === 'function') {
            printUnified({
                type: 'expense',
                title: 'تفاصيل المصروف',
                badges: badges,
                sections: sections,
                footer: 'تم الطباعة من نظام دِرْعٌ وَسَيْفٌ'
            });
        } else {
            window.open(`/expenses/${expenseId}/print/`, '_blank');
        }

        printBtn.disabled = false;
    })
    .catch(err => {
        console.error(err);
        printBtn.disabled = false;
    });
});

// ==========================================
// 3. Edit/Delete Expense Modals
// ==========================================

function refreshExpensesAfterMutation(expenseType) {
    const activeOfficeTab = document.querySelector('#tab-office-expenses.show.active');
    
    // إذا كان في تبويب المكتب
    if (activeOfficeTab || expenseType === 'office') {
        const officeFilterForm = document.getElementById('officeExpenseFilterForm');
        const officeTargetId = officeFilterForm ? officeFilterForm.dataset.targetId : null;
        const officeTarget = officeTargetId ? document.getElementById(officeTargetId) : null;
        
        // إذا كان لدينا نموذج فلتر للمكتب، استخدم AJAX للتحديث
        if (officeFilterForm && officeTarget) {
            const formData = new FormData(officeFilterForm);
            const params = new URLSearchParams(formData);
            params.set('tab', 'office'); // تأكد من الحفاظ على التبويب
            const url = officeFilterForm.action + '?' + params.toString();
            
            fetch(url, { headers: { 'X-Requested-With': 'XMLHttpRequest' } })
                .then(response => response.json())
                .then(data => {
                    // تحديث الجدول
                    if (data.html) officeTarget.innerHTML = data.html;
                    // تحديث العداد
                    if (data.count !== undefined) {
                        const countElement = document.getElementById('officeExpensesCount');
                        if (countElement) countElement.textContent = data.count;
                    }
                    // تحديث بطاقات الإحصاءات
                    if (data.stats) {
                        const statsCards = document.querySelectorAll('.hero-stat .value');
                        if (statsCards.length >= 3 && data.stats.total !== undefined) {
                            statsCards[0].textContent = data.stats.total;
                            statsCards[1].textContent = data.stats.case_expenses;
                            statsCards[2].textContent = data.stats.office_expenses;
                        }
                    }
                })
                .catch(() => {
                    // في حالة الفشل، أعد تحميل الصفحة مع الحفاظ على التبويب
                    const currentUrl = new URL(window.location.href);
                    currentUrl.searchParams.set('tab', 'office');
                    window.location.href = currentUrl.toString();
                });
            return;
        } else {
            // إذا لم يكن هناك نموذج فلتر، أعد تحميل الصفحة مع الحفاظ على التبويب
            const currentUrl = new URL(window.location.href);
            currentUrl.searchParams.set('tab', 'office');
            window.location.href = currentUrl.toString();
            return;
        }
    }
    
    // إذا كان في تبويب القضايا
    const filterForm = document.getElementById('caseExpenseFilterForm');
    const targetId = filterForm ? filterForm.dataset.targetId : null;
    const target = targetId ? document.getElementById(targetId) : null;
    
    // إذا لم يوجد فلتر، أعد تحميل الصفحة
    if (!filterForm || !target) {
        window.location.reload();
        return;
    }

    // تحديث الجدول والإحصاءات عبر AJAX
    const formData = new FormData(filterForm);
    const params = new URLSearchParams(formData);
    const url = filterForm.action + '?' + params.toString();

    fetch(url, { headers: { 'X-Requested-With': 'XMLHttpRequest' } })
        .then(response => response.json())
        .then(data => {
            // تحديث الجدول
            if (data.html) target.innerHTML = data.html;
            if (data.count !== undefined) {
                const countElement = document.getElementById('expensesCount');
                if (countElement) countElement.textContent = data.count;
            }
            // تحديث بطاقات الإحصاءات
            if (data.stats) {
                const statsCards = document.querySelectorAll('.hero-stat .value');
                if (statsCards.length >= 3 && data.stats.total !== undefined) {
                    statsCards[0].textContent = data.stats.total;
                    statsCards[1].textContent = data.stats.case_expenses;
                    statsCards[2].textContent = data.stats.office_expenses;
                }
            }
        })
        .catch(() => window.location.reload());
}

function createExpenseModal(modalId, html, sizeClass = 'modal-lg') {
    const existing = document.getElementById(modalId);
    if (existing) existing.closest('.expense-modal-host')?.remove();

    const host = document.createElement('div');
    host.className = 'expense-modal-host';
    host.innerHTML = `
        <div class="modal fade" id="${modalId}" tabindex="-1" aria-hidden="true" dir="rtl">
            <div class="modal-dialog ${sizeClass} modal-dialog-centered"></div>
        </div>
    `;
    document.body.appendChild(host);

    const modalEl = host.querySelector('.modal');
    const dialog = host.querySelector('.modal-dialog');
    dialog.innerHTML = html;
    modalEl.addEventListener('hidden.bs.modal', () => host.remove());
    return modalEl;
}

function bindExpenseTypeToggle(container) {
    const expenseTypeSelect = container.querySelector('.expense-type-select');
    const caseFieldWrapper = container.querySelector('.case-field-wrapper');
    const caseSelect = container.querySelector('.case-select');

    function toggleCaseField() {
        if (!expenseTypeSelect || !caseFieldWrapper || !caseSelect) return;
        if (expenseTypeSelect.value === 'office') {
            caseFieldWrapper.style.display = 'none';
            caseSelect.required = false;
            caseSelect.value = '';
        } else {
            caseFieldWrapper.style.display = '';
            caseSelect.required = false;
        }
    }

    if (expenseTypeSelect) {
        expenseTypeSelect.addEventListener('change', toggleCaseField);
        toggleCaseField();
    }
}

function bindExpenseEditForm(modalEl) {
    bindExpenseTypeToggle(modalEl);

    if (typeof window.initDatePickers === 'function') {
        window.initDatePickers(modalEl);
    }


    const form = modalEl.querySelector('.expense-modal-form');
    if (!form || form.dataset.bound === 'true') return;

    form.dataset.bound = 'true';
    form.addEventListener('submit', function(event) {
        event.preventDefault();

        const submitBtn = form.querySelector('button[type="submit"]');
        const originalHtml = submitBtn ? submitBtn.innerHTML : '';
        if (submitBtn) {
            submitBtn.disabled = true;
            submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin ms-1"></i>جاري الحفظ...';
        }

        const formData = new FormData(form);

        fetch(form.action, {
            method: 'POST',
            credentials: 'same-origin',
            headers: { 'X-Requested-With': 'XMLHttpRequest' },
            body: formData
        })
            .then(async response => {
                const data = await response.json();
                return { ok: response.ok, data };
            })
            .then(({ ok, data }) => {
                if (ok && data.status === 'success') {
                    const modal = bootstrap.Modal.getInstance(modalEl);
                    modalEl.addEventListener('hidden.bs.modal', function() {
                        refreshExpensesAfterMutation(data.expense_type);
                    }, { once: true });
                    if (modal) modal.hide();
                    return;
                }

                if (data.html) {
                    modalEl.querySelector('.modal-dialog').innerHTML = data.html;
                    bindExpenseEditForm(modalEl);
                    return;
                }

                throw new Error('unexpected_response');
            })
            .catch(error => {
                console.error('Expense edit failed:', error);
                alert('تعذر حفظ المصروف. راجع البيانات وحاول مرة أخرى.');
            })
            .finally(() => {
                if (submitBtn && document.body.contains(submitBtn)) {
                    submitBtn.disabled = false;
                    submitBtn.innerHTML = originalHtml;
                }
            });
    });
}

document.addEventListener('click', function(event) {
    const actionBtn = event.target.closest('.btn-edit-expense, .btn-add-expense');
    if (!actionBtn) return;

    event.preventDefault();
    const url = actionBtn.dataset.url || actionBtn.href;

    fetch(url, {
        credentials: 'same-origin',
        headers: { 'X-Requested-With': 'XMLHttpRequest' }
    })
        .then(response => response.json())
        .then(data => {
            if (!data.html) throw new Error('empty_modal_payload');
            const modalEl = createExpenseModal('expenseEditModal', data.html, 'modal-lg');
            bindExpenseEditForm(modalEl);
            bootstrap.Modal.getOrCreateInstance(modalEl).show();
        })
        .catch(error => {
            console.error('Expense edit modal failed:', error);
            alert('حدث خطأ أثناء فتح النافذة: ' + error.message);
        });
});

function bindExpenseDeleteForm(modalEl) {
    const form = modalEl.querySelector('.expense-delete-form');
    if (!form || form.dataset.bound === 'true') return;

    form.dataset.bound = 'true';
    form.addEventListener('submit', function(event) {
        event.preventDefault();

        const submitBtn = form.querySelector('button[type="submit"]');
        const originalHtml = submitBtn ? submitBtn.innerHTML : '';
        if (submitBtn) {
            submitBtn.disabled = true;
            submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin ms-1"></i>جاري الحذف...';
        }

        const formData = new FormData(form);

        fetch(form.action, {
            method: 'POST',
            credentials: 'same-origin',
            headers: { 'X-Requested-With': 'XMLHttpRequest' },
            body: formData
        })
            .then(async response => {
                const data = await response.json();
                return { ok: response.ok, data };
            })
            .then(({ ok, data }) => {
                if (ok && data.status === 'success') {
                    const modal = bootstrap.Modal.getInstance(modalEl);
                    modalEl.addEventListener('hidden.bs.modal', function() {
                        refreshExpensesAfterMutation(data.expense_type);
                    }, { once: true });
                    if (modal) modal.hide();
                    return;
                }
                throw new Error('unexpected_response');
            })
            .catch(error => {
                console.error('Expense delete failed:', error);
                alert('تعذر حذف المصروف. حاول مرة أخرى.');
            })
            .finally(() => {
                if (submitBtn && document.body.contains(submitBtn)) {
                    submitBtn.disabled = false;
                    submitBtn.innerHTML = originalHtml;
                }
            });
    });
}

document.addEventListener('click', function(event) {
    const deleteBtn = event.target.closest('.btn-delete-expense');
    if (!deleteBtn) return;

    event.preventDefault();
    const url = deleteBtn.dataset.url || deleteBtn.href;

    fetch(url, {
        credentials: 'same-origin',
        headers: { 'X-Requested-With': 'XMLHttpRequest' }
    })
        .then(response => response.json())
        .then(data => {
            if (!data.html) throw new Error('empty_modal_payload');
            const modalEl = createExpenseModal('expenseDeleteModal', data.html, '');
            bindExpenseDeleteForm(modalEl);
            bootstrap.Modal.getOrCreateInstance(modalEl).show();
        })
        .catch(error => {
            console.error('Expense delete modal failed:', error);
            window.location.href = url;
        });
});
