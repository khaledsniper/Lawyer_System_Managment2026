/**
 * Mizan Al-Adala - Invoices Management JavaScript
 * Handles AJAX modals and updates for Invoices
 */

document.addEventListener('DOMContentLoaded', function () {
    initInvoiceModals();
});

function initInvoiceModals() {
    // 1. Add/Edit Invoice Modal
    document.addEventListener('click', function (e) {
        const actionBtn = e.target.closest('.btn-add-invoice, .btn-edit-invoice');
        if (!actionBtn) return;

        e.preventDefault();
        const url = actionBtn.dataset.url || actionBtn.href;
        const modalEl = document.getElementById('invoiceModal');
        const contentArea = document.getElementById('invoiceModalContent');

        if (modalEl && contentArea) {
            contentArea.innerHTML = '<div class="text-center py-5"><div class="spinner-border text-warning" role="status"></div><p class="mt-2">جاري التحميل...</p></div>';
            const modal = bootstrap.Modal.getOrCreateInstance(modalEl);
            modal.show();

            fetch(url, { headers: { 'X-Requested-With': 'XMLHttpRequest' } })
                .then(res => res.json())
                .then(data => {
                    if (data.html) {
                        contentArea.innerHTML = data.html;
                        bindInvoiceForm(modalEl);
                    } else {
                        contentArea.innerHTML = '<div class="alert alert-danger">❌ فشل تحميل المحتوى</div>';
                    }
                })
                .catch(err => {
                    console.error('Fetch error:', err);
                    contentArea.innerHTML = '<div class="alert alert-danger">❌ فشل تحميل البيانات.</div>';
                });
        }
    });

    // 2. Delete Invoice Confirmation
    document.addEventListener('click', function (e) {
        const deleteBtn = e.target.closest('.btn-delete-invoice');
        if (deleteBtn) {
            const url = deleteBtn.getAttribute('data-url');
            const invoiceNum = deleteBtn.getAttribute('data-invoice');

            const modalEl = document.getElementById('deleteInvoiceModal');
            const infoArea = document.getElementById('deleteInvoiceNumber');
            const form = document.getElementById('deleteInvoiceForm');

            if (modalEl && infoArea && form) {
                infoArea.textContent = invoiceNum;
                form.setAttribute('action', url);
                bootstrap.Modal.getOrCreateInstance(modalEl).show();
            }
        }
    });
}

function bindInvoiceForm(modalEl) {
    const form = modalEl.querySelector('form');
    if (!form) return;

    form.addEventListener('submit', function (e) {
        e.preventDefault();
        const submitBtn = form.querySelector('button[type="submit"]');
        const originalText = submitBtn.innerHTML;

        submitBtn.disabled = true;
        submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin me-1"></i> جاري الحفظ...';

        const formData = new FormData(form);

        fetch(form.getAttribute('action') || window.location.href, {
            method: 'POST',
            body: formData,
            headers: { 'X-Requested-With': 'XMLHttpRequest' }
        })
            .then(res => res.json())
            .then(data => {
                if (data.status === 'success') {
                    bootstrap.Modal.getInstance(modalEl).hide();
                    window.location.reload(); 
                } else if (data.html) {
                    document.getElementById('invoiceModalContent').innerHTML = data.html;
                    bindInvoiceForm(modalEl);
                } else {
                    alert('❌ حدث خطأ أثناء الحفظ');
                }
            })
            .catch(err => {
                console.error('Submit error:', err);
                alert('❌ حدث خطأ في الاتصال');
            })
            .finally(() => {
                submitBtn.disabled = false;
                submitBtn.innerHTML = originalText;
            });
    });
}
