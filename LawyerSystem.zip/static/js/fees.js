/**
 * Mizan Al-Adala - Fees Management JavaScript
 * Handles AJAX modals and updates for Fees
 */

document.addEventListener('DOMContentLoaded', function () {
    initFeesModals();
});

function initFeesModals() {
    // 1. Add/Edit Fee Modal
    document.addEventListener('click', function (e) {
        const actionBtn = e.target.closest('.btn-add-fee, .btn-edit-fee');
        if (!actionBtn) return;

        e.preventDefault();
        const url = actionBtn.dataset.url || actionBtn.href;
        const modalEl = document.getElementById('feeModal');
        const contentArea = document.getElementById('feeModalContent');

        if (modalEl && contentArea) {
            contentArea.innerHTML = '<div class="text-center py-5"><div class="spinner-border text-primary" role="status"></div><p class="mt-2">جاري التحميل...</p></div>';
            const modal = bootstrap.Modal.getOrCreateInstance(modalEl);
            modal.show();

            fetch(url, { headers: { 'X-Requested-With': 'XMLHttpRequest' } })
                .then(res => res.json())
                .then(data => {
                    if (data.html) {
                        contentArea.innerHTML = data.html;
                        bindFeeForm(modalEl);
                    } else {
                        contentArea.innerHTML = '<div class="alert alert-danger">❌ فشل تحميل المحتوى</div>';
                    }
                })
                .catch(err => {
                    console.error('Fetch error:', err);
                    contentArea.innerHTML = '<div class="alert alert-danger">❌ فشل تحميل البيانات.</div>';
                });
        }
    });

    // 2. Delete Fee Confirmation
    document.addEventListener('click', function (e) {
        const deleteBtn = e.target.closest('.btn-delete-fee');
        if (deleteBtn) {
            const url = deleteBtn.getAttribute('data-url');
            const caseInfo = deleteBtn.getAttribute('data-case');

            const modalEl = document.getElementById('deleteFeeModal');
            const infoArea = document.getElementById('deleteFeeCaseInfo');
            const form = document.getElementById('deleteFeeForm');

            if (modalEl && infoArea && form) {
                infoArea.textContent = caseInfo;
                form.setAttribute('action', url);
                bootstrap.Modal.getOrCreateInstance(modalEl).show();
            }
        }
    });
}

function bindFeeForm(modalEl) {
    const form = modalEl.querySelector('form');
    if (!form) return;

    form.addEventListener('submit', function (e) {
        e.preventDefault();
        const submitBtn = form.querySelector('button[type="submit"]');
        const originalText = submitBtn.innerHTML;

        submitBtn.disabled = true;
        submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin me-1"></i> جاري الحفظ...';

        const formData = new FormData(form);

        fetch(form.getAttribute('action') || window.location.href, {
            method: 'POST',
            body: formData,
            headers: { 'X-Requested-With': 'XMLHttpRequest' }
        })
            .then(res => res.json())
            .then(data => {
                if (data.status === 'success') {
                    bootstrap.Modal.getInstance(modalEl).hide();
                    window.location.reload(); // Refresh to update stats and table
                } else if (data.html) {
                    // Re-render form with errors
                    document.getElementById('feeModalContent').innerHTML = data.html;
                    bindFeeForm(modalEl);
                } else {
                    alert('❌ حدث خطأ أثناء الحفظ');
                }
            })
            .catch(err => {
                console.error('Submit error:', err);
                alert('❌ حدث خطأ في الاتصال');
            })
            .finally(() => {
                submitBtn.disabled = false;
                submitBtn.innerHTML = originalText;
            });
    });
}
