/**
 * Clients Page JavaScript
 * Handles client management, modals, filtering, and printing
 */

document.addEventListener('DOMContentLoaded', function() {
    // ==========================================
    // 1. Edit Client Modal Handler
    // ==========================================
    
    /**
     * Open edit modal for a client
     */
    document.addEventListener('click', function(e) {
        const editBtn = e.target.closest('.btn-edit-client');
        if (!editBtn) return;

        e.preventDefault();
        const url = editBtn.dataset.url;

        fetch(url, {
            headers: {
                'X-Requested-With': 'XMLHttpRequest'
            }
        })
        .then(response => response.json())
        .then(data => {
            const modalDiv = document.createElement('div');
            // Remove any script tags from the injected HTML to prevent conflicts
            const tempDiv = document.createElement('div');
            tempDiv.innerHTML = data.html;
            const scripts = tempDiv.querySelectorAll('script');
            scripts.forEach(s => s.remove());
            modalDiv.innerHTML = tempDiv.innerHTML;
            document.body.appendChild(modalDiv);

            const modalEl = modalDiv.querySelector('.modal');
            if (modalEl) {
                const modal = new bootstrap.Modal(modalEl);
                modal.show();

                modalEl.addEventListener('hidden.bs.modal', () => modalDiv.remove());

                // اتصال زر الإلغاء لإغلاق الـ modal
                const cancelBtn = modalEl.querySelector('.btn-cancel-form');
                if (cancelBtn) {
                    cancelBtn.addEventListener('click', function(ev) {
                        ev.preventDefault();
                        modal.hide();
                    });
                }

                // ⚠️ تهيئة نموذج التعديل بعد تحميل الـ modal
                _attachClientUpdateFormHandler();
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('❌ فشل تحميل نموذج التعديل');
        });
    });

    /**
     * Attach form handler for client update modal
     */
    function _attachClientUpdateFormHandler() {
        setTimeout(function() {
            const updateForm = document.getElementById('updateClientForm');
            const updateModal = document.getElementById('updateClientModal');

            if (!updateForm) {
                console.error('❌ updateClientForm not found!');
                return;
            }
            if (updateForm.dataset.handlerAttached) return;
            updateForm.dataset.handlerAttached = 'true';

            // حاوية لعرض رسائل الخطأ داخل النافذة
            let errorContainer = document.getElementById('updateClientErrors');
            if (!errorContainer) {
                errorContainer = document.createElement('div');
                errorContainer.id = 'updateClientErrors';
                errorContainer.className = 'alert alert-danger d-none mb-3';
                updateForm.querySelector('.modal-body').prepend(errorContainer);
            }

            // --- منطق إخفاء/إظهار الحقول حسب نوع العميل ---
            const typeSelect = updateForm.querySelector('[name="type"]');

            function updateModalFields() {
                if (!typeSelect) return;
                const isCompany = typeSelect.value === 'company';
                
                const individualFields = updateForm.querySelectorAll('.individual-field');
                const companyFields = updateForm.querySelectorAll('.company-field');
                
                individualFields.forEach(el => {
                    el.style.display = isCompany ? 'none' : '';
                });
                companyFields.forEach(el => {
                    el.style.display = isCompany ? '' : 'none';
                });
            }

            if (typeSelect) {
                typeSelect.addEventListener('change', updateModalFields);
                updateModalFields(); // تشغيل فوري عند التحميل
            }

            // --- معالجة إرسال النموذج ---
            updateForm.addEventListener('submit', function(e) {
                e.preventDefault();
                e.stopPropagation();
                errorContainer.classList.add('d-none');
                errorContainer.innerHTML = '';

                const formData = new FormData(this);
                const submitBtn = this.querySelector('button[type="submit"]');
                const originalText = submitBtn.innerHTML;

                submitBtn.disabled = true;
                submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin me-1"></i> جاري الحفظ...';

                fetch(this.action, {
                    method: 'POST',
                    body: formData,
                    headers: {
                        'X-Requested-With': 'XMLHttpRequest',
                        'X-CSRFToken': formData.get('csrfmiddlewaretoken')
                    }
                })
                .then(response => {
                    const contentType = response.headers.get('content-type') || '';

                    if (!contentType.includes('application/json')) {
                        return response.text().then(html => {
                            throw new Error('الخادم لم يرجع استجابة JSON.');
                        });
                    }
                    return response.json();
                })
                .then(data => {
                    if (data.status === 'success') {
                        if (updateModal) {
                            const modalInstance = bootstrap.Modal.getInstance(updateModal);
                            if (modalInstance) modalInstance.hide();
                        }

                        // تحديث الجدول باستخدام AJAX
                        const tableBody = document.getElementById('clientsTableBody');
                        const clientsCount = document.getElementById('clientsCount');

                        if (tableBody) {
                            tableBody.parentElement.style.opacity = '0.5';
                            tableBody.parentElement.style.pointerEvents = 'none';

                            const currentUrl = window.location.href;
                            fetch(currentUrl, {
                                headers: { 'X-Requested-With': 'XMLHttpRequest' }
                            })
                            .then(response => response.json())
                            .then(ajaxData => {
                                if (ajaxData.html) {
                                    const parser = new DOMParser();
                                    const doc = parser.parseFromString(ajaxData.html, 'text/html');
                                    const newTableContentElement = doc.querySelector('#clientsTableBody');

                                    if (newTableContentElement) {
                                        tableBody.innerHTML = newTableContentElement.innerHTML;
                                    }

                                    // تحديث عدد العملاء - استخدام الـ count من JSON
                                    if (ajaxData.count !== undefined && clientsCount) {
                                        clientsCount.innerHTML = ajaxData.count;
                                    }

                                    // تحديث الإحصائيات
                                    const statIds = ['statTotal', 'statIndividual', 'statCompany', 'statActive'];
                                    statIds.forEach(id => {
                                        const currentEl = document.getElementById(id);
                                        const newEl = doc.getElementById(id);
                                        if (currentEl && newEl) {
                                            currentEl.innerHTML = newEl.innerHTML;
                                        }
                                    });
                                }

                                tableBody.parentElement.style.opacity = '1';
                                tableBody.parentElement.style.pointerEvents = 'auto';

                                // عرض رسالة النجاح
                                const alertDiv = document.createElement('div');
                                alertDiv.className = 'alert alert-success alert-dismissible fade show position-fixed top-0 start-50 translate-middle-x mt-4';
                                alertDiv.style.zIndex = '9999';
                                alertDiv.innerHTML = `
                                    <i class="fas fa-check-circle me-2"></i>
                                    ${data.message || '✅ تم تحديث بيانات العميل بنجاح'}
                                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                                `;
                                document.body.appendChild(alertDiv);
                                setTimeout(() => alertDiv.remove(), 3000);
                            })
                            .catch(error => {
                                console.error('Update error:', error);
                                tableBody.parentElement.style.opacity = '1';
                                tableBody.parentElement.style.pointerEvents = 'auto';
                                window.location.reload();
                            });
                        } else {
                            window.location.reload();
                        }
                    } else {
                        // عرض الأخطاء كإشعار بالون لمدة 5 ثواني
                        let errorMessage = '⚠️ يرجى تصحيح الأخطاء التالية:\n';
                        if (data.errors) {
                            for (const [field, messages] of Object.entries(data.errors)) {
                                messages.forEach(msg => {
                                    const messageText = typeof msg === 'object' ? msg.message : msg;
                                    errorMessage += `• ${field}: ${messageText}\n`;
                                });
                            }
                        }
                        
                        // إنشاء إشعار بالون للأخطاء
                        const alertDiv = document.createElement('div');
                        alertDiv.className = 'alert alert-danger alert-dismissible fade show position-fixed top-0 start-50 translate-middle-x mt-4';
                        alertDiv.style.zIndex = '9999';
                        alertDiv.style.minWidth = '300px';
                        alertDiv.innerHTML = `
                            <i class="fas fa-exclamation-triangle me-2"></i>
                            <strong>خطأ في البيانات</strong><br>
                            <small>${errorMessage.replace(/\n/g, '<br>')}</small>
                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        `;
                        document.body.appendChild(alertDiv);
                        setTimeout(() => alertDiv.remove(), 5000);
                    }
                })
                .catch(error => {
                    console.error('❌ Error:', error);
                    errorContainer.innerHTML = '❌ ' + (error.message || 'حدث خطأ غير متوقع.');
                    errorContainer.classList.remove('d-none');
                })
                .finally(() => {
                    submitBtn.disabled = false;
                    submitBtn.innerHTML = originalText;
                });
            });
        }, 100);
    }

    // ==========================================
    // 2. Filtering and Search
    // ==========================================

    const searchInput = document.getElementById('searchInput');
    const filterForm = document.getElementById('filterForm');
    const tableContainer = document.getElementById('tableContainer');
    const searchLoading = document.getElementById('searchLoading');
    const clientTypeFilter = document.getElementById('clientTypeFilter');

    let debounceTimer;

    // تأكد من أن القيمة الافتراضية فارغة
    if (clientTypeFilter && !window.location.search.includes('type=')) {
        clientTypeFilter.value = '';
    }
    
    /**
     * Update table via AJAX
     */
    function updateTable() {
        if (!filterForm) return;
        const formData = new FormData(filterForm);
        const params = new URLSearchParams(formData);
        const url = `${window.location.pathname}?${params.toString()}`;

        if (searchLoading) searchLoading.classList.add('show');
        if (tableContainer) tableContainer.style.opacity = '0.6';

        fetch(url, {
            headers: {
                'X-Requested-With': 'XMLHttpRequest'
            }
        })
         .then(response => response.json())
         .then(data => {
             if (!data.html) return;

             const parser = new DOMParser();
             const doc = parser.parseFromString(data.html, 'text/html');

             // تحديث الجدول
             const newTableBody = doc.querySelector('#clientsTableBody');
             if (newTableBody) {
                 document.getElementById('clientsTableBody').innerHTML = newTableBody.innerHTML;
             }

             // تحديث Pagination
             const newPagination = doc.querySelector('#paginationContainer');
             const oldPagination = document.getElementById('paginationContainer');
             if (newPagination) {
                 if (oldPagination) {
                     oldPagination.outerHTML = newPagination.outerHTML;
                 }
             } else if (oldPagination) {
                 oldPagination.remove();
             }

             // تحديث عدد العملاء - استخدام الـ count من JSON
             const currentCount = document.getElementById('clientsCount');
             if (data.count !== undefined && currentCount) {
                 currentCount.innerHTML = data.count;
             }
         })
        .catch(error => {
            console.error('Error:', error);
        })
        .finally(() => {
            if (searchLoading) searchLoading.classList.remove('show');
            if (tableContainer) tableContainer.style.opacity = '1';
        });
    }
    
    // البحث اللحظي
    if (searchInput) {
        searchInput.addEventListener('input', function() {
            clearTimeout(debounceTimer);
            debounceTimer = setTimeout(updateTable, 300);
        });
    }
    
    // الفلاتر
    document.querySelectorAll('.filter-select').forEach(select => {
        select.addEventListener('change', updateTable);
    });
    
    // زر إعادة التعيين
    const resetBtn = document.getElementById('resetBtn');
    if (resetBtn) {
        resetBtn.addEventListener('click', function() {
            if (filterForm) filterForm.reset();
            if (clientTypeFilter) clientTypeFilter.value = '';
            const statusFilter = document.querySelector('select[name="status"]');
            if (statusFilter) statusFilter.value = '';
            updateTable();
        });
    }

    // ==========================================
    // 3. Delete Confirmation
    // ==========================================
    
    document.addEventListener('click', function(e) {
        const deleteBtn = e.target.closest('.btn-delete-client');
        if (deleteBtn) {
            const url = deleteBtn.dataset.url;
            const name = deleteBtn.dataset.name;
            const deleteModal = document.getElementById('deleteClientModal');
            const deleteForm = document.getElementById('deleteClientForm');
            const deleteName = document.getElementById('deleteClientName');

            if (deleteModal && deleteForm && deleteName) {
                deleteForm.action = url;
                deleteName.textContent = name;
                new bootstrap.Modal(deleteModal).show();
            }
        }
    });

    // ==========================================
    // 4. Print Client
    // ==========================================
    
    document.addEventListener('click', function(e) {
        const printBtn = e.target.closest('.action-btn.print');
        if (!printBtn) return;

        e.preventDefault();
        e.stopPropagation();

        const url = printBtn.getAttribute('data-client-print-url');
        if (!url) return;
        const clientId = url.split('/').filter(Boolean).pop();

        printClientDirectly(clientId);
    });

    /**
     * Print client directly using unified print system
     */
    function printClientDirectly(clientId) {
        console.log('🖨️ Printing client:', clientId);

        fetch(`/api/clients/${clientId}/`, {
            headers: {
                'X-Requested-With': 'XMLHttpRequest'
            }
        })
        .then(response => response.json())
        .then(data => {
            console.log('✅ Client data received:', data);

            // بناء أقسام التقرير
            const sections = [];

            // معلومات أساسية - تختلف حسب نوع العميل
            const basicInfo = [
                { label: 'الاسم الكامل', value: data.full_name || '—' },
            ];
            
            // حقول خاصة بالأفراد
            if (data.type === 'individual') {
                basicInfo.push(
                    { label: 'الرقم القومي', value: data.national_id || '—' },
                    { label: 'الوظيفة', value: data.job || '—' }
                );
            }
            
            // حقول خاصة بالشركات
            if (data.type === 'company') {
                basicInfo.push(
                    { label: 'السجل التجاري', value: data.commercial_register || '—' },
                    { label: 'البطاقة الضريبية', value: data.tax_card || '—' }
                );
            }
            
            // حقول مشتركة
            basicInfo.push(
                { label: 'الهاتف', value: data.phone || '—' },
                { label: 'هاتف إضافي', value: data.additional_phone || '—' },
                { label: 'العنوان', value: data.address || '—' }
            );
            
            sections.push({ title: 'المعلومات الأساسية', fields: basicInfo });

            // القضايا
            if (data.cases && data.cases.length > 0) {
                sections.push({
                    title: 'القضايا المرتبطة',
                    table: {
                        headers: ['رقم القضية', 'الموضوع', 'النوع', 'المحكمة', 'الحالة'],
                        rows: data.cases.map(c => [
                            `${c.case_number}/${c.case_year}` || '—',
                            c.subject || '—',
                            c.case_type || '—',
                            c.court?.name || '—',
                            c.status_display || '—'
                        ])
                    }
                });
            }

            // العقود
            if (data.contracts && data.contracts.length > 0) {
                sections.push({
                    title: 'العقود المرتبطة',
                    table: {
                        headers: ['رقم العقد', 'النوع', 'التاريخ', 'الحالة'],
                        rows: data.contracts.map(c => [
                            c.contract_number || '—',
                            c.type_display || '—',
                            c.date || '—',
                            c.status_display || '—'
                        ])
                    }
                });
            }

            // الفواتير
            if (data.invoices && data.invoices.length > 0) {
                sections.push({
                    title: 'الفواتير',
                    table: {
                        headers: ['رقم الفاتورة', 'المبلغ', 'المدفوع', 'المتبقي', 'الحالة'],
                        rows: data.invoices.map(inv => [
                            inv.invoice_number || '—',
                            inv.total_amount_formatted || '—',
                            inv.paid_amount_formatted || '0.00',
                            inv.remaining_amount_formatted || '—',
                            inv.status_display || '—'
                        ])
                    }
                });
            }

            // المرفقات
            if (data.attachments && data.attachments.length > 0) {
                sections.push({
                    title: 'المرفقات',
                    table: {
                        headers: ['الاسم', 'التاريخ'],
                        rows: data.attachments.map(att => [
                            att.file_name || '—',
                            att.uploaded_at || '—'
                        ])
                    }
                });
            }

            // الشارات
            const badges = [
                data.type_display || '—',
                data.status_display || '—'
            ];

            console.log('📦 Prepared sections:', sections);
            console.log('🏷️ Prepared badges:', badges);

            // استدعاء دالة الطباعة الموحدة
            if (typeof printUnified === 'function') {
                printUnified({
                    type: 'client',
                    title: 'تقرير العميل',
                    badges: badges,
                    sections: sections,
                    footer: `تم استخراج هذا التقرير للعميل: ${data.full_name || '—'}`
                });
            }
        })
        .catch(error => {
            console.error('❌ Error in printClientDirectly:', error);
            alert('❌ حدث خطأ أثناء الطباعة: ' + error.message);
        });
    }
});
