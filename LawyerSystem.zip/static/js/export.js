function buildExportQuery(formSelector) {
    const form = document.querySelector(formSelector);
    const params = new URLSearchParams();

    if (!form) {
        return params.toString();
    }

    const formData = new FormData(form);
    for (const [key, value] of formData.entries()) {
        if (value) {
            params.append(key, value);
        }
    }

    return params.toString();
}

function resetExportButton(btn, originalHtml, delay = 1000) {
    window.setTimeout(() => {
        btn.disabled = false;
        btn.innerHTML = originalHtml;
    }, delay);
}

function downloadBase64File(content, filename, mimeType) {
    const byteCharacters = atob(content);
    const byteNumbers = new Array(byteCharacters.length);
    for (let i = 0; i < byteCharacters.length; i++) {
        byteNumbers[i] = byteCharacters.charCodeAt(i);
    }

    const blob = new Blob([new Uint8Array(byteNumbers)], { type: mimeType });
    const link = document.createElement('a');
    link.href = window.URL.createObjectURL(blob);
    link.download = filename;
    link.click();
}

window.handleExportButton = function(event) {
    const btn = event?.target?.closest('button');
    if (!btn) return;

    const exportUrl = btn.dataset.exportUrl;
    const exportType = (btn.dataset.exportType || 'excel').toLowerCase();
    const formSelector = btn.dataset.formSelector || 'form';
    if (!exportUrl) {
        console.error('Missing data-export-url on export button');
        return;
    }

    const originalHtml = btn.innerHTML;
    btn.disabled = true;
    btn.innerHTML = '<i class="fas fa-spinner fa-spin me-1"></i> جاري التصدير...';

    const queryString = buildExportQuery(formSelector);
    const url = queryString ? `${exportUrl}?${queryString}` : exportUrl;
    const isDesktop = typeof pywebview !== 'undefined' && pywebview.api && pywebview.api.saveFile;

    if (isDesktop) {
        fetch(url, {
            headers: { 'X-Desktop-Mode': 'true' }
        })
            .then(response => response.json())
            .then(data => {
                if (!data.success) {
                    throw new Error(data.error || 'فشل تصدير الملف');
                }
                const fileTypes = exportType === 'pdf' 
                    ? ['PDF files (*.pdf)', 'All files (*.*)'] 
                    : ['Excel files (*.xlsx)', 'All files (*.*)'];
                return pywebview.api.saveFile(data.filename, data.content, fileTypes);
            })
            .catch(error => {
                console.error('Desktop export error:', error);
                alert('حدث خطأ أثناء التصدير: ' + error.message);
            })
            .finally(() => resetExportButton(btn, originalHtml));
        return;
    }

    if (exportType === 'pdf') {
        fetch(url, {
            headers: { 'X-Desktop-Mode': 'true' }
        })
            .then(response => {
                // إصلاح مشكلة توافق وضع سطح المكتب: التحقق من نوع الاستجابة
                const contentType = response.headers.get('content-type');
                if (contentType && contentType.includes('application/pdf')) {
                    return response.blob().then(blob => {
                        const fileUrl = window.URL.createObjectURL(blob);
                        const link = document.createElement('a');
                        link.href = fileUrl;
                        link.download = `report_${Date.now()}.pdf`;
                        link.click();
                        window.URL.revokeObjectURL(fileUrl);
                        return;
                    });
                }
                return response.json();
            })
            .then(data => {
                if (!data) return;
                if (data.success) {
                    downloadBase64File(data.content, data.filename, 'application/pdf');
                    return;
                }
                window.location.href = url;
            })
            .catch(error => {
                console.error('Browser PDF export error:', error);
                // في حالة فشل الـ JSON نتحول مباشرة للتحميل التقليدي
                window.location.href = url;
            })
            .finally(() => resetExportButton(btn, originalHtml));
        return;
    }

    window.location.href = url;
    resetExportButton(btn, originalHtml, 2000);
};
