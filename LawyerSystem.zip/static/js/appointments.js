/**
 * Mizan Al-Adala - Appointments Management JavaScript
 * Handles AJAX modals and updates for Appointments
 */

document.addEventListener('DOMContentLoaded', function () {
    initAppointmentModals();
});

function initAppointmentModals() {
    // 1. Add Appointment (Standard Modal in Template)
    const addAppointmentForm = document.getElementById('addAppointmentForm');
    if (addAppointmentForm) {
        addAppointmentForm.addEventListener('submit', function (e) {
            e.preventDefault();
            submitAppointmentForm(this, 'addAppointmentModal');
        });
    }

    // 2. Edit Appointment Modal
    document.addEventListener('click', function (e) {
        const editBtn = e.target.closest('.btn-edit-appointment');
        if (!editBtn) return;

        e.preventDefault();
        const url = editBtn.dataset.url || editBtn.href;
        const modalEl = document.getElementById('appointmentModal');
        const contentArea = document.getElementById('appointmentModalContent');

        if (modalEl && contentArea) {
            contentArea.innerHTML = '<div class="text-center py-5"><div class="spinner-border text-info" role="status"></div><p class="mt-2">جاري التحميل...</p></div>';
            const modal = bootstrap.Modal.getOrCreateInstance(modalEl);
            modal.show();

            fetch(url, { headers: { 'X-Requested-With': 'XMLHttpRequest' } })
                .then(res => res.json())
                .then(data => {
                    if (data.html) {
                        contentArea.innerHTML = data.html;
                        const form = modalEl.querySelector('form');
                        if (form) {
                            form.addEventListener('submit', function (ev) {
                                ev.preventDefault();
                                submitAppointmentForm(this, 'appointmentModal');
                            });
                        }
                    } else {
                        contentArea.innerHTML = '<div class="alert alert-danger">❌ فشل تحميل المحتوى</div>';
                    }
                })
                .catch(err => {
                    console.error('Fetch error:', err);
                    contentArea.innerHTML = '<div class="alert alert-danger">❌ فشل تحميل البيانات.</div>';
                });
        }
    });

    // 3. Delete Appointment Confirmation
    document.addEventListener('click', function (e) {
        const deleteBtn = e.target.closest('.btn-delete-appointment');
        if (deleteBtn) {
            const url = deleteBtn.getAttribute('data-url');
            const client = deleteBtn.getAttribute('data-client');
            const date = deleteBtn.getAttribute('data-date');

            const modalEl = document.getElementById('deleteAppointmentModal');
            const infoArea = document.getElementById('deleteAppointmentInfo');
            const form = document.getElementById('deleteAppointmentForm');

            if (modalEl && infoArea && form) {
                infoArea.textContent = `${client} (${date})`;
                form.setAttribute('action', url);
                bootstrap.Modal.getOrCreateInstance(modalEl).show();
            }
        }
    });

    // 4. Delete Appointment Submission
    const deleteAppointmentForm = document.getElementById('deleteAppointmentForm');
    if (deleteAppointmentForm) {
        deleteAppointmentForm.addEventListener('submit', function (e) {
            e.preventDefault();
            const url = this.getAttribute('action');
            const formData = new FormData(this);

            fetch(url, {
                method: 'POST',
                body: formData,
                headers: { 'X-Requested-With': 'XMLHttpRequest' }
            })
                .then(res => res.json())
                .then(data => {
                    if (data.status === 'success') {
                        bootstrap.Modal.getInstance(document.getElementById('deleteAppointmentModal')).hide();
                        window.location.reload();
                    } else {
                        alert('❌ فشل الحذف');
                    }
                });
        });
    }
}

function submitAppointmentForm(form, modalId) {
    const submitBtn = form.querySelector('button[type="submit"]');
    const originalText = submitBtn.innerHTML;

    submitBtn.disabled = true;
    submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin me-1"></i> جاري الحفظ...';

    const formData = new FormData(form);

    fetch(form.getAttribute('action') || window.location.href, {
        method: 'POST',
        body: formData,
        headers: { 'X-Requested-With': 'XMLHttpRequest' }
    })
        .then(res => res.json())
        .then(data => {
            if (data.status === 'success') {
                bootstrap.Modal.getInstance(document.getElementById(modalId)).hide();
                window.location.reload();
            } else if (data.errors) {
                alert('❌ يرجى تصحيح الأخطاء في النموذج');
            } else {
                alert('❌ حدث خطأ أثناء الحفظ');
            }
        })
        .catch(err => {
            console.error('Submit error:', err);
            alert('❌ حدث خطأ في الاتصال');
        })
        .finally(() => {
            submitBtn.disabled = false;
            submitBtn.innerHTML = originalText;
        });
}
