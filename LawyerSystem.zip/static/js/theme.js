/* Theme Toggle - Mizan Al-Adala
 *
 * The theme is now rendered server-side via the `user_theme` context processor.
 * This script only handles the toggle button and saves changes back to the server.
 */

function _getCSRFToken() {
    var name = 'csrftoken';
    var cookies = document.cookie.split(';');
    for (var i = 0; i < cookies.length; i++) {
        var cookie = cookies[i].trim();
        if (cookie.indexOf(name + '=') === 0) {
            return cookie.substring(name.length + 1);
        }
    }
    return '';
}

function _applyTheme(theme) {
    document.documentElement.setAttribute('data-theme', theme);
    var themeToggle = document.getElementById('themeToggle');
    if (!themeToggle) return;
    var moonIcon = themeToggle.querySelector('.moon-icon');
    var sunIcon = themeToggle.querySelector('.sun-icon');
    if (theme === 'dark') {
        if (moonIcon) moonIcon.style.display = 'none';
        if (sunIcon) sunIcon.style.display = 'block';
    } else {
        if (moonIcon) moonIcon.style.display = 'block';
        if (sunIcon) sunIcon.style.display = 'none';
    }
}

function _saveThemeToServer(theme) {
    var csrfToken = _getCSRFToken();
    if (!csrfToken) return;

    fetch('/core/theme/', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRFToken': csrfToken,
            'X-Requested-With': 'XMLHttpRequest',
        },
        body: JSON.stringify({ theme: theme }),
    }).catch(function() { /* silently ignore */ });
}

function initTheme() {
    var themeToggle = document.getElementById('themeToggle');
    if (!themeToggle) return;

    // The theme is already set server-side via data-theme attribute.
    // Just read it and set up the toggle button.
    var currentTheme = document.documentElement.getAttribute('data-theme') || 'light';
    _applyTheme(currentTheme);

    // Remove old listeners to avoid duplicates (HTMX re-renders)
    var newToggle = themeToggle.cloneNode(true);
    themeToggle.parentNode.replaceChild(newToggle, themeToggle);

    newToggle.addEventListener('click', function() {
        var current = document.documentElement.getAttribute('data-theme');
        var next = current === 'dark' ? 'light' : 'dark';
        _applyTheme(next);
        // Save to localStorage as fallback AND server as primary
        localStorage.setItem('theme', next);
        _saveThemeToServer(next);
    });
}

document.addEventListener('DOMContentLoaded', initTheme);

// Re-init after HTMX swaps
document.addEventListener('htmx:afterSwap', function() {
    initTheme();
});

