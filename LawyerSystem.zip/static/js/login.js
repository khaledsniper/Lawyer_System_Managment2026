/**
 * Login Page JavaScript
 * Handles password visibility toggle, exit app, and desktop mode detection.
 */

document.addEventListener('DOMContentLoaded', function() {
    const togglePassword = document.getElementById('togglePassword');
    const passwordInput = document.getElementById('id_password');
    const exitAppBtn = document.getElementById('exitAppBtn');

    function getCookie(name) {
        const value = `; ${document.cookie}`;
        const parts = value.split(`; ${name}=`);
        if (parts.length === 2) return parts.pop().split(';').shift();
        return '';
    }

    // Toggle password visibility
    if (togglePassword && passwordInput) {
        togglePassword.addEventListener('click', function () {
            const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
            passwordInput.setAttribute('type', type);
            this.classList.toggle('fa-eye');
            this.classList.toggle('fa-eye-slash');
        });

        // Keyboard accessibility
        togglePassword.addEventListener('keypress', function(e) {
            if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                this.click();
            }
        });
    }

    // Exit app handler (desktop mode)
    if (exitAppBtn) {
        exitAppBtn.addEventListener('click', async function() {
            function closeApp() {
                if (typeof pywebview !== 'undefined' && pywebview.api && typeof pywebview.api.closeWindow === 'function') {
                    pywebview.api.closeWindow();
                } else {
                    window.close();
                }
            }

            try {
                await fetch(CLOSE_DESKTOP_APP_URL, {
                    method: 'POST',
                    headers: {
                        'X-CSRFToken': getCookie('csrftoken'),
                        'X-Requested-With': 'XMLHttpRequest'
                    }
                });
                closeApp();
            } catch (error) {
                closeApp();
            }
        });
    }

    // Desktop mode detection
    if (typeof pywebview !== 'undefined') {
        console.log('[Login] Running in desktop mode');

        let checkUrlChange = setInterval(function() {
            const urlChanged = window.location.href.indexOf('login') === -1;
            if (urlChanged) {
                clearInterval(checkUrlChange);
            }
        }, 500);
    }
});
