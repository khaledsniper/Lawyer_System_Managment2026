/**
 * نظام الطباعة الموحد - دِرْعٌ وَسَيْفٌ
 * Unified Print System
 * 
 * يوفر تصميم موحد وشامل لجميع أنواع التقارير
 * (القضايا - العملاء - الخصوم - الجلسات)
 * 
 * يستخدم نفس طريقة طباعة القضايا - طباعة مباشرة بدون نافذة منبثقة
 */

// ========================================
// أدوات مساعدة
// ========================================
function escapeHtml(str) {
    if (str === null || str === undefined) return '—';
    return String(str)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#039;');
}

// ========================================
// أنماط الطباعة الموحدة
// ========================================
const PRINT_STYLES = `
    @page {
        size: A4;
        margin: 0;
    }
    #unifiedPrintArea { display: none; }
    @media print {
        @page {
            size: A4;
            margin: 0;
        }
        html, body {
            height: 100% !important;
            overflow: hidden !important;
            margin: 0 !important;
            padding: 0 !important;
        }
        body * { visibility: hidden; }
        #unifiedPrintArea, #unifiedPrintArea * { visibility: visible; }
        #unifiedPrintArea {
            display: block !important;
            position: fixed !important;
            left: 0 !important;
            top: 0 !important;
            width: 100% !important;
            height: 100% !important;
            padding: 10mm !important;
            margin: 0 !important;
            font-family: 'Cairo', Arial, sans-serif !important;
            background: #fff !important;
            direction: rtl !important;
            overflow: hidden !important;
        }
         .print-wrapper {
             border: 2px solid #64748b !important;
             border-radius: 8px !important;
             overflow: hidden !important;
             /* إزالة الحد الأقصى للارتفاع لتجنب إنشاء صفحة إضافية عند طباعة صف واحد */
             height: auto !important;
         }
        .print-header {
            background: linear-gradient(135deg, #0f172a 0%, #2563eb 60%, #3b82f6 100%);
            color: #fff; padding: 12px 18px 12px 0; display: flex; flex-direction: row-reverse; align-items: center; justify-content: space-between; gap: 14px;
        }
        .print-logo {
            width: 85px; height: 85px; border-radius: 12px; background: #fff;
            padding: 5px; object-fit: contain; box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        }
        .print-title h2 { margin: 0; font-size: 20px; font-weight: 700; }
        .print-title p { margin: 2px 0 0; opacity: .9; font-size: 11px; }
        .badges { display: flex; flex-wrap: wrap; gap: 6px; margin-top: 8px; }
        .badge-pill {
            background: rgba(255,255,255,0.12); border: 1px solid rgba(255,255,255,0.2);
            border-radius: 999px; padding: 4px 10px; font-size: 11px; font-weight: 700;
        }
        .print-body { padding: 14px; background: #fff; }
        .section { margin-bottom: 12px; page-break-inside: avoid; page-break-after: avoid; }
        .section h4 {
            margin: 0 0 8px; font-size: 14px; color: #0f172a;
            border-right: 3px solid #2563eb; padding-right: 8px;
        }
        .grid { 
            display: grid; 
            grid-template-columns: repeat(2, minmax(0, 1fr)); 
            gap: 12px; 
            page-break-inside: avoid; 
        }
        .card {
            border: 1.5px solid #94a3b8 !important; 
            border-radius: 6px; 
            padding: 10px 12px; 
            background: #fff !important;
            page-break-inside: avoid;
            display: flex;
            flex-direction: column;
            justify-content: center;
        }
        .label { color: #475569; font-weight: 700; font-size: 11px; margin-bottom: 2px; }
        .value { color: #000; font-weight: 700; font-size: 13px; }
        .table { width: 100%; border-collapse: collapse; page-break-after: avoid; page-break-inside: avoid; margin-top: 10px; }
        .table th {
            background: #f1f5f9 !important; color: #1e293b; text-align: right;
            padding: 8px 10px; font-size: 11px; border: 1.5px solid #94a3b8;
        }
        .table td { padding: 8px 10px; border: 1.5px solid #94a3b8; font-size: 11px; color: #000; }
        .footer {
            text-align: center; margin-top: 12px; padding-top: 8px;
            border-top: 1px solid #e2e8f0; color: #64748b; font-size: 10px;
            page-break-after: avoid !important;
        }
        .footer p { margin: 4px 0; }
    }
`;

// ========================================
// دالة الطباعة الموحدة الرئيسية - طباعة مباشرة مثل القضايا
// ========================================
function printUnified(config) {
    const {
        type,         // نوع التقرير: 'client', 'opponent', 'case', 'session'
        title,        // عنوان التقرير
        badges = [],  // الأوسمة (الحالة، الأولوية، الرقم...)
        sections = [], // الأقسام (حقول + جداول)
        footer = 'تم الطباعة من نظام دِرْعٌ وَسَيْفٌ'
    } = config;

    // مؤشر تقدم تحميل الطباعة
    const loadingIndicator = document.createElement('div');
    loadingIndicator.style.cssText = `
        position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%);
        background: rgba(0,0,0,0.8); color: white; padding: 20px 40px; border-radius: 8px;
        z-index: 99999; font-family: Cairo, Arial; font-size: 14px;
    `;
    loadingIndicator.textContent = '⏳ جاري تحضير الطباعة...';
    document.body.appendChild(loadingIndicator);

    console.log('🖨️ printUnified called with config:', config);
    console.log('Sections count:', config.sections?.length);
    console.log('Badges count:', config.badges?.length);

    // بناء HTML مع تنقية البيانات (XSS Protection)
    const badgesHTML = config.badges && config.badges.length > 0 
        ? `<div class="badges">${config.badges.map(b => `<span class="badge-pill">${escapeHtml(b)}</span>`).join('')}</div>`
        : '';

    const sectionsHTML = sections.map(section => {
        let content = '';
        
        // إذا كانت الحقول
        if (section.fields && section.fields.length > 0) {
            content = `<div class="grid">
                ${section.fields.map(field => `
                    <div class="card">
                        <div class="label">${escapeHtml(field.label)}</div>
                        <div class="value">${escapeHtml(field.value)}</div>
                    </div>
                `).join('')}
            </div>`;
        }
        
        // إذا كانت جدول
        if (section.table) {
            const table = section.table;
            content = `<table class="table">
                <thead><tr>${table.headers.map(h => `<th>${escapeHtml(h)}</th>`).join('')}</tr></thead>
                <tbody>
                    ${table.rows.map(row => `
                        <tr>${row.map(cell => `<td>${escapeHtml(cell)}</td>`).join('')}</tr>
                    `).join('')}
                </tbody>
            </table>`;
        }
        
        // إذا كانت قائمة
        if (section.list && section.list.length > 0) {
            content = `<div class="card"><div class="value">
                <ul style="margin:0 0 0 16px; padding:0; list-style:none;">
                    ${section.list.map(item => `<li>• ${escapeHtml(item)}</li>`).join('')}
                </ul>
            </div></div>`;
        }

        return `<div class="section"><h4>${escapeHtml(section.title)}</h4>${content}</div>`;
    }).join('');

    // إنشاء عنصر الطباعة المخفي
    let printContent = document.getElementById('unifiedPrintArea');
    if (!printContent) {
        printContent = document.createElement('div');
        printContent.id = 'unifiedPrintArea';
        document.body.appendChild(printContent);
    }

    // الحصول على شعار المكتب من العنصر الموجود في الصفحة إذا كان متوفراً
    let officeLogo = '/static/images/logo.png';
    const existingLogo = document.querySelector('img[alt="شعار المكتب"], .navbar-brand img, #office-logo');
    if (existingLogo && existingLogo.src) {
        officeLogo = existingLogo.src;
    }

    const template = document.createElement('template');
    template.innerHTML = `
        <div class="print-wrapper">
            <div class="print-header">
                <img src="${officeLogo}" alt="شعار المكتب" class="print-logo" onerror="this.style.display='none'">
                <div class="print-title">
                    <h2>دِرْعٌ وَسَيْفٌ - ${escapeHtml(title)}</h2>
                    <p>طباعة شاملة للتفاصيل</p>
                    ${badgesHTML}
                </div>
            </div>
            <div class="print-body">
                ${sectionsHTML}
                <div class="footer">
                    <p style="margin: 4px 0;">${escapeHtml(footer)}</p>
                    <p style="margin: 4px 0;">${new Date().toLocaleDateString('ar-EG', { year: 'numeric', month: 'long', day: 'numeric' })}</p>
                </div>
            </div>
        </div>
    `;

    printContent.replaceChildren(template.content);

    console.log('📄 Print content created, length:', printContent.innerHTML.length);

    // إضافة الأنماط إذا لم تكن موجودة
    if (!document.getElementById('printUnifiedStyles')) {
        const printStyle = document.createElement('style');
        printStyle.id = 'printUnifiedStyles';
        printStyle.innerHTML = PRINT_STYLES;
        document.head.appendChild(printStyle);
    }

    // طباعة مباشرة (مثل طريقة القضايا)
    printContent.style.display = 'block';
    
    // تغيير عنوان الصفحة مؤقتاً لتسمية ملف الـ PDF الناتج
    const originalTitle = document.title;
    document.title = config.title || 'تقرير_دِرْعٌ_وَسَيْفٌ';

    // دالة تنظيف شاملة بعد انتهاء الطباعة
    const cleanup = () => {
        printContent.style.display = 'none';
        printContent.innerHTML = '';
        document.title = originalTitle;
        
        // إزالة جميع مستمعي الأحداث لمنع تسرب الذاكرة
        window.removeEventListener('beforeprint', beforePrintHandler);
        window.removeEventListener('afterprint', afterPrintHandler);
        console.log('✅ Print cleanup complete');
    };

    // إضافة مستمع لحدث قبل الطباعة لضمان عدم وجود صفحات فارغة
    const beforePrintHandler = () => {
        // إخفاء أي عناصر فارغة قد تسبب صفحات إضافية
        const emptyElements = document.querySelectorAll('#unifiedPrintArea > *:empty');
        emptyElements.forEach(el => el.style.display = 'none');
        
        const wrapper = document.querySelector('#unifiedPrintArea .print-wrapper');
        if (wrapper) {
            wrapper.querySelectorAll('*').forEach(el => {
                if (el.tagName.toLowerCase() === 'img') return;
                if (!el.innerHTML.trim()) {
                    el.style.display = 'none';
                }
            });
        }
    };

    // مستمع بعد الطباعة
    const afterPrintHandler = () => {
        cleanup();
        
        // رسالة تأكيد نجاح الطباعة
        const successMsg = document.createElement('div');
        successMsg.style.cssText = `
            position: fixed; top: 20px; right: 20px; 
            background: #10b981; color: white; 
            padding: 12px 24px; border-radius: 8px;
            z-index: 99999; font-family: Cairo, Arial; font-size: 14px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
            animation: fadeIn 0.3s ease;
        `;
        successMsg.textContent = '✅ تم إرسال التقرير للطباعة بنجاح';
        document.body.appendChild(successMsg);
        
        // إزالة الرسالة تلقائياً بعد 3 ثواني
        setTimeout(() => {
            successMsg.style.opacity = '0';
            successMsg.style.transition = 'opacity 0.3s ease';
            setTimeout(() => successMsg.remove(), 300);
        }, 3000);
    };

    // إضافة مستمعي الأحداث مع خيار once
    window.addEventListener('beforeprint', beforePrintHandler, { once: true });
    window.addEventListener('afterprint', afterPrintHandler, { once: true });

    // إصلاح التوافق مع جميع المتصفحات (Chrome, Firefox, Edge, Safari)
    const isFirefox = navigator.userAgent.toLowerCase().indexOf('firefox') > -1;
    const isSafari = navigator.userAgent.toLowerCase().indexOf('safari') > -1 && navigator.userAgent.toLowerCase().indexOf('chrome') === -1;
    const printDelay = isFirefox ? 350 : (isSafari ? 400 : 150);

    // معالجة حالة إلغاء الطباعة متوافقة مع جميع المتصفحات
    window.addEventListener('mousemove', function restoreOnCancel() {
        setTimeout(() => {
            if (printContent.style.display === 'block') {
                cleanup();
            }
            window.removeEventListener('mousemove', restoreOnCancel);
        }, isSafari ? 2000 : 1000);
    }, { once: true });

    // تصحيح خاصية visibility في Firefox
    if (isFirefox) {
        document.body.style.overflow = 'hidden';
        window.addEventListener('afterprint', () => {
            document.body.style.overflow = '';
        }, { once: true });
    }

    // إزالة مؤشر التحميل قبل بدء الطباعة
    setTimeout(() => {
        loadingIndicator.remove();
        window.print();
    }, printDelay);
}
