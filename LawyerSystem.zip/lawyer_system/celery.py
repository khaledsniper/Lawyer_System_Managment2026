import os
from celery import Celery

# ضبط متغير البيئة لإعدادات Django
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'lawyer_system.settings')

app = Celery('lawyer_system')

# استخدام إعدادات Django (التي تبدأ بـ CELERY_)
app.config_from_object('django.conf:settings', namespace='CELERY')

# اكتشاف المهام (Tasks) تلقائياً في جميع التطبيقات المسجلة
app.autodiscover_tasks()

@app.task(bind=True)
def debug_task(self):
    print(f'Request: {self.request!r}')
